/**
 * Kampar Street Food - Main JavaScript
 * 
 * MAIN SECTIONS:
 * 1. Global Application State - stores data used across multiple pages
 * 2. Utility Functions - helper functions for common tasks
 * 3. Favorites Management - handles saving/removing favorite vendors
 * 4. Navigation Functions - manages menu and page navigation
 * 5. Data Loading Functions - loads data from JSON files
 * 6. Social Sharing Functions - handles sharing to social media
 */

// =============================================================================
// GLOBAL APPLICATION STATE
// =============================================================================

/**
 * Global application state object
 */

// Global application state (legacy - now managed by StateManager)
window.appState = {
    // Array of vendor IDs that user has favorited (e.g., ["1", "3", "7"])
    favorites: JSON.parse(localStorage.getItem('favorites') || '[]'),
    
    // Array of all vendor objects loaded from vendors.json
    vendors: [],
    
    // Array of all blog post objects loaded from blog-posts.json
    blogPosts: [],
    
    // Current search term (what user typed in search box)
    searchQuery: '',
    
    // Current filter settings applied to vendor list
    filters: {
        category: '',      // Filter by food category (Traditional, Modern, etc.)
        priceRange: '',    // Filter by price ($, $$, $$$)
        status: '',        // Filter by open/closed status
        tags: []           // Filter by tags (future feature)
    },
    
    // Initialization flags
    _initialized: false,
    _stateManagerInitialized: false
};

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================
const utils = {
    /**
     * Debounce function for search
     * @param {Function} func - The function to delay
     * @param {number} wait - How long to wait in milliseconds (e.g., 300 = 0.3 seconds)
     * @returns {Function} - A new function that waits before executing
     */
    debounce: function(func, wait) {
        let timeout;  // Stores the timer ID
        
        // Return a new function that wraps the original
        return function executedFunction(...args) {
            // Function to run after the wait period
            const later = () => {
                clearTimeout(timeout);  // Clear the timer
                func(...args);          // Run the original function
            };
            
            // If there's already a timer running, cancel it
            clearTimeout(timeout);
            
            // Start a new timer
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Format date for display
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {string} - Human-readable date like "August 15, 2024"
     */
    formatDate: function(dateString) {
        const date = new Date(dateString);  // Create Date object from string
        
        // Use built-in formatting with US English locale
        return date.toLocaleDateString('en-US', {
            year: 'numeric',   // Full year (2024)
            month: 'long',     // Full month name (August)
            day: 'numeric'     // Day number (15)
        });
    },

    /**
     * Format time for display (12-hour format)
     * @param {string} timeString - Time in HH:MM format (24-hour)
     * @returns {string} - Time in 12-hour format with AM/PM
     */
    formatTime: function(timeString) {
        const [hours, minutes] = timeString.split(':');  // Split "14:30" into ["14", "30"]
        const date = new Date();  // Create new Date object for today
        
        // Set the hours and minutes (converts string to number)
        date.setHours(parseInt(hours), parseInt(minutes));
        
        // Use built-in formatting for 12-hour time
        return date.toLocaleTimeString('en-US', {
            hour: 'numeric',     // Hour without leading zero (2, not 02)
            minute: '2-digit',   // Minutes with leading zero (30, not 3)
            hour12: true         // Use 12-hour format with AM/PM
        });
    },

    // Check if vendor is currently open
    isVendorOpen: function(vendor) {
        const now = new Date();
        const currentDay = now.toLocaleDateString('en-US', { weekday: 'long' });
        const currentTime = now.getHours() * 60 + now.getMinutes();
        
        const todayHours = vendor.hours.find(h => h.day === currentDay);
        if (!todayHours) return false;
        
        const [openHour, openMinute] = todayHours.open.split(':').map(Number);
        const [closeHour, closeMinute] = todayHours.close.split(':').map(Number);
        
        const openTime = openHour * 60 + openMinute;
        const closeTime = closeHour * 60 + closeMinute;
        
        return currentTime >= openTime && currentTime <= closeTime;
    },

    // Generate URL-friendly slug
    generateSlug: function(text) {
        return text
            .toLowerCase()
            .replace(/[^a-z0-9 -]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .trim('-');
    },

    // Generate star rating HTML
    generateStarRating: function(rating, size = '1rem') {
        let starsHtml = '';
        for (let i = 1; i <= 5; i++) {
            const starClass = i <= rating ? 'fas fa-star' : 'far fa-star';
            starsHtml += `<i class="${starClass} rating-star" style="font-size: ${size}"></i>`;
        }
        return starsHtml;
    },

    // Truncate text with ellipsis
    truncateText: function(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substr(0, maxLength) + '...';
    },

    // Copy text to clipboard
    copyToClipboard: function(text) {
        if (navigator.clipboard) {
            return navigator.clipboard.writeText(text);
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            return Promise.resolve();
        }
    },

    // Show toast notification
    showToast: function(message, type = 'info') {
        const toast = $(`
            <div class="toast align-items-center text-white bg-${type} border-0 position-fixed" 
                 style="top: 20px; right: 20px; z-index: 1055;" role="alert">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `);
        
        $('body').append(toast);
        const bsToast = new bootstrap.Toast(toast[0]);
        bsToast.show();
        
        // Remove toast after it's hidden
        toast.on('hidden.bs.toast', function() {
            toast.remove();
        });
    },

    // Smooth scroll to element
    smoothScrollTo: function(element, offset = 0) {
        const target = $(element);
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - offset
            }, 500);
        }
    }
};



// Navigation Functions
const navigation = {
    // Initialize navigation functionality
    init: function() {
        this.setupStickyNavbar();
        this.setupMobileMenu();
        this.setupActivePageHighlight();
    },

    // Setup sticky navbar behavior
    setupStickyNavbar: function() {
        $(window).scroll(function() {
            const navbar = $('.navbar');
            if ($(this).scrollTop() > 50) {
                navbar.addClass('scrolled');
            } else {
                navbar.removeClass('scrolled');
            }
        });
    },

    // Setup mobile menu functionality
    setupMobileMenu: function() {
        // Mobile menu toggle
        $('.navbar-toggler').click(function() {
            $(this).toggleClass('active');
        });

        // Close mobile menu when clicking on a link
        $('.navbar-nav .nav-link').click(function() {
            $('.navbar-collapse').collapse('hide');
            $('.navbar-toggler').removeClass('active');
        });
    },

    // Highlight active page in navigation
    setupActivePageHighlight: function() {
        const currentPage = window.location.pathname.split('/').pop() || 'home.html';
        const pageMap = {
            'index.html': 'login', // Login page
            'home.html': 'home',   // Main homepage
            '': 'home',
            'explore.html': 'explore',
            'vendor-details.html': 'explore',
            'blog.html': 'blog',
            'blog-post.html': 'blog',
            'submit-vendor.html': 'submit',
            'subscription.html': 'subscription',
            'about.html': 'about',
            'contact.html': 'contact',
            'favorites.html': 'favorites',
            'profile.html': 'profile'
        };

        const activePage = pageMap[currentPage] || 'home';
        $(`.nav-link[data-page="${activePage}"]`).addClass('active');
    }
};

// Data Loading Functions
const dataManager = {
    // Load vendors data
    loadVendors: function() {
        return $.getJSON('/data/vendors.json')
            .done(function(data) {
                appState.vendors = data;
            })
            .fail(function() {
                console.error('Failed to load vendors data');
                utils.showToast('Failed to load vendors data', 'danger');
            });
    },

    // Load blog posts data
    loadBlogPosts: function() {
        return $.getJSON('/data/blog-posts.json')
            .done(function(data) {
                appState.blogPosts = data;
            })
            .fail(function() {
                console.error('Failed to load blog posts data');
                utils.showToast('Failed to load blog posts data', 'danger');
            });
    },

    // Get vendor by ID
    getVendorById: function(id) {
        return appState.vendors.find(vendor => vendor.id === id);
    },

    // Get blog post by ID
    getBlogPostById: function(id) {
        return appState.blogPosts.find(post => post.id === id);
    }
};

// Social Sharing Functions
const socialShare = {
    // Share on Facebook
    facebook: function(url, title) {
        const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(title)}`;
        this.openShareWindow(shareUrl);
    },

    // Share on Twitter
    twitter: function(url, title) {
        const shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
        this.openShareWindow(shareUrl);
    },

    // Share on WhatsApp
    whatsapp: function(url, title) {
        const text = `${title} ${url}`;
        const shareUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
        this.openShareWindow(shareUrl);
    },

    // Share on Telegram
    telegram: function(url, title) {
        const shareUrl = `https://telegram.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
        this.openShareWindow(shareUrl);
    },

    // Open share window
    openShareWindow: function(url) {
        window.open(url, 'share', 'width=600,height=400,scrollbars=yes,resizable=yes');
    },

    // Use native share API if available
    nativeShare: function(url, title) {
        if (navigator.share) {
            navigator.share({
                title: title,
                url: url
            });
        } else {
            // Fallback to copy link
            utils.copyToClipboard(url).then(() => {
                utils.showToast('Link copied to clipboard', 'success');
            });
        }
    }
};

// Search and Filter Functions
const searchFilter = {
    // Filter vendors based on current filters
    filterVendors: function(vendors) {
        let filtered = [...vendors];

        // Apply search query
        if (appState.searchQuery) {
            const query = appState.searchQuery.toLowerCase();
            filtered = filtered.filter(vendor => 
                vendor.name.toLowerCase().includes(query) ||
                vendor.description.toLowerCase().includes(query) ||
                vendor.tags.some(tag => tag.toLowerCase().includes(query)) ||
                vendor.category.toLowerCase().includes(query)
            );
        }

        // Apply category filter
        if (appState.filters.category) {
            filtered = filtered.filter(vendor => 
                vendor.category === appState.filters.category
            );
        }

        // Apply price range filter
        if (appState.filters.priceRange) {
            filtered = filtered.filter(vendor => 
                vendor.priceBand === appState.filters.priceRange
            );
        }

        // Apply status filter
        if (appState.filters.status) {
            filtered = filtered.filter(vendor => {
                const isOpen = utils.isVendorOpen(vendor);
                return appState.filters.status === 'Open' ? isOpen : !isOpen;
            });
        }

        // Apply tags filter
        if (appState.filters.tags.length > 0) {
            filtered = filtered.filter(vendor =>
                appState.filters.tags.every(tag =>
                    vendor.tags.some(vendorTag => 
                        vendorTag.toLowerCase().includes(tag.toLowerCase())
                    )
                )
            );
        }

        return filtered;
    },

    // Update search query
    updateSearchQuery: function(query) {
        appState.searchQuery = query;
    },

    // Update filters
    updateFilter: function(filterType, value) {
        if (filterType === 'tags') {
            if (appState.filters.tags.includes(value)) {
                appState.filters.tags = appState.filters.tags.filter(tag => tag !== value);
            } else {
                appState.filters.tags.push(value);
            }
        } else {
            appState.filters[filterType] = value;
        }
    },

    // Clear all filters
    clearAllFilters: function() {
        appState.searchQuery = '';
        appState.filters = {
            category: '',
            priceRange: '',
            status: '',
            tags: []
        };
    }
};

// Initialize application when DOM is ready
$(document).ready(function() {
    // Prevent duplicate initialization
    if (window.appState._initialized) {
        console.log('Main.js: Application already initialized, skipping...');
        return;
    }
    
    console.log('Main.js: DOM ready, initializing application...');
    window.appState._initialized = true;
    
    // Initialize navigation first
    navigation.init();

    // Setup global event handlers
    setupGlobalEventHandlers();

    // Load initial data first, then initialize StateManager and other components
    Promise.all([
        dataManager.loadVendors(),
        dataManager.loadBlogPosts()
    ]).then(() => {
        console.log('Main.js: Data loaded successfully');
        console.log('Main.js: Vendors loaded:', appState.vendors.length);
        console.log('Main.js: Blog posts loaded:', appState.blogPosts.length);
        
        // Initialize StateManager after data is loaded (with guard)
        if (typeof StateManager !== 'undefined' && !window.appState._stateManagerInitialized) {
            console.log('Main.js: Initializing StateManager...');
            window.appState._stateManagerInitialized = true;
            StateManager.init();
            
            // Initialize favorites UI after StateManager is ready (single call with delay)
            setTimeout(() => {
                console.log('Main.js: Initializing favorites UI...');
                StateManager.initializeFavoritesUI();
            }, 100); // Increased delay to ensure DOM is ready
        }
        
        // Dispatch event to signal that app is ready
        const event = new CustomEvent('appReady', {
            detail: {
                vendorsCount: appState.vendors.length,
                blogPostsCount: appState.blogPosts.length
            }
        });
        window.dispatchEvent(event);
        
    }).catch(error => {
        console.error('Main.js: Error loading initial data:', error);
    });
});

// Global Event Handlers
function setupGlobalEventHandlers() {
    // Favorite button click handler
    $(document).on('click', '.favorite-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const vendorId = $(this).data('vendor-id');
        if (typeof StateManager !== 'undefined') {
            StateManager.toggleFavorite(vendorId);
        }
    });

    // Share button handlers
    $(document).on('click', '.share-facebook', function(e) {
        e.preventDefault();
        const url = $(this).data('url') || window.location.href;
        const title = $(this).data('title') || document.title;
        socialShare.facebook(url, title);
    });

    $(document).on('click', '.share-twitter', function(e) {
        e.preventDefault();
        const url = $(this).data('url') || window.location.href;
        const title = $(this).data('title') || document.title;
        socialShare.twitter(url, title);
    });

    $(document).on('click', '.share-whatsapp', function(e) {
        e.preventDefault();
        const url = $(this).data('url') || window.location.href;
        const title = $(this).data('title') || document.title;
        socialShare.whatsapp(url, title);
    });

    $(document).on('click', '.share-native', function(e) {
        e.preventDefault();
        const url = $(this).data('url') || window.location.href;
        const title = $(this).data('title') || document.title;
        socialShare.nativeShare(url, title);
        return false;
    });

    // Smooth scroll for anchor links
    $(document).on('click', 'a[href^="#"]', function(e) {
        e.preventDefault();
        const target = $(this.getAttribute('href'));
        if (target.length) {
            utils.smoothScrollTo(target, 80);
        }
    });

    // Back to top button
    const backToTopBtn = $('<button class="btn btn-primary position-fixed" style="bottom: 20px; right: 20px; z-index: 1000; display: none;"><i class="fas fa-arrow-up"></i></button>');
    $('body').append(backToTopBtn);

    $(window).scroll(function() {
        if ($(this).scrollTop() > 200) {
            backToTopBtn.fadeIn();
        } else {
            backToTopBtn.fadeOut();
        }
    });

    backToTopBtn.click(function() {
        $('html, body').animate({ scrollTop: 0 }, 500);
    });
}

// Initialize tooltips
function initializeTooltips() {
    // Initialize Bootstrap tooltips for status badges
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Initialize tooltips when DOM is ready and after dynamic content is loaded
$(document).ready(function() {
    initializeTooltips();
    
    // Re-initialize tooltips when new content is loaded
    $(document).on('DOMNodeInserted', function() {
        setTimeout(initializeTooltips, 100);
    });
});

// Export global functions
window.utils = utils;
window.navigation = navigation;
window.dataManager = dataManager;
window.socialShare = socialShare;
window.searchFilter = searchFilter;
window.initializeTooltips = initializeTooltips;
