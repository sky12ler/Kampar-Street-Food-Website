/**
 * Secure Cookie Management Utilities
 * 


/**
 * Set a secure cookie with appropriate attributes based on protocol
 * 
 * @param {string} name - Cookie name
 * @param {string} value - Cookie value (will be URL encoded)
 * @param {number} days - Expiration in days (default: 180)
 * @returns {boolean} True if cookie was set successfully
 */
export function setCookie(name, value, days = 180) {
    try {
        // Input validation
        if (!name || typeof name !== 'string') {
            console.warn('Cookie name must be a non-empty string');
            return false;
        }
        
        if (value === null || value === undefined) {
            value = '';
        }
        
        // URL encode the value for safety
        const encodedValue = encodeURIComponent(value);
        
        // Calculate expiration date
        const expirationDate = new Date();
        expirationDate.setTime(expirationDate.getTime() + (days * 24 * 60 * 60 * 1000));
        
        // Build cookie string with security attributes
        let cookieString = `${name}=${encodedValue}; expires=${expirationDate.toUTCString()}; path=/; SameSite=Lax`;
        
        // Add Secure attribute only for HTTPS
        if (window.location.protocol === 'https:') {
            cookieString += '; Secure';
        }
        
        // Set the cookie
        document.cookie = cookieString;
        
        // Verify cookie was set by reading it back
        return getCookie(name) === value;
        
    } catch (error) {
        console.error('Error setting cookie:', error);
        return false;
    }
}

/**
 * Get a cookie value by name
 * 
 * @param {string} name - Cookie name to retrieve
 * @returns {string|null} Cookie value (URL decoded) or null if not found
 */
export function getCookie(name) {
    try {
        // Input validation
        if (!name || typeof name !== 'string') {
            console.warn('Cookie name must be a non-empty string');
            return null;
        }
        
        // Escape special regex characters in cookie name
        const nameEQ = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '=';
        
        // Parse all cookies
        const cookies = document.cookie.split(';');
        
        for (let cookie of cookies) {
            // Trim whitespace
            cookie = cookie.trim();
            
            // Check if this cookie matches our name
            if (cookie.indexOf(nameEQ) === 0) {
                // Extract and decode the value
                const encodedValue = cookie.substring(nameEQ.length);
                return decodeURIComponent(encodedValue);
            }
        }
        
        return null;
        
    } catch (error) {
        console.error('Error getting cookie:', error);
        return null;
    }
}

/**
 * Delete a cookie by setting it to expire in the past
 * 
 * @param {string} name - Cookie name to delete
 * @returns {boolean} True if deletion was attempted successfully
 */
export function deleteCookie(name) {
    try {
        // Input validation
        if (!name || typeof name !== 'string') {
            console.warn('Cookie name must be a non-empty string');
            return false;
        }
        
        // Set cookie to expire in the past with all possible path/domain combinations
        const pastDate = 'Thu, 01 Jan 1970 00:00:00 UTC';
        
        // Delete with various path combinations to ensure removal
        const deletionStrings = [
            `${name}=; expires=${pastDate}; path=/`,
            `${name}=; expires=${pastDate}; path=/; domain=${window.location.hostname}`,
            `${name}=; expires=${pastDate}; path=${window.location.pathname}`,
            `${name}=; expires=${pastDate}`
        ];
        
        // Apply deletion strings
        deletionStrings.forEach(cookieString => {
            document.cookie = cookieString;
        });
        
        // Verify deletion
        return getCookie(name) === null;
        
    } catch (error) {
        console.error('Error deleting cookie:', error);
        return false;
    }
}

/**
 * Check if cookies are available and functional
 * 
 * @returns {boolean} True if cookies are supported and enabled
 */
export function areCookiesEnabled() {
    try {
        // Try to set a test cookie
        const testName = '__cookie_test__';
        const testValue = 'test';
        
        setCookie(testName, testValue, 1);
        const retrieved = getCookie(testName);
        deleteCookie(testName);
        
        return retrieved === testValue;
        
    } catch (error) {
        console.error('Error testing cookie availability:', error);
        return false;
    }
}

/**
 * Get all cookies as an object
 * 
 * @returns {Object} Object with cookie names as keys and values as values
 */
export function getAllCookies() {
    try {
        const cookies = {};
        const cookieString = document.cookie;
        
        if (!cookieString) {
            return cookies;
        }
        
        cookieString.split(';').forEach(cookie => {
            const trimmed = cookie.trim();
            const equalIndex = trimmed.indexOf('=');
            
            if (equalIndex > 0) {
                const name = trimmed.substring(0, equalIndex);
                const value = decodeURIComponent(trimmed.substring(equalIndex + 1));
                cookies[name] = value;
            }
        });
        
        return cookies;
        
    } catch (error) {
        console.error('Error getting all cookies:', error);
        return {};
    }
}

// Export default object for convenience
export default {
    set: setCookie,
    get: getCookie,
    delete: deleteCookie,
    enabled: areCookiesEnabled,
    getAll: getAllCookies
};
