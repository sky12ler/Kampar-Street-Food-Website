/**
 * Form Draft Persistence System
 */

import { set, get, del, has } from './ss.js';

// Configuration
const STORAGE_KEY_PREFIX = 'form_draft_';
const AUTO_SAVE_DELAY = 500; // milliseconds
const SUBMIT_VENDOR_FORM_ID = 'submitVendorForm';
const SUBMIT_VENDOR_PAGE_PATH = '/submit-vendor.html';

// State management
const formStates = new Map();
const saveTimeouts = new Map();

/**
 * Initialize form persistence system
 * Auto-detects forms and starts monitoring
 */
export function initFormPersistence() {
    // Wait for DOM to be fully loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            initializeFormPersistence();
        });
    } else {
        initializeFormPersistence();
    }
}

/**
 * Internal initialization function
 */
function initializeFormPersistence() {
    console.log('Initializing form persistence system...');
    
    // Find forms to monitor
    const formsToMonitor = findFormsToMonitor();
    
    if (formsToMonitor.length === 0) {
        console.log('No forms found to monitor for persistence');
        return;
    }
    
    // Initialize each form
    formsToMonitor.forEach(form => {
        initializeFormMonitoring(form);
    });
    
    console.log(`Form persistence initialized for ${formsToMonitor.length} form(s)`);
}

/**
 * Find forms that should be monitored for persistence
 * @returns {HTMLFormElement[]} Array of forms to monitor
 */
function findFormsToMonitor() {
    const forms = [];
    
    // Primary target: Submit Vendor form
    const submitVendorForm = document.getElementById(SUBMIT_VENDOR_FORM_ID) ||
                            document.querySelector('form[data-form-type="submit-vendor"]') ||
                            document.querySelector('form.submit-vendor-form');
    
    if (submitVendorForm) {
        forms.push(submitVendorForm);
    }
    
    // Secondary: Look for forms on submit-vendor page
    if (isSubmitVendorPage()) {
        const pageForm = document.querySelector('form:not([data-no-persist])');
        if (pageForm && !forms.includes(pageForm)) {
            forms.push(pageForm);
        }
    }
    
    // Tertiary: Any form with data-persist attribute
    const persistentForms = document.querySelectorAll('form[data-persist="true"]');
    persistentForms.forEach(form => {
        if (!forms.includes(form)) {
            forms.push(form);
        }
    });
    
    return forms;
}

/**
 * Check if current page is the submit vendor page
 * @returns {boolean} True if on submit-vendor page
 */
function isSubmitVendorPage() {
    const path = window.location.pathname;
    return path === SUBMIT_VENDOR_PAGE_PATH || 
           path.endsWith(SUBMIT_VENDOR_PAGE_PATH) || 
           path.includes('submit-vendor');
}

/**
 * Initialize monitoring for a specific form
 * @param {HTMLFormElement} form - Form to monitor
 */
function initializeFormMonitoring(form) {
    const formId = getFormIdentifier(form);
    
    console.log(`Initializing persistence for form: ${formId}`);
    
    // Restore saved data
    restoreFormData(form, formId);
    
    // Set up auto-save monitoring
    setupFormMonitoring(form, formId);
    
    // Set up submission handling
    setupSubmissionHandling(form, formId);
    
    formStates.set(formId, {
        form,
        lastSaveTime: Date.now(),
        isMonitoring: true
    });
}

/**
 * Get a unique identifier for a form
 * @param {HTMLFormElement} form - Form element
 * @returns {string} Unique identifier
 */
function getFormIdentifier(form) {
    return form.id || 
           form.getAttribute('data-form-id') ||
           form.className.replace(/\s+/g, '_') ||
           `form_${Array.from(document.forms).indexOf(form)}`;
}

/**
 * Restore saved form data from sessionStorage
 * @param {HTMLFormElement} form - Form to restore
 * @param {string} formId - Form identifier
 */

function getElementsByKey(form, key) {
  // 1) try by name (works for groups too)
  const byName = form.elements[key];
  if (byName) return byName; // could be a single element or RadioNodeList

  // 2) fallback by id
  try {
    const nodeList = form.querySelectorAll('#' + CSS.escape(key));
    if (nodeList.length === 1) return nodeList[0];
    if (nodeList.length > 1) return nodeList; // rare, but handle anyway
  } catch {}
  return null;
}

function restoreFormData(form, formId) {
    try {
        const storageKey = STORAGE_KEY_PREFIX + formId;
        const savedData = get(storageKey);
        
        if (!savedData || typeof savedData !== 'object') {
            console.log(`No saved data found for form: ${formId}`);
            return;
        }
        
        console.log(`Restoring form data for: ${formId}`);
        
        let restoredCount = 0;
        
        // Restore each saved field
        Object.entries(savedData).forEach(([fieldName, fieldData]) => {
            const elements = getElementsByKey(form, fieldName);
            
            if (elements) {
                if (elements.nodeType) {
                    // Single element
                    if (restoreFieldValue(elements, fieldData)) {
                        restoredCount++;
                    }
                } else {
                    // NodeList (radio buttons or checkboxes with same name)
                    Array.from(elements).forEach(element => {
                        if (restoreFieldValue(element, fieldData)) {
                            restoredCount++;
                        }
                    });
                }
            }
        });
        
        console.log(`Restored ${restoredCount} field(s) for form: ${formId}`);
        
        // Dispatch change events to trigger any form validation or UI updates
        triggerFormUpdateEvents(form);
        
    } catch (error) {
        console.error(`Error restoring form data for ${formId}:`, error);
    }
}

/**
 * Restore value for a specific form field
 * @param {HTMLElement} element - Form element
 * @param {Object} fieldData - Saved field data
 * @returns {boolean} True if value was restored
 */
function restoreFieldValue(element, fieldData) {
    try {
        const tagName = element.tagName.toLowerCase();
        const type = element.type ? element.type.toLowerCase() : '';
        
        switch (tagName) {
            case 'input':
                switch (type) {
                    case 'checkbox':
                        if (typeof fieldData.checked === 'boolean') {
                            element.checked = fieldData.checked;
                            return true;
                        }
                        break;
                        
                    case 'radio':
                        if (typeof fieldData.checked === 'boolean' && 
                            element.value === fieldData.value) {
                            element.checked = fieldData.checked;
                            return true;
                        }
                        break;
                        
                    case 'file':
                        // Cannot restore file contents for security reasons
                        // But we can show the filename if it was saved
                        if (fieldData.filename) {
                            console.log(`File input ${element.name} previously had: ${fieldData.filename}`);
                        }
                        break;
                        
                    default:
                        // Text, email, tel, url, password, etc.
                        if (fieldData.value !== undefined) {
                            element.value = fieldData.value;
                            return true;
                        }
                        break;
                }
                break;
                
            case 'textarea':
                if (fieldData.value !== undefined) {
                    element.value = fieldData.value;
                    return true;
                }
                break;
                
            case 'select':
                if (fieldData.value !== undefined) {
                    element.value = fieldData.value;
                    // For multi-select, restore selectedOptions if available
                    if (element.multiple && fieldData.selectedValues) {
                        Array.from(element.options).forEach(option => {
                            option.selected = fieldData.selectedValues.includes(option.value);
                        });
                    }
                    return true;
                }
                break;
        }
        
        return false;
        
    } catch (error) {
        console.error('Error restoring field value:', error);
        return false;
    }
}

/**
 * Set up form field monitoring for auto-save
 * @param {HTMLFormElement} form - Form to monitor
 * @param {string} formId - Form identifier
 */
function setupFormMonitoring(form, formId) {
    // Get all form elements that can have values
    const monitoredElements = form.querySelectorAll(
        'input:not([type="submit"]):not([type="button"]):not([type="reset"]), textarea, select'
    );
    
    // Add event listeners for different field types
    monitoredElements.forEach(element => {
        const events = getRelevantEvents(element);
        
        events.forEach(eventType => {
            element.addEventListener(eventType, () => {
                scheduleFormSave(form, formId);
            });
        });
    });
    
    console.log(`Monitoring ${monitoredElements.length} elements in form: ${formId}`);
}

/**
 * Get relevant events for a form element
 * @param {HTMLElement} element - Form element
 * @returns {string[]} Array of event names
 */
function getRelevantEvents(element) {
    const tagName = element.tagName.toLowerCase();
    const type = element.type ? element.type.toLowerCase() : '';
    
    const events = ['change']; // All elements get change event
    
    // Add input event for text-like inputs
    if (tagName === 'textarea' || 
        (tagName === 'input' && ['text', 'email', 'tel', 'url', 'search', 'password'].includes(type))) {
        events.push('input');
    }
    
    // Add keydown for additional responsiveness
    if (tagName === 'textarea' || 
        (tagName === 'input' && !['checkbox', 'radio', 'file', 'submit', 'button', 'reset'].includes(type))) {
        events.push('keydown');
    }
    
    return events;
}

/**
 * Schedule a debounced form save
 * @param {HTMLFormElement} form - Form to save
 * @param {string} formId - Form identifier
 */
function scheduleFormSave(form, formId) {
    // Clear existing timeout
    if (saveTimeouts.has(formId)) {
        clearTimeout(saveTimeouts.get(formId));
    }
    
    // Set new timeout
    const timeoutId = setTimeout(() => {
        saveFormData(form, formId);
        saveTimeouts.delete(formId);
    }, AUTO_SAVE_DELAY);
    
    saveTimeouts.set(formId, timeoutId);
}

/**
 * Save form data to sessionStorage
 * @param {HTMLFormElement} form - Form to save
 * @param {string} formId - Form identifier
 */
function saveFormData(form, formId) {
    try {
        const formData = {};
        const formElements = form.elements;
        
        // Collect data from all form elements
        for (let i = 0; i < formElements.length; i++) {
            const element = formElements[i];
            if (isIgnoredElement(element)) continue;
            const key = (element.name || element.id || '').trim();
            if (!key) continue; // skip elements without a stable key

            const fieldData = getFieldData(element);
            if (fieldData !== null) {
                formData[key] = fieldData;
            }
        }
        
        // Save to sessionStorage
        const storageKey = STORAGE_KEY_PREFIX + formId;
        const saveSuccess = set(storageKey, formData);
        
        if (saveSuccess) {
            console.log(`Form data saved for: ${formId}`);
            
            // Update state
            const formState = formStates.get(formId);
            if (formState) {
                formState.lastSaveTime = Date.now();
            }
        } else {
            console.warn(`Failed to save form data for: ${formId}`);
        }
        
    } catch (error) {
        console.error(`Error saving form data for ${formId}:`, error);
    }
}

/**
 * Get data from a form field
 * @param {HTMLElement} element - Form element
 * @returns {Object|null} Field data or null if should be ignored
 */
function getFieldData(element) {
    const tagName = element.tagName.toLowerCase();
    const type = element.type ? element.type.toLowerCase() : '';
    
    switch (tagName) {
        case 'input':
            switch (type) {
                case 'checkbox':
                    return { checked: element.checked, value: element.value };
                    
                case 'radio':
                    return { checked: element.checked, value: element.value };
                    
                case 'file':
                    // Store filename only, not file content (security)
                    const filename = element.files && element.files[0] ? element.files[0].name : '';
                    return filename ? { filename } : null;
                    
                case 'submit':
                case 'button':
                case 'reset':
                    return null; // Don't save these
                    
                default:
                    return { value: element.value };
            }
            
        case 'textarea':
            return { value: element.value };
            
        case 'select':
            if (element.multiple) {
                const selectedValues = Array.from(element.selectedOptions).map(option => option.value);
                return { value: element.value, selectedValues };
            } else {
                return { value: element.value };
            }
            
        default:
            return null;
    }
}

/**
 * Check if element should be ignored for persistence
 * @param {HTMLElement} element - Form element
 * @returns {boolean} True if should be ignored
 */
function isIgnoredElement(element) {
    // Skip elements explicitly marked to ignore
    if (element.hasAttribute('data-no-persist') || 
        element.classList.contains('no-persist')) {
        return true;
    }
    
    // Skip password fields for security (unless explicitly allowed)
    if (element.type === 'password' && !element.hasAttribute('data-allow-persist')) {
        return true;
    }
    
    // Skip submit/button/reset elements
    const type = element.type ? element.type.toLowerCase() : '';
    if (['submit', 'button', 'reset'].includes(type)) {
        return true;
    }
    
    return false;
}

/**
 * Set up form submission handling to clear drafts
 * @param {HTMLFormElement} form - Form element
 * @param {string} formId - Form identifier
 */
function setupSubmissionHandling(form, formId) {
    form.addEventListener('submit', (event) => {
        console.log(`Form submission detected for: ${formId}`);
        
        // Clear the draft after a short delay to allow form processing
        setTimeout(() => {
            clearFormDraft(formId);
        }, 1000);
    });
    
    // Also listen for successful AJAX submissions
    // This is a generic approach - specific implementations may override
    window.addEventListener('formSubmissionSuccess', (event) => {
        if (event.detail && event.detail.formId === formId) {
            clearFormDraft(formId);
        }
    });
}

/**
 * Clear saved draft for a specific form
 * @param {string} formId - Form identifier
 */
export function clearFormDraft(formId) {
    try {
        const storageKey = STORAGE_KEY_PREFIX + formId;
        const deleted = del(storageKey);
        
        if (deleted) {
            console.log(`Form draft cleared for: ${formId}`);
        }
        
        // Clear any pending save timeouts
        if (saveTimeouts.has(formId)) {
            clearTimeout(saveTimeouts.get(formId));
            saveTimeouts.delete(formId);
        }
        
    } catch (error) {
        console.error(`Error clearing form draft for ${formId}:`, error);
    }
}

/**
 * Clear all form drafts
 */
export function clearAllFormDrafts() {
    try {
        const allKeys = Object.keys(sessionStorage);
        const draftKeys = allKeys.filter(key => key.startsWith(STORAGE_KEY_PREFIX));
        
        draftKeys.forEach(key => {
            del(key.substring(STORAGE_KEY_PREFIX.length));
        });
        
        console.log(`Cleared ${draftKeys.length} form draft(s)`);
        
    } catch (error) {
        console.error('Error clearing all form drafts:', error);
    }
}

/**
 * Trigger update events on form to refresh UI
 * @param {HTMLFormElement} form - Form to update
 */
function triggerFormUpdateEvents(form) {
    try {
        // Dispatch a custom event that form scripts can listen for
        const updateEvent = new CustomEvent('formDataRestored', {
            detail: { form }
        });
        form.dispatchEvent(updateEvent);
        
        // Also dispatch change events on the form
        const changeEvent = new Event('change', { bubbles: true });
        form.dispatchEvent(changeEvent);
        
    } catch (error) {
        console.error('Error triggering form update events:', error);
    }
}

/**
 * Get information about saved form drafts
 * @returns {Object} Information about saved drafts
 */
export function getDraftInfo() {
    try {
        const allKeys = Object.keys(sessionStorage || {});
        const draftKeys = allKeys.filter(key => key.startsWith(STORAGE_KEY_PREFIX));
        
        const drafts = {};
        draftKeys.forEach(key => {
            const formId = key.substring(STORAGE_KEY_PREFIX.length);
            const data = get(key);
            if (data) {
                drafts[formId] = {
                    fieldCount: Object.keys(data).length,
                    lastModified: new Date().toISOString(), // Approximate
                    size: JSON.stringify(data).length
                };
            }
        });
        
        return {
            count: draftKeys.length,
            drafts
        };
        
    } catch (error) {
        console.error('Error getting draft info:', error);
        return { count: 0, drafts: {} };
    }
}

// Export default object for convenience
export default {
    init: initFormPersistence,
    clear: clearFormDraft,
    clearAll: clearAllFormDrafts,
    info: getDraftInfo
};
