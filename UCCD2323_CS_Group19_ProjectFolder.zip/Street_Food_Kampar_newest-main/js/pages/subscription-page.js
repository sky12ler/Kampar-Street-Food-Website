/**
 * Kampar Street Food - Subscription Page JavaScript
 * Handles pricing toggle, plan selection, and subscription management with fake FPX flow
 */

const subscriptionPage = {
    // Initialize subscription page
    init: function() {
        this.handleReturnFromPayment();
        this.setupBillingToggle();
        this.setupEventHandlers();
        
        this.initializeAnimations();
    },

  
    // Generic toast for feedback
showToast: function(message, type = 'info') {
    const colors = {
        success: 'bg-success text-white',
        warning: 'bg-warning text-dark',
        error: 'bg-danger text-white',
        info: 'bg-info text-dark'
    };
    
    const toastHtml = `
        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header ${colors[type] || colors.info}">
                    <strong class="me-auto">${type.toUpperCase()}</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">${message}</div>
            </div>
        </div>
    `;
    $('body').append(toastHtml);
    setTimeout(() => $('.toast-container').remove(), 4000);
},

    // Add this function to handle returning from payment
handleReturnFromPayment: function() {
    const params = new URLSearchParams(window.location.search);
    const status = params.get('status');
    
    if (status === 'cancelled') {
        this.showToast('Payment was cancelled. No subscription was activated.', 'warning');
        // Clean URL to prevent repeating the message
        window.history.replaceState({}, document.title, window.location.pathname);
    }
},

    // Setup billing toggle (monthly/annual)
    setupBillingToggle: function() {
        const billingToggle = $('#billingToggle');
        
        billingToggle.change(() => {
            const isAnnual = billingToggle.is(':checked');
            this.updatePricing(isAnnual);
        });
    },

    // Update pricing display based on billing period
    updatePricing: function(isAnnual) {
        const monthlyPrices = $('.monthly-price');
        const annualPrices = $('.annual-price');
        const annualSavings = $('.annual-savings');

        if (isAnnual) {
            monthlyPrices.addClass('d-none');
            annualPrices.removeClass('d-none');
            annualSavings.removeClass('d-none');
            
            annualPrices.addClass('price-highlight');
            setTimeout(() => annualPrices.removeClass('price-highlight'), 1000);
        } else {
            annualPrices.addClass('d-none');
            monthlyPrices.removeClass('d-none');
            annualSavings.addClass('d-none');
            
            monthlyPrices.addClass('price-highlight');
            setTimeout(() => monthlyPrices.removeClass('price-highlight'), 1000);
        }
    },

    // Setup event handlers
    setupEventHandlers: function() {
        // Plan selection
        window.selectPlan = (planType) => this.selectPlan(planType);

        // Smooth scroll for CTA buttons
        $('a[href^="#"]').click(function(e) {
            const target = $(this.getAttribute('href'));
            if (target.length) {
                e.preventDefault();
                $('html, body').animate({ scrollTop: target.offset().top - 100 }, 600);
            }
        });
    },

    // Handle plan selection
    selectPlan: function(planType) {
        const isAnnual = $('#billingToggle').is(':checked');
        const planData = this.getPlanData(planType, isAnnual);
        
        console.log(`Selected plan: ${planType}`, planData);
        this.showPlanSelection(planType, planData);
        this.showPaymentModal(planData);
    },

    // Get plan data
    getPlanData: function(planType, isAnnual) {
        const plans = {
            basic: {
                name: 'Food Explorer',
                monthlyPrice: 9,
                annualPrice: 7,
                features: [
                    'Access to 50+ exclusive vendors',
                    'Monthly food discovery newsletter',
                    'Basic vendor recommendations',
                    'Mobile app access',
                    'Community forum access'
                ]
            },
            premium: {
                name: 'Foodie Pro',
                monthlyPrice: 19,
                annualPrice: 15,
                features: [
                    'Everything in Explorer',
                    'Access to 150+ premium vendors',
                    'Priority reservations & bookings',
                    '10% discount at partner vendors',
                    'Weekly food tours & events',
                    'Personal food concierge service',
                    'Advanced filtering & search'
                ]
            },
            elite: {
                name: 'Culinary Elite',
                monthlyPrice: 39,
                annualPrice: 31,
                features: [
                    'Everything in Pro',
                    'Unlimited access to all vendors',
                    'VIP dining experiences & tastings',
                    '20% discount + exclusive menus',
                    'Private chef collaborations',
                    '24/7 premium support',
                    'Early access to new features'
                ]
            }
        };

        const plan = plans[planType];
        return {
            ...plan,
            type: planType,
            billing: isAnnual ? 'annual' : 'monthly',
            price: isAnnual ? plan.annualPrice : plan.monthlyPrice,
            totalAnnual: isAnnual ? plan.annualPrice * 12 : plan.monthlyPrice * 12,
            savings: isAnnual ? (plan.monthlyPrice - plan.annualPrice) * 12 : 0
        };
    },

    // Show plan selection feedback
    showPlanSelection: function(planType, planData) {
        const planCard = $(`.pricing-card:contains("${planData.name}")`).closest('.card');
        planCard.addClass('plan-selected');
        $('.pricing-card').not(planCard).removeClass('plan-selected');
        setTimeout(() => planCard.removeClass('plan-selected'), 2000);
    },

    // Show payment modal (demo, redirect to fake FPX)
    showPaymentModal: function(planData) {
        const modalHtml = `
            <div class="modal fade" id="paymentModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-credit-card me-2"></i>
                                Subscribe to ${planData.name}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h6 class="fw-bold">Plan Summary</h6>
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <span>${planData.name}</span>
                                                <span class="fw-bold">RM${planData.price}/month</span>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <small class="text-muted">Billing</small>
                                                <small class="text-muted">${planData.billing}</small>
                                            </div>
                                            ${planData.savings > 0 ? `
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <small class="text-success">Annual Savings</small>
                                                    <small class="text-success">RM${planData.savings}</small>
                                                </div>
                                            ` : ''}
                                            <hr>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <strong>Total</strong>
                                                <strong>RM${planData.billing === 'annual' ? planData.price * 12 : planData.price}</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        <strong>Demo Mode</strong><br>
                                        Click "Complete Subscription" to simulate a payment via FPX.
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button class="btn btn-primary btn-lg" onclick="subscriptionPage.processPayment('${planData.type}', event)">
                                            <i class="fas fa-lock me-2"></i>
                                            Complete Subscription
                                        </button>
                                        <button class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                            Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#paymentModal').remove();
        $('body').append(modalHtml);
        const modal = new bootstrap.Modal(document.getElementById('paymentModal'));
        modal.show();
        $('#paymentModal').on('hidden.bs.modal', function() { $(this).remove(); });
    },

    // Process payment (redirect to fake FPX)
    processPayment: function(planType, event) {
        event.preventDefault();
        window.location.href = `fake-fpx.html?plan=${planType}`;
    },

  
// Replace the showSubscriptionSuccess function in subscription-page.js
showSubscriptionSuccess: function(planType, isAnnual = false) {
    // Use auth system to update subscription
    if (typeof updateUserSubscription === 'function') {
        updateUserSubscription(planType, true);
    } else {
        // Fallback to localStorage
        const user = JSON.parse(localStorage.getItem('currentUser') || '{}');
        user.isSubscribed = true;
        user.tier = planType;
        localStorage.setItem('currentUser', JSON.stringify(user));
    }

    const planData = this.getPlanData(planType, isAnnual);
    const successToast = `
        <div class="toast-container position-fixed bottom-0 end-0 p-3">
            <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header bg-success text-white">
                    <i class="fas fa-check-circle me-2"></i>
                    <strong class="me-auto">Subscription Active!</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    Welcome to ${planData.name}! Check your email for confirmation details.
                </div>
            </div>
        </div>
    `;
    $('body').append(successToast);
    setTimeout(() => $('.toast-container').remove(), 5000);
},


    // Initialize scroll animations
    initializeAnimations: function() {
        const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) entry.target.classList.add('animate-in');
            });
        }, observerOptions);

        $('.pricing-card, .table-responsive').each(function() { observer.observe(this); });
    },

    
};

// Initialize when DOM is ready
$(document).ready(function() {
    subscriptionPage.init();
    
});

// Export for global access
window.subscriptionPage = subscriptionPage;
