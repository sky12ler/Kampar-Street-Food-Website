/**
 * Kampar Street Food - Vendor Details Page JavaScript
 * Handles vendor information display, photo carousel, map, and related functionality
 */


let currentVendor = null;
let photoSwiper = null;
let vendorMap = null;

const vendorDetails = {
    // Initialize vendor details page
    init: function() {
        this.loadVendorFromURL();
       
    },

    // Load vendor data from URL parameter
    loadVendorFromURL: function() {
        const urlParams = new URLSearchParams(window.location.search);
        const vendorId = urlParams.get('id');
        
        if (!vendorId) {
            this.showError();
            return;
        }

    
        currentVendor = dataManager.getVendorById(vendorId);
        
        if (!currentVendor) {
            this.showError();
            return;
        }

        this.displayVendor(currentVendor);
        this.hideLoading();
        this.showContent();
        this.setupEventHandlers();
    },
    

    // Display vendor information
    displayVendor: function(vendor) {
        // Update page title and meta
        document.title = `${vendor.name} - Kampar Street Food`;
        $('#page-title').attr('content', `${vendor.name} - Kampar Street Food`);
        $('#page-description').attr('content', vendor.description);

        // Basic information
        $('#vendor-name').text(vendor.name);
        $('#vendor-breadcrumb').text(vendor.name);
        $('#vendor-description').text(vendor.description);
        $('#full-description').text(vendor.description);
        $('#vendor-category').text(vendor.category);
        $('#vendor-price').text(vendor.priceBand);
        $('#vendor-address').text(vendor.address);
        $('#vendor-distance').text(vendor.distance);

        // Verified badge
        if (vendor.isVerified) {
            $('#vendor-verified').show();
        }

        // Rating
        const ratingHtml = `
            ${utils.generateStarRating(vendor.rating, '1.2rem')}
            <span class="rating-text ms-2 fs-5">${vendor.rating}</span>
            <span class="rating-count text-muted ms-1">(${vendor.reviewsCount} reviews)</span>
        `;
        $('#vendor-rating').html(ratingHtml);

        // Status
        const isOpen = utils.isVendorOpen(vendor);
        const statusHtml = isOpen 
            ? '<span class="badge badge-success fs-6">Open Now</span>'
            : '<span class="badge text-danger fw-bold fs-6" data-bs-toggle="tooltip" title="Currently closed - check operating hours for opening times">• Closed</span>';
        $('#vendor-status').html(statusHtml);

        // Tags
        const tagsHtml = vendor.tags.map(tag => 
            `<span class="badge bg-light text-dark me-2 mb-2">${tag}</span>`
        ).join('');
        $('#vendor-tags').html(tagsHtml);

        // Contact information
        if (vendor.phone) {
            $('#phone-link').attr('href', `tel:${vendor.phone}`).text(vendor.phone);
            $('#phone-info').show();
        }

        // Photo gallery
        this.setupPhotoGallery(vendor.photos);
        
        // Operating hours
        this.displayOperatingHours(vendor.hours);
        
        // Menu
        this.displayMenu(vendor.menu);
        
        // Reviews
        this.displayReviews(vendor.reviews);
        
        // Social media
        this.displaySocialMedia(vendor.socialMedia);
        
        // Map
        this.initializeMap(vendor.coordinates);
        
        // Navigation buttons
        this.setupNavigationButtons(vendor);
        
        // Related vendors
        this.displayRelatedVendors(vendor);

        // Only set vendor ID, let StateManager handle favorite UI
        $('#main-favorite-btn').attr('data-vendor-id', vendor.id);

    },

    // Setup photo gallery carousel
    setupPhotoGallery: function(photos) {
        const photoGallery = $('#photo-gallery');
        photoGallery.empty();

        if (!photos || photos.length === 0) {
            // Default placeholder
            photoGallery.html(`
                <div class="swiper-slide">
                    <img src="/images/placeholder-food.jpg" alt="No photos available" class="img-fluid" style="width: 100%; height: 400px; object-fit: cover;">
                </div>
            `);
        } else {
            photos.forEach(photo => {
                photoGallery.append(`
                    <div class="swiper-slide">
                        <img src="${photo}" alt="${currentVendor.name}" class="img-fluid" 
                             style="width: 100%; height: 400px; object-fit: cover; cursor: pointer;"
                             onclick="vendorDetails.openPhotoModal('${photo}')">
                    </div>
                `);
            });
        }

        // Initialize Swiper
        photoSwiper = new Swiper('.photo-swiper', {
            loop: photos && photos.length > 1,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            autoplay: photos && photos.length > 1 ? {
                delay: 4000,
                disableOnInteraction: false,
            } : false,
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            }
        });
    },

    // Open photo in modal (simplified)
    openPhotoModal: function(photoSrc) {
        // Create and show modal
        const modal = $(`
            <div class="modal fade" tabindex="-1">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content bg-transparent border-0">
                        <div class="modal-body p-0">
                            <img src="${photoSrc}" alt="${currentVendor.name}" class="img-fluid w-100">
                            <button type="button" class="btn-close position-absolute top-0 end-0 m-3 btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        $('body').append(modal);
        const bsModal = new bootstrap.Modal(modal[0]);
        bsModal.show();
        
        modal.on('hidden.bs.modal', function() {
            modal.remove();
        });
    },

    // Display operating hours
    displayOperatingHours: function(hours) {
        const hoursContainer = $('#operating-hours');
        hoursContainer.empty();

        if (!hours || hours.length === 0) {
            hoursContainer.html('<p class="text-muted">Hours not available</p>');
            return;
        }

        const currentDay = new Date().toLocaleDateString('en-US', { weekday: 'long' });

        hours.forEach(dayHours => {
            const isToday = dayHours.day === currentDay;
            const isOpen = utils.isVendorOpen(currentVendor) && isToday;
            
            const dayClass = isToday ? 'fw-bold text-primary' : '';
            const statusClass = isOpen ? 'text-success' : '';
            
            hoursContainer.append(`
                <div class="d-flex justify-content-between align-items-center mb-2 ${dayClass}">
                    <span>${dayHours.day}</span>
                    <span class="${statusClass}">
                        ${utils.formatTime(dayHours.open)} - ${utils.formatTime(dayHours.close)}
                        ${isOpen ? ' (Open Now)' : ''}
                    </span>
                </div>
            `);
        });
    },

    // Display menu items
    displayMenu: function(menu) {
        const menuContainer = $('#menu-items');
        const noMenuContainer = $('#no-menu');
        
        if (!menu || menu.length === 0) {
            noMenuContainer.show();
            return;
        }

        menuContainer.empty();
        menu.forEach(item => {
            menuContainer.append(`
                <div class="col-md-6 col-lg-4">
                    <div class="card menu-item-card h-100">
                        ${item.image ? `
                            <img src="${item.image}" class="card-img-top" alt="${item.name}" 
                                 style="height: 200px; object-fit: cover;">
                        ` : ''}
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-0">${item.name}</h6>
                                <span class="badge badge-primary">${item.price}</span>
                            </div>
                            ${item.description ? `<p class="card-text text-muted small">${item.description}</p>` : ''}
                        </div>
                    </div>
                </div>
            `);
        });
    },

    // Display reviews
    displayReviews: function(reviews) {
        const reviewsContainer = $('#reviews-container');
        const noReviewsContainer = $('#no-reviews');
        
        // Load saved reviews from localStorage and merge with existing reviews
        const savedReviews = this.loadSavedReviews(currentVendor.id);
        const allReviews = [...savedReviews, ...(reviews || [])];
        
        // Remove duplicates based on review ID
        const uniqueReviews = allReviews.filter((review, index, self) =>
            index === self.findIndex(r => r.id === review.id)
        );
        
        // Sort by date (newest first)
        uniqueReviews.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        if (uniqueReviews.length === 0) {
            noReviewsContainer.show();
            return;
        } else {
            noReviewsContainer.hide();
        }

        reviewsContainer.empty();
        
        // Reviews summary
        const averageRating = currentVendor.rating;
        const totalReviews = uniqueReviews.length;
        
        reviewsContainer.append(`
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="text-center">
                                <div class="display-4 fw-bold text-primary">${averageRating}</div>
                                <div class="rating mb-2">
                                    ${utils.generateStarRating(averageRating, '1.2rem')}
                                </div>
                                <p class="text-muted">Based on ${totalReviews} reviews</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <button class="btn btn-primary w-100" id="writeReviewBtn">
                                <i class="fas fa-plus me-2"></i>Write a Review
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `);

        // Individual reviews
        uniqueReviews.forEach(review => {
            const isNewReview = savedReviews.some(saved => saved.id === review.id);
            reviewsContainer.append(`
                <div class="card mb-3 ${isNewReview ? 'border-success' : ''}">
                    <div class="card-body">
                        <div class="d-flex align-items-start">
                            <img src="${review.avatar || '/images/placeholder-avatar.jpg'}" 
                                 alt="${review.author}" class="rounded-circle me-3" width="48" height="48">
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <h6 class="mb-0">
                                            ${review.author}
                                            ${isNewReview ? '<span class="badge bg-success ms-2">New</span>' : ''}
                                        </h6>
                                        <div class="rating">
                                            ${utils.generateStarRating(review.rating, '0.9rem')}
                                        </div>
                                    </div>
                                    <small class="text-muted">${utils.formatDate(review.date)}</small>
                                </div>
                                <p class="mb-0">${review.comment}</p>
                            </div>
                        </div>
                    </div>
                </div>
            `);
        });
    },

    // Display social media links
    displaySocialMedia: function(socialMedia) {
        if (!socialMedia) return;

        const socialContainer = $('#social-links');
        const socialCard = $('#social-card');
        
        socialContainer.empty();
        let hasSocialLinks = false;

        if (socialMedia.facebook) {
            hasSocialLinks = true;
            socialContainer.append(`
                <a href="${socialMedia.facebook}" target="_blank" class="btn btn-outline-primary">
                    <i class="fab fa-facebook-f me-2"></i>Facebook
                </a>
            `);
        }

        if (socialMedia.instagram) {
            hasSocialLinks = true;
            socialContainer.append(`
                <a href="${socialMedia.instagram}" target="_blank" class="btn btn-outline-danger">
                    <i class="fab fa-instagram me-2"></i>Instagram
                </a>
            `);
        }

        if (socialMedia.whatsapp) {
            hasSocialLinks = true;
            socialContainer.append(`
                <a href="https://wa.me/${socialMedia.whatsapp}" target="_blank" class="btn btn-outline-success">
                    <i class="fab fa-whatsapp me-2"></i>WhatsApp
                </a>
            `);
        }

        if (hasSocialLinks) {
            socialCard.show();
        }
    },

    // Initialize map
    initializeMap: function(coordinates) {
        if (!coordinates) return;

        // Initialize map when location tab is shown
        $('#location-tab').on('shown.bs.tab', () => {
            if (!vendorMap) {
                vendorMap = L.map('vendor-map').setView([coordinates.lat, coordinates.lng], 16);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                }).addTo(vendorMap);
                
                // Add marker
                const marker = L.marker([coordinates.lat, coordinates.lng]).addTo(vendorMap);
                marker.bindPopup(`
                    <div class="text-center">
                        <h6 class="mb-2">${currentVendor.name}</h6>
                        <p class="mb-2 small">${currentVendor.address}</p>
                        <button class="btn btn-sm btn-primary" onclick="vendorDetails.getDirections()">
                            Get Directions
                        </button>
                    </div>
                `).openPopup();
            } else {
                // Refresh map
                setTimeout(() => vendorMap.invalidateSize(), 100);
            }
        });
    },

    // Setup navigation and action buttons
    setupNavigationButtons: function(vendor) {
        // Get directions button
        $('#get-directions-btn').click(() => {
            this.getDirections();
        });

        // Google Maps button
        $('#google-maps-btn').attr('href', 
            `https://www.google.com/maps/search/?api=1&query=${vendor.coordinates.lat},${vendor.coordinates.lng}`
        );

        // Waze button
        $('#waze-btn').attr('href', 
            `https://waze.com/ul?ll=${vendor.coordinates.lat},${vendor.coordinates.lng}&navigate=yes`
        );

        // WhatsApp location sharing
        $('#whatsapp-location-btn').click(() => {
            const message = `Check out ${vendor.name} at ${vendor.address}! https://www.google.com/maps/search/?api=1&query=${vendor.coordinates.lat},${vendor.coordinates.lng}`;
            window.open(`https://wa.me/?text=${encodeURIComponent(message)}`);
        });

        // Share buttons
        $('.share-facebook').attr('data-url', window.location.href).attr('data-title', vendor.name);
        $('.share-twitter').attr('data-url', window.location.href).attr('data-title', `Check out ${vendor.name}!`);
        $('.share-whatsapp').attr('data-url', window.location.href).attr('data-title', `Check out ${vendor.name}!`);
        $('.share-native').attr('data-url', window.location.href).attr('data-title', vendor.name);
    },

    // Get directions to vendor
    getDirections: function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const userLat = position.coords.latitude;
                const userLng = position.coords.longitude;
                const vendorLat = currentVendor.coordinates.lat;
                const vendorLng = currentVendor.coordinates.lng;
                
                const url = `https://www.google.com/maps/dir/${userLat},${userLng}/${vendorLat},${vendorLng}`;
                window.open(url, '_blank');
            }, () => {
                // Fallback if geolocation fails
                const url = `https://www.google.com/maps/search/?api=1&query=${currentVendor.coordinates.lat},${currentVendor.coordinates.lng}`;
                window.open(url, '_blank');
            });
        } else {
            // Fallback for browsers without geolocation
            const url = `https://www.google.com/maps/search/?api=1&query=${currentVendor.coordinates.lat},${currentVendor.coordinates.lng}`;
            window.open(url, '_blank');
        }
    },

    // Display related vendors
    displayRelatedVendors: function(currentVendor) {
        if (appState.vendors.length < 2) return;

        // Find vendors in same category (excluding current)
        const relatedVendors = appState.vendors
            .filter(v => v.id !== currentVendor.id && v.category === currentVendor.category)
            .sort((a, b) => b.rating - a.rating)
            .slice(0, 3);

        // If not enough from same category, add highest rated vendors
        if (relatedVendors.length < 3) {
            const additionalVendors = appState.vendors
                .filter(v => v.id !== currentVendor.id && !relatedVendors.find(rv => rv.id === v.id))
                .sort((a, b) => b.rating - a.rating)
                .slice(0, 3 - relatedVendors.length);
            
            relatedVendors.push(...additionalVendors);
        }

        const relatedContainer = $('#related-vendors');
        relatedContainer.empty();

        relatedVendors.forEach((vendor, index) => {
            const vendorCard = this.createRelatedVendorCard(vendor, index);
            relatedContainer.append(vendorCard);
        });

        // Initialize favorites UI for related vendors
        if (typeof initializeTooltips !== 'undefined') {
    initializeTooltips();
}
    },

    // Create related vendor card HTML (identical to favorites page styling)
    createRelatedVendorCard: function(vendor, index) {
        const isOpen = utils.isVendorOpen(vendor);
        const statusBadge = isOpen 
            ? '<span class="badge badge-success">Open</span>'
            : '<span class="badge text-danger fw-bold" data-bs-toggle="tooltip" title="Currently closed - check vendor details for operating hours">• Closed</span>';

        const mainPhoto = vendor.photos && vendor.photos.length > 0 
            ? vendor.photos[0] 
            : '/images/placeholder-food.jpg';

        return `
            <div class="col-md-6 col-lg-4 vendor-item">
                <div class="card favorite-vendor-card h-100" onclick="window.location.href='vendor-details.html?id=${vendor.id}'" style="cursor: pointer; ${!isOpen ? 'opacity: 0.9;' : ''}">
                    <div class="position-relative">
                        <img src="${mainPhoto}" class="card-img-top" alt="${vendor.name}" 
                             loading="lazy" style="height: 200px; object-fit: cover;">
                        <button class="btn btn-icon favorite-btn position-absolute top-0 end-0 m-2 bg-white shadow-sm" 
                                data-vendor-id="${vendor.id}" 
                                onclick="event.stopPropagation();" 
                                title="Add to favorites">
                            <i class="far fa-heart"></i>
                        </button>
                        <div class="position-absolute bottom-0 start-0 m-2">${statusBadge}</div>
                        ${vendor.isVerified ? '<div class="position-absolute top-0 start-0 m-2"><i class="fas fa-check-circle text-primary bg-white rounded-circle"></i></div>' : ''}
                    </div>
                    
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">${vendor.name}</h5>
                        <p class="card-text text-muted flex-grow-1">${utils.truncateText(vendor.description, 100)}</p>
                        
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="rating">
                                    ${utils.generateStarRating(vendor.rating, '0.9rem')}
                                    <span class="rating-text ms-1">${vendor.rating}</span>
                                    <span class="rating-count text-muted">(${vendor.reviewsCount})</span>
                                </div>
                                <span class="badge badge-warning">${vendor.priceBand}</span>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    ${vendor.distance}
                                </small>
                                <span class="badge badge-secondary">${vendor.category}</span>
                            </div>
                            
                            <div class="vendor-tags">
                                ${vendor.tags.slice(0, 3).map(tag => 
                                    `<span class="badge bg-light text-dark me-1 mb-1">${tag}</span>`
                                ).join('')}
                            </div>
                        </div>

                        <div class="d-flex gap-2 mt-auto">
                            <button class="btn btn-primary flex-grow-1" 
                                    onclick="event.stopPropagation(); window.location.href='vendor-details.html?id=${vendor.id}'">
                                View Details
                            </button>
                            ${vendor.phone ? `
                                <button class="btn btn-outline-primary" 
                                        onclick="event.stopPropagation(); window.open('tel:${vendor.phone}')"
                                        title="Call vendor">
                                    <i class="fas fa-phone"></i>
                                </button>
                            ` : ''}
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary" type="button" data-bs-toggle="dropdown" onclick="event.stopPropagation();">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    ${vendor.coordinates ? `
                                        <li><a class="dropdown-item" href="#" 
                                               onclick="event.preventDefault(); event.stopPropagation(); vendorDetails.getDirectionsTo('${vendor.id}')">
                                            <i class="fas fa-directions me-2"></i>Get Directions
                                        </a></li>
                                    ` : ''}
                                    <li><a class="dropdown-item share-vendor" href="#"
                                    onclick="event.preventDefault(); event.stopPropagation(); socialShare.nativeShare('vendor-details.html?id=${vendor.id}', 'Check out ${vendor.name}!')">
                                        <i class="fas fa-share me-2"></i>Share Vendor
                                    </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    // Get directions to a specific vendor
    getDirectionsTo: function(vendorId) {
        const vendor = appState.vendors.find(v => v.id === vendorId);
        if (!vendor || !vendor.coordinates) return;
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const userLat = position.coords.latitude;
                const userLng = position.coords.longitude;
                const vendorLat = vendor.coordinates.lat;
                const vendorLng = vendor.coordinates.lng;
                
                const url = `https://www.google.com/maps/dir/${userLat},${userLng}/${vendorLat},${vendorLng}`;
                window.open(url, '_blank');
            }, () => {
                // Fallback if geolocation fails
                const url = `https://www.google.com/maps/search/?api=1&query=${vendor.coordinates.lat},${vendor.coordinates.lng}`;
                window.open(url, '_blank');
            });
        } else {
            // Fallback for browsers without geolocation
            const url = `https://www.google.com/maps/search/?api=1&query=${vendor.coordinates.lat},${vendor.coordinates.lng}`;
            window.open(url, '_blank');
        }
    },

    // Setup event handlers
    setupEventHandlers: function() {
        // Tab switching analytics
        $('.nav-tabs button').on('shown.bs.tab', function(e) {
            const tabName = $(e.target).attr('id').replace('-tab', '');
            console.log(`Viewed ${tabName} tab for vendor: ${currentVendor.name}`);
        });

        // Review functionality - delegate event handler
        $(document).on('click', '#writeReviewBtn', () => {
            this.openReviewModal();
        });

        // Star rating functionality
        this.setupStarRating();
        
        // Review form handlers
        this.setupReviewForm();
    },

    // Open review modal
    openReviewModal: function() {
        if (!currentVendor) return;

        // Populate vendor info in modal
        $('#review-vendor-name').text(currentVendor.name);
        $('#review-vendor-category').text(currentVendor.category);
        
        const vendorImage = currentVendor.photos && currentVendor.photos.length > 0 
            ? currentVendor.photos[0] 
            : '/images/placeholder-food.jpg';
        $('#review-vendor-image').attr('src', vendorImage);

        // Reset form
        this.resetReviewForm();

        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('reviewModal'));
        modal.show();
    },

    // Setup star rating functionality
    setupStarRating: function() {
        $(document).on('click', '#starRating i', function() {
            const rating = $(this).data('rating');
            $('#reviewRating').val(rating);
            
            // Update star display
            $('#starRating i').each(function(index) {
                if (index < rating) {
                    $(this).removeClass('far').addClass('fas').addClass('text-warning');
                } else {
                    $(this).removeClass('fas text-warning').addClass('far');
                }
            });
        });

        // Hover effects
        $(document).on('mouseenter', '#starRating i', function() {
            const rating = $(this).data('rating');
            $('#starRating i').each(function(index) {
                if (index < rating) {
                    $(this).addClass('text-warning');
                } else {
                    $(this).removeClass('text-warning');
                }
            });
        });

        $(document).on('mouseleave', '#starRating', function() {
            const currentRating = $('#reviewRating').val();
            $('#starRating i').each(function(index) {
                if (index < currentRating) {
                    $(this).addClass('text-warning');
                } else {
                    $(this).removeClass('text-warning');
                }
            });
        });
    },

    // Setup review form handlers
    setupReviewForm: function() {
        // Character counter
        $(document).on('input', '#reviewComment', function() {
            const count = $(this).val().length;
            $('#charCount').text(count);
            
            if (count < 10) {
                $('#charCount').removeClass('text-success').addClass('text-danger');
            } else {
                $('#charCount').removeClass('text-danger').addClass('text-success');
            }
        });

        // Submit review
        $(document).on('click', '#submitReview', () => {
            this.submitReview();
        });
    },

    // Reset review form
    resetReviewForm: function() {
        $('#reviewForm')[0].reset();
        $('#reviewRating').val('');
        $('#charCount').text('0').removeClass('text-success text-danger');
        
        // Reset stars
        $('#starRating i').removeClass('fas text-warning').addClass('far');
    },

    // Validate review form
    validateReviewForm: function() {
        const rating = $('#reviewRating').val();
        const comment = $('#reviewComment').val().trim();
        const name = $('#reviewerName').val().trim();
        const agreed = $('#agreeTerms').is(':checked');

        let isValid = true;
        let errors = [];

        if (!rating) {
            errors.push('Please select a rating');
            isValid = false;
        }

        if (comment.length < 10) {
            errors.push('Review comment must be at least 10 characters');
            isValid = false;
        }

        if (!name) {
            errors.push('Please enter your name');
            isValid = false;
        }

        if (!agreed) {
            errors.push('Please agree to the community guidelines');
            isValid = false;
        }

        if (!isValid) {
            alert('Please fix the following errors:\n• ' + errors.join('\n• '));
        }

        return isValid;
    },

    // Submit review
    submitReview: function() {
        if (!this.validateReviewForm()) {
            return;
        }

        const reviewData = {
            id: 'review_' + Date.now(),
            vendorId: currentVendor.id,
            rating: parseInt($('#reviewRating').val()),
            comment: $('#reviewComment').val().trim(),
            author: $('#reviewerName').val().trim(),
            date: new Date().toISOString(),
            avatar: '/images/placeholder-avatar.jpg'
        };

        // Show loading state
        const submitBtn = $('#submitReview');
        const originalText = submitBtn.html();
        submitBtn.html('<i class="fas fa-spinner fa-spin me-2"></i>Submitting...').prop('disabled', true);

        // Simulate API call delay
        setTimeout(() => {
            // Save to localStorage
            this.saveReview(reviewData);
            
            // Add review to current vendor data
            if (!currentVendor.reviews) {
                currentVendor.reviews = [];
            }
            currentVendor.reviews.unshift(reviewData);
            
            // Update review count and rating
            currentVendor.reviewsCount += 1;
            this.updateVendorRating();
            
            // Update display
            this.displayReviews(currentVendor.reviews);
            
            // Hide modal
            bootstrap.Modal.getInstance(document.getElementById('reviewModal')).hide();
            
            // Show success toast
            this.showSuccessToast();
            
            // Reset button
            submitBtn.html(originalText).prop('disabled', false);
        }, 1500);
    },

    // Save review to localStorage
    saveReview: function(reviewData) {
        let reviews = JSON.parse(localStorage.getItem('kampar_reviews') || '[]');
        reviews.unshift(reviewData);
        localStorage.setItem('kampar_reviews', JSON.stringify(reviews));
    },

    // Update vendor rating after new review
    updateVendorRating: function() {
        if (!currentVendor.reviews || currentVendor.reviews.length === 0) return;
        
        const total = currentVendor.reviews.reduce((sum, review) => sum + review.rating, 0);
        const newRating = (total / currentVendor.reviews.length).toFixed(1);
        currentVendor.rating = parseFloat(newRating);
        
        // Update the main vendor data in appState
        const vendorIndex = appState.vendors.findIndex(v => v.id === currentVendor.id);
        if (vendorIndex !== -1) {
            appState.vendors[vendorIndex].rating = currentVendor.rating;
            appState.vendors[vendorIndex].reviewsCount = currentVendor.reviewsCount;
            appState.vendors[vendorIndex].reviews = currentVendor.reviews;
        }
    },

    // Show success toast
    showSuccessToast: function() {
        const toast = new bootstrap.Toast(document.getElementById('reviewSuccessToast'));
        toast.show();
    },

    // Load saved reviews from localStorage
    loadSavedReviews: function(vendorId) {
        const reviews = JSON.parse(localStorage.getItem('kampar_reviews') || '[]');
        return reviews.filter(review => review.vendorId === vendorId);
    },

    // Show error state
    showError: function() {
        $('#loading-state').hide();
        $('#error-state').show();
        $('#vendor-content').hide();
    },

    // Hide loading state
    hideLoading: function() {
        $('#loading-state').hide();
    },

    // Show main content
    showContent: function() {
        $('#vendor-content').show();
    },

   
};

// Initialize when DOM is ready
$(document).ready(function() {
    setTimeout(() => {
        vendorDetails.init();
    }, 100);

});

// Add custom styles for this page
const style = document.createElement('style');
style.textContent = `
    .menu-item-card {
        transition: transform 0.2s ease;
    }
    
    .menu-item-card:hover {
        transform: translateY(-4px);
    }
    
    .photo-swiper .swiper-button-next,
    .photo-swiper .swiper-button-prev {
        color: rgba(255, 255, 255, 0.8);
        background: rgba(0, 0, 0, 0.3);
        border-radius: 50%;
        width: 40px;
        height: 40px;
    }
    
    .photo-swiper .swiper-button-next:hover,
    .photo-swiper .swiper-button-prev:hover {
        color: white;
        background: rgba(0, 0, 0, 0.5);
    }
    
    .photo-swiper .swiper-pagination-bullet {
        background: rgba(255, 255, 255, 0.6);
        opacity: 1;
    }
    
    .photo-swiper .swiper-pagination-bullet-active {
        background: white;
    }
    
    .nav-tabs .nav-link {
        color: var(--color-text-secondary);
    }
    
    .nav-tabs .nav-link.active {
        color: var(--color-primary);
        border-bottom-color: var(--color-primary);
    }
    
    /* Star Rating Styles */
    .star-rating {
        font-size: 2rem;
        cursor: pointer;
        user-select: none;
        margin-bottom: 0.5rem;
    }
    
    .star-rating i {
        color: #ddd;
        transition: color 0.2s ease;
        margin-right: 0.25rem;
    }
    
    .star-rating i:hover {
        color: #ffc107 !important;
    }
    
    .star-rating i.text-warning {
        color: #ffc107 !important;
    }
    
    /* Review Form Styles */
    #reviewModal .modal-body {
        max-height: 70vh;
        overflow-y: auto;
    }
    
    .border-success {
        border-color: #198754 !important;
        border-width: 2px !important;
    }
    
    /* Character Counter Styles */
    #charCount.text-danger {
        color: #dc3545 !important;
    }
    
    #charCount.text-success {
        color: #198754 !important;
    }
    
    /* Toast Styles */
    .toast-container {
        z-index: 1060;
    }
    
    .toast .toast-header.bg-success {
        background-color: #198754 !important;
    }
    
    /* Vendor card hover styles moved to main.css for consistency */
    
    @media (max-width: 768px) {
        .photo-swiper .swiper-button-next,
        .photo-swiper .swiper-button-prev {
            display: none;
        }
        
        #vendor-map {
            height: 300px !important;
        }
        
        .star-rating {
            font-size: 1.5rem;
        }
        
        #reviewModal .modal-dialog {
            margin: 0.5rem;
        }
    }
`;
document.head.appendChild(style);

// Export for global access
window.vendorDetails = vendorDetails;
