/**
 * Kampar Street Food - Favorites Page JavaScript
 * Handles favorites display, search, statistics, and management
 */

let favoriteVendors = [];
let filteredFavorites = [];
let searchQuery = '';
let isInitialized = false; // Guard flag to prevent duplicate initialization
let processingUpdate = false; // Flag to prevent recursive updates
let loadingFavorites = false; // Flag to prevent concurrent loading
const SORTKEY = 'favorites:sort';
const getSort = () => localStorage.getItem(SORTKEY) || 'name';
const setSort = (k) => localStorage.setItem(SORTKEY, k);
const ADDEDKEY = 'favorites:addedAt'; // map: { [vendorId]: epoch_ms }
const getAddedMap = () => JSON.parse(localStorage.getItem(ADDEDKEY) || '{}');
const setAddedMap = (m) => localStorage.setItem(ADDEDKEY, JSON.stringify(m));
let prevFavoriteIds = []; // to detect add/remove deltas


const favoritesPage = {
    // Debounce utility for this object
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func.apply(this, args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    // Initialize favorites page
    init: function() {
        // Prevent duplicate initialization
        if (isInitialized) {
            console.log('Favorites page already initialized, skipping...');
            return;
        }
        
        console.log('Initializing favorites page...');
        isInitialized = true;
        
        // Setup event handlers first
        this.setupEventHandlers();

        // Reflect persisted sort in the dropdown
        $('#favorites-sort').val(getSort());
        
        // Wait for StateManager and data to be ready
        this.waitForDependencies();
    },
    
    // Wait for dependencies to be loaded
    waitForDependencies: function() {
        console.log('Waiting for dependencies...');
        
        let retryCount = 0;
        const maxRetries = 5;
        const retryDelay = 200;
        let timeoutId = null;
        
        const checkAndLoad = () => {
            // Clear any existing timeout to prevent accumulation
            if (timeoutId) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }
            
            if (typeof StateManager !== 'undefined' && 
                typeof appState !== 'undefined' && 
                appState.vendors && appState.vendors.length > 0) {
                console.log('Dependencies ready, loading favorites');
                this.loadFavoriteVendors();
                
                return; // Exit successfully
            }
            
            retryCount++;
            if (retryCount < maxRetries) {
                console.log(`Dependencies not ready, retry ${retryCount}/${maxRetries}...`);
                timeoutId = setTimeout(checkAndLoad, retryDelay);
            } else {
                console.warn('Dependencies not ready after max retries, showing empty state');
                this.displayFavorites();
            }
        };
        
        checkAndLoad();
    },

    // Load favorite vendors
    loadFavoriteVendors: function() {
        // Prevent concurrent loading
        if (loadingFavorites) {
            console.log('FavoritesPage: Already loading favorites, skipping...');
            return;
        }
        
        loadingFavorites = true;
        
        if (!appState.vendors || appState.vendors.length === 0) {
            favoriteVendors = [];
            filteredFavorites = [];
            this.displayFavorites();
            loadingFavorites = false;
            return;
        }

        // 1. Get the full list of favorite vendors
        let favoriteIds = StateManager.getFavorites();
        prevFavoriteIds = favoriteIds.slice();

        favoriteVendors = appState.vendors.filter(vendor => favoriteIds.includes(vendor.id));
        
        // 2. Re-apply the search filter immediately after loading the full list
        // This is the key fix!
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            filteredFavorites = favoriteVendors.filter(vendor =>
                vendor.name.toLowerCase().includes(query) ||
                vendor.description.toLowerCase().includes(query) ||
                vendor.category.toLowerCase().includes(query) ||
                vendor.tags.some(tag => tag.toLowerCase().includes(query))
            );
        } else {
            filteredFavorites = [...favoriteVendors];
        }

        // 3. Sort the filtered list (or the full list if no search)
        this.sortFavorites(getSort());

        // After sortFavorites() renders, update extras
        this.updateStatistics();
        this.loadRecommendations();
        
        loadingFavorites = false;
    },

    // Setup event handlers
    setupEventHandlers: function() {
        // Prevent duplicate handler setup
        if (this.handlersSetup) {
            console.log('Event handlers already setup, skipping...');
            return;
        }
        
        this.handlersSetup = true;
        
        // Use named functions to prevent duplicate listeners with debouncing
        this.handleFavoritesUpdate = this.debounce(() => {
            // --- begin delta tracking ---
            try {
                const currentIds = (StateManager ? StateManager.getFavorites() : JSON.parse(localStorage.getItem('favorites') || '[]')) || [];
                const before = new Set(prevFavoriteIds || []);
                const after  = new Set(currentIds || []);
                const added = [];
                const removed = [];

                // additions
                for (const id of after) if (!before.has(id)) added.push(id);
                // removals
                for (const id of before) if (!after.has(id)) removed.push(id);

                if (added.length || removed.length) {
                    const map = getAddedMap();
                    const now = Date.now();
                    added.forEach(id => { map[id] = now; });     // stamp new favorites
                    removed.forEach(id => { delete map[id]; });   // clean removed
                    setAddedMap(map);
                    prevFavoriteIds = currentIds.slice();         // update cache
                }
            } catch (e) {
                console.warn('favorites: delta tracking failed', e);
            }
            // --- end delta tracking ---

            if (isInitialized && !this.isLoading && !processingUpdate) {
                processingUpdate = true;
                this.isLoading = true;
                this.loadFavoriteVendors();
                setTimeout(() => { 
                    this.isLoading = false; 
                    processingUpdate = false;
                }, 200);
            }
        }, 300);

        this.handleRefreshFavorites = this.debounce(() => {
            // Check for changes in favorite IDs before reloading
            const currentIds = (StateManager ? StateManager.getFavorites() : JSON.parse(localStorage.getItem('favorites') || '[]')) || [];
            const hasChanges = (currentIds.length !== prevFavoriteIds.length) ||
                                currentIds.some(id => !prevFavoriteIds.includes(id));

            if (hasChanges) {
                console.log('FavoritesPage: Favorite list changed, reloading full list.');
                if (isInitialized && !this.isLoading && !processingUpdate) {
                    processingUpdate = true;
                    this.isLoading = true;
                    this.loadFavoriteVendors();
                    setTimeout(() => {
                        this.isLoading = false;
                        processingUpdate = false;
                    }, 200);
                }
            } else {
                console.log('FavoritesPage: No list change detected, skipping full reload.');
            }
        }, 300);

        // Remove any existing listeners first
        window.removeEventListener('favoritesUpdated', this.handleFavoritesUpdate);
        window.removeEventListener('refreshFavoritesList', this.handleRefreshFavorites);
        
        // Add fresh listeners
        window.addEventListener('favoritesUpdated', this.handleFavoritesUpdate);
        window.addEventListener('refreshFavoritesList', this.handleRefreshFavorites);

        // Also listen to jQuery-triggered events
        $(document).off('favoritesUpdated.favorites').on('favoritesUpdated.favorites', this.handleFavoritesUpdate);
        $(document).off('refreshFavoritesList.favorites').on('refreshFavoritesList.favorites', this.handleRefreshFavorites);

        // Search functionality - prevent duplicate handlers
        const searchInput = $('#favorites-search');
        const clearButton = $('#search-clear');

        // Remove existing handlers first
        searchInput.off('input.favorites');
        clearButton.off('click.favorites');

        const debouncedSearch = utils.debounce((query) => {
            searchQuery = query;
            this.filterFavorites();
        }, 300);

        searchInput.on('input.favorites', function() {
            const query = $(this).val().trim();
            debouncedSearch(query);
            
            if (query) {
                clearButton.removeClass('d-none');
            } else {
                clearButton.addClass('d-none');
            }
        });

        clearButton.on('click.favorites', () => {
            this.clearSearch();
        });

        // Sort functionality - prevent duplicates
        $('#favorites-sort').off('change.favorites').on('change.favorites', (e) => {
            const key = e.target.value || 'name';
            setSort(key);
            this.sortFavorites(key);
        });


        // Action buttons - prevent duplicates
        $('#export-favorites').off('click.favorites').on('click.favorites', () => {
            this.exportFavorites();
        });

        $('#share-favorites').off('click.favorites').on('click.favorites', () => {
            this.shareFavorites();
        });

        $('#clear-favorites').off('click.favorites').on('click.favorites', () => {
            this.clearAllFavorites();
        });
    },

    // Display favorites
    displayFavorites: function() {
        console.log('FavoritesPage: Displaying favorites...', 'favoriteVendors.length:', favoriteVendors.length);
        
        const emptyState = $('#empty-state');
        const favoritesGrid = $('#favorites-grid');
        const noResults = $('#no-search-results');

        // Show empty state if no favorites
        if (favoriteVendors.length === 0) {
            console.log('FavoritesPage: No favorite vendors, showing empty state');
            emptyState.show();
            favoritesGrid.parent().hide();
            $('#favorites-summary').parent().hide();
            $('#recommendations-section').hide();
            return;
        } else {
            console.log('FavoritesPage: Found favorite vendors, showing grid');
            emptyState.hide();
            favoritesGrid.parent().show();
            $('#favorites-summary').parent().show();
        }

        // Show no results if search returned nothing
        if (filteredFavorites.length === 0 && searchQuery) {
            console.log('FavoritesPage: No search results, showing no results message');
            noResults.show();
            favoritesGrid.empty();
            return;
        } else {
            noResults.hide();
        }

        // Display vendors
        console.log('FavoritesPage: Rendering', filteredFavorites.length, 'vendor cards');
        favoritesGrid.empty();
        filteredFavorites.forEach((vendor, index) => {
            const vendorCard = this.createFavoriteVendorCard(vendor, index);
            favoritesGrid.append(vendorCard);
        });

        // Initialize favorites UI immediately after creating cards (debounced)
        if (typeof StateManager !== 'undefined' && !this.uiUpdateScheduled) {
            this.uiUpdateScheduled = true;
            setTimeout(() => {
                console.log('FavoritesPage: Initializing favorites UI for cards');
                StateManager.initializeFavoritesUI();
                this.uiUpdateScheduled = false;
            }, 50);
        }
    },

createFavoriteVendorCard: function(vendor, index) {
    const isOpen = utils.isVendorOpen(vendor);
    const statusBadge = isOpen 
        ? '<span class="badge badge-success">Open</span>'
        : '<span class="badge text-danger fw-bold">• Closed</span>';

    const mainPhoto = vendor.photos && vendor.photos.length > 0 
        ? vendor.photos[0] 
        : '/images/placeholder-food.jpg';

    return `
        <div class="col-md-6 col-lg-4 vendor-item">
            <div class="card favorite-vendor-card h-100" data-vendor-id="${vendor.id}" style="${!isOpen ? 'opacity: 0.9;' : ''}">
                <div class="position-relative">
                    <img src="${mainPhoto}" class="card-img-top" alt="${vendor.name}" 
                         loading="lazy" style="height: 200px; object-fit: cover;">
                    <button class="btn btn-icon favorite-btn position-absolute top-0 end-0 m-2 bg-white shadow-sm" 
                            data-vendor-id="${vendor.id}" 
                            title="Remove from favorites">
                        <i class="fas fa-heart text-danger"></i>
                    </button>
                    <div class="position-absolute bottom-0 start-0 m-2">${statusBadge}</div>
                    ${vendor.isVerified ? '<div class="position-absolute top-0 start-0 m-2"><i class="fas fa-check-circle text-primary bg-white rounded-circle"></i></div>' : ''}
                </div>
                
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">${vendor.name}</h5>
                    <p class="card-text text-muted flex-grow-1">${utils.truncateText(vendor.description, 100)}</p>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div class="rating">
                                ${utils.generateStarRating(vendor.rating, '0.9rem')}
                                <span class="rating-text ms-1">${vendor.rating}</span>
                                <span class="rating-count text-muted">(${vendor.reviewsCount})</span>
                            </div>
                            <span class="badge badge-warning">${vendor.priceBand}</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted">
                                <i class="fas fa-map-marker-alt me-1"></i>
                                ${vendor.distance}
                            </small>
                            <span class="badge badge-secondary">${vendor.category}</span>
                        </div>
                        
                        <div class="vendor-tags">
                            ${vendor.tags.slice(0, 3).map(tag => 
                                `<span class="badge bg-light text-dark me-1 mb-1">${tag}</span>`
                            ).join('')}
                        </div>
                    </div>

                        <div class="d-flex gap-2 mt-auto">
                            <button class="btn btn-primary flex-grow-1" 
                                    onclick="event.stopPropagation(); window.location.href='vendor-details.html?id=${vendor.id}'">
                                View Details
                            </button>
                            ${vendor.phone ? `
                                <button class="btn btn-outline-primary" 
                                        onclick="event.stopPropagation(); window.open('tel:${vendor.phone}')"
                                        title="Call vendor">
                                    <i class="fas fa-phone"></i>
                                </button>
                            ` : ''}
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary" type="button" data-bs-toggle="dropdown" onclick="event.stopPropagation();">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    ${vendor.coordinates ? `
                                        <li><a class="dropdown-item" href="#" 
                                               onclick="event.preventDefault(); event.stopPropagation(); favoritesPage.getDirectionsTo('${vendor.id}')">
                                            <i class="fas fa-directions me-2"></i>Get Directions
                                        </a></li>
                                    ` : ''}
                                    <li><a class="dropdown-item share-vendor" href="#"
                                    onclick="event.preventDefault(); event.stopPropagation(); socialShare.nativeShare('vendor-details.html?id=${vendor.id}', 'Check out ${vendor.name}!')">
                                        <i class="fas fa-share me-2"></i>Share Vendor
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
},

    // Filter favorites based on search
    filterFavorites: function() {
        if (!searchQuery) {
            filteredFavorites = [...favoriteVendors];
        } else {
            const query = searchQuery.toLowerCase();
            filteredFavorites = favoriteVendors.filter(vendor =>
                vendor.name.toLowerCase().includes(query) ||
                vendor.description.toLowerCase().includes(query) ||
                vendor.category.toLowerCase().includes(query) ||
                vendor.tags.some(tag => tag.toLowerCase().includes(query))
            );
        }
        
        // Render through the sorter so current sort is kept
        this.sortFavorites(getSort());
    },

    // Sort favorites with improved error handling
    sortFavorites: function(sortBy) {
        if (!sortBy || typeof sortBy !== 'string') {
            console.warn('Invalid sort parameter:', sortBy);
            return;
        }
        
        if (!filteredFavorites || filteredFavorites.length === 0) {
            console.log('No favorites to sort');
            // Still reflect empty state in UI
            this.displayFavorites();
            return;
        }
        
        try {
            switch(sortBy) {
                case 'rating':
                    filteredFavorites.sort((a, b) => (b.rating || 0) - (a.rating || 0));
                    break;
                case 'category':
                    filteredFavorites.sort((a, b) => (a.category || '').localeCompare(b.category || ''));
                    break;
                case 'added': {
                        // get favorite ID array
                        const favoritesKey = 'favorites';
                        const favoriteIds = JSON.parse(localStorage.getItem(favoritesKey) || '[]');
    
                        // reverse the favorite array
                        filteredFavorites.sort((a, b) => {
                            const indexA = favoriteIds.indexOf(a.id);
                            const indexB = favoriteIds.indexOf(b.id);
                            return indexB - indexA;
                        });
                        break;
                    }
                case 'name':
                default:
                    filteredFavorites.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
                    break;
            }
            
            console.log(`Sorted favorites by ${sortBy}:`, filteredFavorites.length, 'items');
            this.displayFavorites();
            
        } catch (error) {
            console.error('Error sorting favorites:', error);
            if (window.utils && window.utils.showToast) {
                window.utils.showToast('Error sorting favorites. Please try again.', 'error');
            }
        }
    },

    // Clear search
    clearSearch: function() {
        $('#favorites-search').val('');
        $('#search-clear').addClass('d-none');
        searchQuery = '';
        this.filterFavorites();
    },

    // Update statistics
    updateStatistics: function() {
        const totalFavorites = favoriteVendors.length;
        const openNow = favoriteVendors.filter(v => utils.isVendorOpen(v)).length;
        const avgRating = totalFavorites > 0 ? 
            (favoriteVendors.reduce((sum, v) => sum + v.rating, 0) / totalFavorites).toFixed(1) : 
            '0.0';
        const uniqueCategories = new Set(favoriteVendors.map(v => v.category)).size;

        $('#total-favorites').text(totalFavorites);
        $('#open-favorites').text(openNow);
        $('#avg-rating').text(avgRating);
        $('#categories-count').text(uniqueCategories);
    },

    // Load recommendations
    loadRecommendations: function() {
        if (favoriteVendors.length === 0 || appState.vendors.length < 4) {
            return;
        }

        // Get categories of favorite vendors
        const favoriteCategories = [...new Set(favoriteVendors.map(v => v.category))];
        const favoriteIds = new Set(favoriteVendors.map(v => v.id));

        // Find similar vendors not in favorites
        const recommendations = appState.vendors
            .filter(vendor => 
                !favoriteIds.has(vendor.id) && 
                favoriteCategories.includes(vendor.category)
            )
            .sort((a, b) => b.rating - a.rating)
            .slice(0, 3);

        if (recommendations.length > 0) {
            this.displayRecommendations(recommendations);
            $('#recommendations-section').show();
        }
    },

    // Display recommendations
    displayRecommendations: function(recommendations) {
        const recommendationsGrid = $('#recommendations-grid');
        recommendationsGrid.empty();

        recommendations.forEach(vendor => {
            const recommendationCard = this.createRecommendationVendorCard(vendor);
            recommendationsGrid.append(recommendationCard);
        });

        // Initialize favorites for recommendations immediately
        if (typeof StateManager !== 'undefined') {
            setTimeout(() => {
                StateManager.initializeFavoritesUI();
            }, 50);
        }
    },

    createRecommendationVendorCard: function(vendor) {
    const isOpen = utils.isVendorOpen(vendor);
    const statusBadge = isOpen 
        ? '<span class="badge badge-success">Open</span>'
        : '<span class="badge text-danger fw-bold">• Closed</span>';

    const mainPhoto = vendor.photos && vendor.photos.length > 0 
        ? vendor.photos[0] 
        : '/images/placeholder-food.jpg';

    return `
        <div class="col-md-6 col-lg-4 vendor-item">
            <div class="card favorite-vendor-card h-100" data-vendor-id="${vendor.id}" style="${!isOpen ? 'opacity: 0.9;' : ''}">
                <div class="position-relative">
                    <img src="${mainPhoto}" class="card-img-top" alt="${vendor.name}" 
                         loading="lazy" style="height: 200px; object-fit: cover;">
                    <button class="btn btn-icon favorite-btn position-absolute top-0 end-0 m-2 bg-white shadow-sm" 
                            data-vendor-id="${vendor.id}" 
                            title="Add to favorites">
                        <i class="far fa-heart"></i>
                    </button>
                    <div class="position-absolute bottom-0 start-0 m-2">${statusBadge}</div>
                    ${vendor.isVerified ? '<div class="position-absolute top-0 start-0 m-2"><i class="fas fa-check-circle text-primary bg-white rounded-circle"></i></div>' : ''}
                </div>
                
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">${vendor.name}</h5>
                    <p class="card-text text-muted flex-grow-1">${utils.truncateText(vendor.description, 100)}</p>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div class="rating">
                                ${utils.generateStarRating(vendor.rating, '0.9rem')}
                                <span class="rating-text ms-1">${vendor.rating}</span>
                                <span class="rating-count text-muted">(${vendor.reviewsCount})</span>
                            </div>
                            <span class="badge badge-warning">${vendor.priceBand}</span>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted">
                                <i class="fas fa-map-marker-alt me-1"></i>
                                ${vendor.distance}
                            </small>
                            <span class="badge badge-secondary">${vendor.category}</span>
                        </div>
                        
                        <div class="vendor-tags">
                            ${vendor.tags.slice(0, 3).map(tag => 
                                `<span class="badge bg-light text-dark me-1 mb-1">${tag}</span>`
                            ).join('')}
                        </div>
                    </div>

                    <div class="d-flex gap-2 mt-auto">
                        <button class="btn btn-primary flex-grow-1 view-details" data-vendor-id="${vendor.id}">
                            View Details
                        </button>
                        ${vendor.phone ? `
                            <button class="btn btn-outline-primary call-vendor" data-phone="${vendor.phone}" title="Call vendor">
                                <i class="fas fa-phone"></i>
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
},


    // Export favorites to JSON
    exportFavorites: function() {
        if (favoriteVendors.length === 0) {
            utils.showToast('No favorites to export', 'info');
            return;
        }

        const exportData = {
            exportDate: new Date().toISOString(),
            totalFavorites: favoriteVendors.length,
            favorites: favoriteVendors.map(vendor => ({
                id: vendor.id,
                name: vendor.name,
                category: vendor.category,
                rating: vendor.rating,
                address: vendor.address,
                phone: vendor.phone
            }))
        };

        const dataStr = JSON.stringify(exportData, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = `kampar-street-food-favorites-${new Date().toISOString().split('T')[0]}.json`;
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        
        utils.showToast('Favorites exported successfully', 'success');
    },

    // Share favorites collection
    shareFavorites: function() {
        if (favoriteVendors.length === 0) {
            utils.showToast('No favorites to share', 'info');
            return;
        }

        const favoriteNames = favoriteVendors.slice(0, 3).map(v => v.name).join(', ');
        const moreText = favoriteVendors.length > 3 ? ` and ${favoriteVendors.length - 3} more` : '';
        const text = `Check out my favorite street food spots in Kampar: ${favoriteNames}${moreText}! 🍜❤️`;
        const url = window.location.origin;

        if (navigator.share) {
            navigator.share({
                title: 'My Kampar Street Food Favorites',
                text: text,
                url: url
            });
        } else {
            // Fallback to WhatsApp sharing
            const whatsappText = encodeURIComponent(`${text}\n\nExplore more at: ${url}`);
            window.open(`https://wa.me/?text=${whatsappText}`, '_blank');
        }
    },

    // Clear all favorites with confirmation
    clearAllFavorites: function() {
        if (favoriteVendors.length === 0) {
            utils.showToast('No favorites to clear', 'info');
            return;
        }

        // Create confirmation modal
        const modal = $(`
            <div class="modal fade" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header border-0">
                            <h5 class="modal-title">
                                <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                                Clear All Favorites
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to remove all <strong>${favoriteVendors.length}</strong> vendors from your favorites?</p>
                            <p class="text-muted">This action cannot be undone.</p>
                        </div>
                        <div class="modal-footer border-0">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" id="confirm-clear">
                                <i class="fas fa-trash me-2"></i>Clear All
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `);

        $('body').append(modal);
        const bsModal = new bootstrap.Modal(modal[0]);
        bsModal.show();

        // Handle confirmation
        modal.find('#confirm-clear').click(() => {
            appState.favorites = [];
            if (typeof StateManager !== 'undefined') {
                StateManager.state.favorites = [];
                StateManager.saveFavorites();
            }
            favoriteVendors = [];
            filteredFavorites = [];
            
            localStorage.removeItem(ADDEDKEY);
            prevFavoriteIds = [];
            
            this.displayFavorites();
            this.updateStatistics();
            this.updateFavoritesCount();
            
            bsModal.hide();
            utils.showToast('All favorites cleared', 'success');
        });

        modal.on('hidden.bs.modal', function() {
            modal.remove();
        });
    },

    // Get directions to a specific vendor
    getDirectionsTo: function(vendorId) {
        const vendor = appState.vendors.find(v => v.id === vendorId);
        if (!vendor || !vendor.coordinates) return;
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const userLat = position.coords.latitude;
                const userLng = position.coords.longitude;
                const vendorLat = vendor.coordinates.lat;
                const vendorLng = vendor.coordinates.lng;
                
                const url = `https://www.google.com/maps/dir/${userLat},${userLng}/${vendorLat},${vendorLng}`;
                window.open(url, '_blank');
            }, () => {
                // Fallback if geolocation fails
                const url = `https://www.google.com/maps/search/?api=1&query=${vendor.coordinates.lat},${vendor.coordinates.lng}`;
                window.open(url, '_blank');
            });
        } else {
            // Fallback for browsers without geolocation
            const url = `https://www.google.com/maps/search/?api=1&query=${vendor.coordinates.lat},${vendor.coordinates.lng}`;
            window.open(url, '_blank');
        }
    },

    // Cleanup function to prevent memory leaks
    cleanup: function() {
        if (!isInitialized) return;
        
        console.log('Cleaning up favorites page...');
        
        // Clear any pending timeouts
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }
        
        // Remove event listeners
        if (this.handleFavoritesUpdate) {
            window.removeEventListener('favoritesUpdated', this.handleFavoritesUpdate);
        }
        if (this.handleRefreshFavorites) {
            window.removeEventListener('refreshFavoritesList', this.handleRefreshFavorites);
        }
        
        // Remove jQuery event handlers
        $('#favorites-search').off('input.favorites');
        $('#search-clear').off('click.favorites');
        $('#favorites-sort').off('change.favorites');
        $('#export-favorites').off('click.favorites');
        $('#share-favorites').off('click.favorites');
        $('#clear-favorites').off('click.favorites');
        
        // Reset state flags
        isInitialized = false;
        this.handlersSetup = false;
        this.isLoading = false;
        this.uiUpdateScheduled = false;
        favoriteVendors = [];
        filteredFavorites = [];
        searchQuery = '';
    }

    
};

// Initialize when DOM is ready - SINGLE INITIALIZATION POINT
$(document).ready(function() {
    // Prevent duplicate initialization
    if (window.favoritesPageInitialized) {
        console.log('FavoritesPage: Already initialized, skipping...');
        return;
    }
    
    window.favoritesPageInitialized = true;
    
    // Only initialize after a small delay to ensure dependencies are loaded
    setTimeout(() => {
        if (typeof favoritesPage !== 'undefined') {
            favoritesPage.init();
        }
    }, 150); // Increased delay to ensure proper sequencing

    // Cleanup on page unload to prevent memory leaks
    $(window).on('beforeunload', function() {
        if (typeof favoritesPage !== 'undefined') {
            favoritesPage.cleanup();
        }
    });

  // Navigate to vendor details
$(document).on('click', '.view-details', function(e) {
    e.stopPropagation();
    const vendorId = $(this).data('vendor-id');
    if (vendorId) window.location.href = `vendor-details.html?id=${vendorId}`;
});

// Call vendor
$(document).on('click', '.call-vendor', function(e) {
    e.stopPropagation();
    const phone = $(this).data('phone');
    if (phone) window.open(`tel:${phone}`);
});

// Share vendor
$(document).on('click', '.share-vendor', function(e) {
    e.preventDefault();
    e.stopPropagation();
    const vendorId = $(this).data('vendor-id');
    const vendor = favoriteVendors.find(v => v.id === vendorId);
    if (vendor) {
        const url = `${window.location.origin}/vendor-details.html?id=${vendorId}`;
        const text = `Check out ${vendor.name} - ${vendor.description}`;
        
        if (navigator.share) {
            navigator.share({
                title: vendor.name,
                text: text,
                url: url
            }).catch(console.error);
        } else {
            // Fallback: WhatsApp share
            const whatsappText = encodeURIComponent(`${text}\n\n${url}`);
            window.open(`https://wa.me/?text=${whatsappText}`, '_blank');
        }
    }
});
});

// Add custom styles
const style = document.createElement('style');
style.textContent = `
    .favorite-vendor-card {
        /* Favorite vendor card styles moved to main.css for consistency */
    }
    
    .recommendation-card {
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        will-change: transform, box-shadow;
    }
    
    .recommendation-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 30px rgba(0,0,0,0.15);
    }
    
    .fade-in {
        opacity: 0;
        /* Smoother animation with delayed start to prevent blinking */
        animation: fadeInUp 0.7s ease-out 0.1s forwards;
    }
    
    @keyframes fadeInUp {
        0% {
            opacity: 0;
            transform: translateY(20px) translateZ(0);
        }
        100% {
            opacity: 1;
            transform: translateY(0) translateZ(0);
        }
    }
    
    .search-container {
        transition: transform 0.3s ease-out;
        transform: translateZ(0);
        backface-visibility: hidden;
    }
    
    .search-container:focus-within {
        transform: scale(1.01) translateZ(0);
    }
    
    /* Consistent vendor card styles now defined in main.css */
    
    .vendor-item {
        /* Use a fixed small delay instead of calculated delay to prevent blinking */
        animation-delay: 0.1s;
        /* Add GPU acceleration */
        transform: translateZ(0);
        backface-visibility: hidden;
    }
    
    /* Ensure buttons work properly on clickable cards */
    .favorite-vendor-card .btn,
    .favorite-vendor-card .dropdown-toggle {
        position: relative;
        z-index: 10;
    }
`;
document.head.appendChild(style);

// Export for global access
window.favoritesPage = favoritesPage;


