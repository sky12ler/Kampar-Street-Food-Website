/**
 * Kampar Street Food - Home Page JavaScript
 * Handles hero slider, categories, popular vendors, and featured stories
 */

let heroSwiper;

const homePage = {
    // Initialize home page
    init: function() {
        this.initHeroSlider();
        this.loadCategoryCounts();
        this.loadPopularVendors();
        this.loadFeaturedStories();
        this.updateFavoritesCount();
    },

    // Initialize hero slider with Swiper
    initHeroSlider: function() {
        heroSwiper = new Swiper('.hero-swiper', {
            loop: true,
            autoplay: {
                delay: 6000,
                disableOnInteraction: false,
                pauseOnMouseEnter: true,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            },
            keyboard: { enabled: true, onlyInViewport: true },
            breakpoints: {
                320: { autoplay: { delay: 5000 } },
                768: { autoplay: { delay: 6000 } },
            },
            on: {
                slideChange: function() {
                    this.slides.forEach(slide => {
                        const video = slide.querySelector('video');
                        if (video) video.pause();
                    });

                    const activeSlide = this.slides[this.activeIndex];
                    const activeVideo = activeSlide.querySelector('video');
                    if (activeVideo) {
                        activeVideo.play().catch(e => {
                            console.log('Video autoplay failed:', e);
                            activeVideo.muted = true;
                            activeVideo.play().catch(e2 => console.log('Video playback failed:', e2));
                        });
                    }
                },
                init: function() {
                    this.slides.forEach((slide, index) => {
                        const video = slide.querySelector('video');
                        if (video) {
                            video.muted = true;
                            video.playsInline = true;
                            video.setAttribute('playsinline', 'true');
                            video.setAttribute('webkit-playsinline', 'true');
                            video.addEventListener('loadeddata', () => {
                                video.setAttribute('data-loaded', 'true');
                                if (index === this.activeIndex) video.play().catch(() => {});
                            });
                            video.addEventListener('error', () => {
                                video.style.display = 'none';
                                const fallbackImg = slide.querySelector('img');
                                if (fallbackImg) fallbackImg.style.opacity = '1';
                            });
                        }
                    });

                    const firstVideo = this.slides[0]?.querySelector('video');
                    if (firstVideo) firstVideo.play().catch(() => {});
                }
            }
        });

        this.setupVideoHandling();
    },

    // Setup video handling
    setupVideoHandling: function() {
        const videos = document.querySelectorAll('.hero-video');

        videos.forEach(video => {
            video.preload = 'metadata';

            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    video.pause();
                } else {
                    const activeSlide = heroSwiper?.slides[heroSwiper.activeIndex];
                    if (activeSlide?.querySelector('video') === video) video.play().catch(() => {});
                }
            });

            video.addEventListener('ended', () => {
                video.currentTime = 0;
                video.play().catch(() => {});
            });

            video.addEventListener('canplaythrough', () => video.style.opacity = '1');
        });
    },

    // Load category counts
    loadCategoryCounts: function() {
        if (appState.vendors.length === 0) {
            setTimeout(() => this.loadCategoryCounts(), 100);
            return;
        }

        const categories = { Traditional: 0, Noodles: 0, Soup: 0, Dessert: 0, Snacks: 0 };

        appState.vendors.forEach(vendor => {
            if (categories.hasOwnProperty(vendor.category)) categories[vendor.category]++;
        });

        $('#traditional-count').text(categories.Traditional);
        $('#noodles-count').text(categories.Noodles);
        $('#soup-count').text(categories.Soup);
        $('#dessert-count').text(categories.Dessert);
        $('#snacks-count').text(categories.Snacks);
        $('#all-count').text(appState.vendors.length);
    },

    // Load popular vendors
    loadPopularVendors: function() {
        if (appState.vendors.length === 0) {
            setTimeout(() => this.loadPopularVendors(), 100);
            return;
        }

        const popularVendors = [...appState.vendors]
            .sort((a, b) => b.rating - a.rating)
            .slice(0, 6);

        const vendorsContainer = $('#popular-vendors');
        vendorsContainer.empty();

        popularVendors.forEach(vendor => vendorsContainer.append(this.createVendorCard(vendor)));

        // Initialize favorites UI via StateManager
        setTimeout(() => {
            if (typeof StateManager !== 'undefined') StateManager.initializeFavoritesUI();
        }, 200);
    },

    // Vendor card HTML
    createVendorCard: function(vendor) {
        const isOpen = utils.isVendorOpen(vendor);
        const statusBadge = isOpen
            ? '<span class="badge badge-success">Open</span>'
            : '<span class="badge text-danger fw-bold" data-bs-toggle="tooltip" title="Currently closed">• Closed</span>';

        const mainPhoto = vendor.photos?.[0] || '/images/malaysian_street_food_vendor_cooking_stall.jpg';

        return `
            <div class="col-md-6 col-lg-4 fade-in">
                <div class="card vendor-card h-100" onclick="window.location.href='vendor-details.html?id=${vendor.id}'" style="cursor:pointer; ${!isOpen ? 'opacity:0.9;' : ''}">
                    <div class="position-relative">
                        <img src="${mainPhoto}" class="card-img-top" alt="${vendor.name}" loading="lazy" onerror="this.src='/images/malaysian_street_food_vendor_cooking_stall.jpg'">
                        <button class="btn btn-icon favorite-btn position-absolute top-0 end-0 m-2" data-vendor-id="${vendor.id}" onclick="event.stopPropagation();">
                            <i class="far fa-heart"></i>
                        </button>
                        ${statusBadge ? `<div class="position-absolute bottom-0 start-0 m-2">${statusBadge}</div>` : ''}
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">${vendor.name}</h5>
                        <p class="card-text text-muted">${utils.truncateText(vendor.description, 120)}</p>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div class="rating">
                                ${utils.generateStarRating(vendor.rating)}
                                <span class="rating-text ms-1">${vendor.rating}</span>
                                <span class="rating-count">(${vendor.reviewsCount})</span>
                            </div>
                            <span class="badge badge-primary">${vendor.priceBand}</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${vendor.distance}</small>
                            <div class="vendor-tags">
                                ${vendor.tags.slice(0, 2).map(tag => `<span class="badge bg-light text-dark me-1">${tag}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
    },

    // Load featured blog stories
    loadFeaturedStories: function() {
        if (appState.blogPosts.length === 0) {
            setTimeout(() => this.loadFeaturedStories(), 100);
            return;
        }

        const featuredStories = appState.blogPosts.slice(0, 3);
        const storiesContainer = $('#featured-stories');
        storiesContainer.empty();

        featuredStories.forEach(story => storiesContainer.append(this.createStoryCard(story)));
    },

    // Story card HTML
    createStoryCard: function(story) {
        return `
            <div class="col-md-6 col-lg-4 fade-in">
                <article class="card story-card h-100" onclick="window.location.href='blog-post.html?id=${story.id}'" style="cursor:pointer;">
                    <img src="${story.image}" class="card-img-top" alt="${story.title}" loading="lazy">
                    <div class="card-body">
                        <div class="mb-2"><span class="badge badge-secondary">${story.category}</span></div>
                        <h5 class="card-title">${story.title}</h5>
                        <p class="card-text text-muted">${story.excerpt}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center">
                                <img src="${story.authorAvatar}" alt="${story.author}" class="rounded-circle me-2" width="32" height="32">
                                <small class="text-muted">${story.author}</small>
                            </div>
                            <div class="d-flex align-items-center text-muted">
                                <small class="me-3"><i class="far fa-heart me-1"></i>${story.likes}</small>
                                <small>${story.readTime}</small>
                            </div>
                        </div>
                        <div class="mt-2"><small class="text-muted">${utils.formatDate(story.date)}</small></div>
                    </div>
                </article>
            </div>`;
    },

    // Favorites count now only calls StateManager
    updateFavoritesCount: function() {
        if (typeof StateManager !== 'undefined') StateManager.updateFavoritesCount();
    },

    // Scroll-triggered animations
    setupScrollAnimations: function() {
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) entry.target.classList.add('animate-in');
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.fade-in, .slide-in').forEach(el => observer.observe(el));
    }
};

// DOM Ready
$(document).ready(function() {
    setTimeout(() => {
        homePage.init();
        homePage.setupScrollAnimations();
    }, 100);

    $(document).on('favoritesUpdated', function() {
        homePage.updateFavoritesCount();
    });

    $('.hero-swiper').hover(
        () => heroSwiper?.autoplay.stop(),
        () => heroSwiper?.autoplay.start()
    );
});

$(document).on('click', '.category-card', function() {
    $(this).addClass('scale-animation');
});

// Export global
window.homePage = homePage;  