/**
 * Kampar Street Food - Blog Page JavaScript (fixed persistence + single heart icon)
 */

let allBlogPosts = [];
let filteredPosts = [];
let displayedPosts = [];
let postsPerPage = 6;
let currentPage = 1;
let currentCategory = '';
let searchQuery = '';
let loadAttempts = 0;
const maxLoadAttempts = 50;

const blogPage = {
  init: function() {
    console.log('Blog page initializing...');
    this.setupEventHandlers();
    this.loadBlogPosts();

    // When navigating back (bfcache/pageshow), reapply persistence and rerender counts/icons
    window.addEventListener('pageshow', () => {
      if (allBlogPosts.length) {
        allBlogPosts = this.applyPersistenceToPosts(allBlogPosts);
        filteredPosts = [...allBlogPosts];
        currentPage = 1;
        displayedPosts = [];
        this.displayPosts();
        this.displayFeaturedStory();
        this.updateResultsCount();
        this.updateLoadMoreButton();
      } else {
        // If posts weren't loaded yet, attempt load
        this.loadBlogPosts();
      }
    });
  },

  // Try to load posts (from appState or fetch)
  loadBlogPosts: function() {
    console.log('Attempting to load blog posts, attempt:', loadAttempts + 1);

    // If appState already has blogPosts, use it
    if (window.appState && Array.isArray(window.appState.blogPosts) && window.appState.blogPosts.length > 0) {
      allBlogPosts = this.applyPersistenceToPosts(window.appState.blogPosts);
      filteredPosts = [...allBlogPosts];
      this.displayFeaturedStory();
      this.filterAndDisplayPosts();
      this.loadWritersSection();
      this.hideLoading();
      return;
    }

    // else try to load via manager or fetch
    if (loadAttempts < maxLoadAttempts) {
      loadAttempts++;
      if (window.dataManager && typeof window.dataManager.loadBlogPosts === 'function') {
        window.dataManager.loadBlogPosts()
          .done(() => {
            setTimeout(() => this.loadBlogPosts(), 100);
          })
          .fail(() => {
            this.loadBlogPostsDirectly();
          });
      } else {
        this.loadBlogPostsDirectly();
      }
    } else {
      this.showErrorState();
    }
  },

  loadBlogPostsDirectly: function() {
    console.log('Loading blog posts directly...');
    if (typeof $ !== 'undefined') {
      $.getJSON('/data/blog-posts.json')
        .done((data) => {
          window.appState = window.appState || {};
          window.appState.blogPosts = data;
          allBlogPosts = this.applyPersistenceToPosts(data);
          filteredPosts = [...allBlogPosts];
          this.displayFeaturedStory();
          this.filterAndDisplayPosts();
          this.loadWritersSection();
          this.hideLoading();
        })
        .fail((err) => {
          console.error('Failed to load blog posts directly', err);
          this.showErrorState();
        });
    } else {
      fetch('/data/blog-posts.json')
        .then(r => r.json())
        .then(data => {
          window.appState = window.appState || {};
          window.appState.blogPosts = data;
          allBlogPosts = this.applyPersistenceToPosts(data);
          filteredPosts = [...allBlogPosts];
          this.displayFeaturedStory();
          this.filterAndDisplayPosts();
          this.loadWritersSection();
          this.hideLoading();
        })
        .catch(err => {
          console.error('Failed to fetch blog-posts.json', err);
          this.showErrorState();
        });
    }
  },

  showErrorState: function() {
    this.hideLoading();
    $('#featured-story').html(`<div class="card border-0 shadow-sm"><div class="card-body text-center p-5"><i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i><h3>Unable to Load Blog Posts</h3><p class="text-muted mb-4">Please refresh the page.</p><button class="btn btn-primary" onclick="window.location.reload()">Refresh</button></div></div>`);
    $('#blog-posts-grid').empty();
  },

  hideLoading: function() {
    ['#loading-state', '.blog-loading', '.loading-spinner', '#blog-loading'].forEach(sel => {
      const el = $(sel);
      if (el.length) el.hide();
    });
    ['#blog-posts-grid', '#featured-story', '.blog-content'].forEach(sel => {
      const el = $(sel);
      if (el.length) el.show();
    });
  },

  setupEventHandlers: function() {
    // search
    const searchInput = $('#blog-search');
    if (searchInput.length) {
      const debouncedSearch = this.debounce((q) => {
        searchQuery = q;
        this.filterAndDisplayPosts();
      }, 300);
      searchInput.on('input', function() {
        debouncedSearch($(this).val().trim());
      });
    }

    // category filters
    $('.category-filter').off('click').on('click', (e) => {
      const category = $(e.currentTarget).data('category');
      this.filterByCategory(category);
    });

    $('#sort-select').off('change').on('change', (e) => this.sortPosts(e.target.value));
    $('#load-more-btn').off('click').on('click', () => this.loadMorePosts());
    $('#newsletter-form').off('submit').on('submit', (e) => { 
  e.preventDefault(); 
  this.subscribeEmail('#newsletter-email');   
});

  },

  debounce: function(func, wait) {
    let timeout;
    return function(...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  },

  // Featured
  displayFeaturedStory: function() {
    if (!allBlogPosts || allBlogPosts.length === 0) return;
    const featuredPost = allBlogPosts.reduce((prev, cur) => ((prev.likes || 0) > (cur.likes || 0) ? prev : cur));
    const featuredSection = $('#featured-story');
    if (!featuredSection.length) return;

    const featuredHtml = `
      <div class="row g-0">
        <div class="col-md-6">
          <img src="${featuredPost.image || '/images/placeholder-food.jpg'}" class="img-fluid rounded-start h-100" alt="${featuredPost.title}" style="object-fit: cover; min-height: 300px;" onerror="this.src='/images/placeholder-food.jpg'">
        </div>
        <div class="col-md-6">
          <div class="card-body h-100 d-flex flex-column p-4 p-lg-5">
            <div class="mb-3">
              <span class="badge badge-primary">${featuredPost.category || 'Food Guide'}</span>
              <span class="badge badge-warning ms-2">Featured</span>
            </div>
            <h2 class="card-title mb-3">${featuredPost.title}</h2>
            <p class="card-text flex-grow-1 text-muted">${featuredPost.excerpt}</p>

            <div class="d-flex justify-content-between align-items-center mb-3">
              <div class="d-flex align-items-center">
                <img src="${featuredPost.authorAvatar || '/images/placeholder-avatar.jpg'}" alt="${featuredPost.author}" class="rounded-circle me-3" width="40" height="40" onerror="this.src='/images/placeholder-avatar.jpg'">
                <div>
                  <h6 class="mb-0">${featuredPost.author}</h6>
                  <small class="text-muted">${this.formatDate(featuredPost.date)}</small>
                </div>
              </div>

              <div class="d-flex align-items-center text-muted">
                <small class="me-3">
                  ${this.renderLikeIcon(featuredPost)} ${featuredPost.likes || 0}
                </small>
                <small class="me-3">
                  <i class="far fa-comment me-1"></i> ${featuredPost.comments || 0}
                </small>
                <small>${featuredPost.readTime || '5 min read'}</small>
              </div>
            </div>

            <button class="btn btn-primary align-self-start" onclick="blogPage.readPost('${featuredPost.id}')">Read Story <i class="fas fa-arrow-right ms-2"></i></button>
          </div>
        </div>
      </div>
    `;

    featuredSection.html(`<div class="card border-0 shadow-sm">${featuredHtml}</div>`);
  },

  formatDate: function(dateString) {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch {
      return dateString;
    }
  },

  filterAndDisplayPosts: function() {
    if (!allBlogPosts || allBlogPosts.length === 0) return;
    filteredPosts = [...allBlogPosts];

    if (currentCategory) filteredPosts = filteredPosts.filter(p => p.category === currentCategory);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filteredPosts = filteredPosts.filter(p => (p.title || '').toLowerCase().includes(q) || (p.excerpt || '').toLowerCase().includes(q) || (p.tags || []).some(tag => (tag || '').toLowerCase().includes(q)));
    }

    currentPage = 1;
    displayedPosts = [];
    this.displayPosts();
    this.updateResultsCount();
  },

  displayPosts: function() {
    const start = (currentPage - 1) * postsPerPage;
    const end = start + postsPerPage;
    const postsToShow = filteredPosts.slice(start, end);
    displayedPosts = [...displayedPosts, ...postsToShow];
    const blogGrid = $('#blog-posts-grid');
    if (!blogGrid.length) return;

    this.renderPostsToContainer(blogGrid, postsToShow, currentPage === 1);
  },

  renderPostsToContainer: function(container, postsToShow, clearFirst) {
    if (clearFirst) container.empty();
    if (postsToShow.length === 0) {
      container.html('<div class="col-12"><p class="text-muted text-center">No blog posts found.</p></div>');
      return;
    }
    postsToShow.forEach(post => container.append(this.createPostCard(post)));
    this.updateLoadMoreButton();
  },

  // Persistence helpers
  getLikesByPost: function() {
    return JSON.parse(localStorage.getItem('likesByPost') || '{}');
  },

  getLikedPostsSet: function() {
    return new Set((JSON.parse(localStorage.getItem('likedPosts') || '[]')).map(String));
  },

  applyPersistenceToPosts: function(postsArray) {
    const likesMap = this.getLikesByPost();
    return postsArray.map(p => {
      const id = String(p.id);
      return { ...p, likes: likesMap[id] != null ? likesMap[id] : (p.likes || 0) };
    });
  },

  renderLikeIcon: function(post) {
    const liked = this.getLikedPostsSet();
    return liked.has(String(post.id)) ? `<i class="fas fa-heart text-danger me-1"></i>` : `<i class="far fa-heart me-1"></i>`;
  },

  createPostCard: function(post) {
    return `
      <div class="col-md-6 col-lg-4">
        <div class="card h-100 border-0 shadow-sm">
          <img src="${post.image || '/images/placeholder-food.jpg'}" class="card-img-top" alt="${post.title}" style="height: 200px; object-fit: cover;" onerror="this.src='/images/placeholder-food.jpg'">
          <div class="card-body d-flex flex-column">
            <div class="mb-2"><span class="badge badge-primary">${post.category}</span></div>
            <h5 class="card-title">${post.title}</h5>
            <p class="card-text text-muted flex-grow-1">${post.excerpt}</p>

            <div class="d-flex justify-content-between align-items-center mb-3">
              <div class="d-flex align-items-center">
                <img src="${post.authorAvatar || '/images/placeholder-avatar.jpg'}" alt="${post.author}" class="rounded-circle me-2" width="30" height="30" onerror="this.src='/images/placeholder-avatar.jpg'">
                <small class="text-muted">${post.author}</small>
              </div>
              <small class="text-muted">${post.readTime || '5 min read'}</small>
            </div>

            <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center text-muted">
                <small class="me-3">${this.renderLikeIcon(post)} ${post.likes || 0}</small>
                <small class="me-3"><i class="far fa-comment me-1"></i> ${post.comments || 0}</small>
              </div>
              <button class="btn btn-outline-primary btn-sm" onclick="blogPage.readPost('${post.id}')">Read More</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  updateResultsCount: function() {
    const resultsCount = $('#results-count');
    if (resultsCount.length) resultsCount.text(`Showing ${displayedPosts.length} of ${filteredPosts.length} posts`);
  },

  updateLoadMoreButton: function() {
    const loadMoreBtn = $('#load-more-btn');
    const loadMoreContainer = $('#load-more-container');
    if (!loadMoreBtn.length || !loadMoreContainer.length) return;
    if (displayedPosts.length >= filteredPosts.length) {
      loadMoreBtn.addClass('d-none');
      loadMoreContainer.hide();
    } else {
      loadMoreBtn.removeClass('d-none');
      loadMoreContainer.show();
    }
  },

  loadMorePosts: function() {
    currentPage++;
    this.displayPosts();
    this.updateResultsCount();
    this.updateLoadMoreButton();
  },

  filterByCategory: function(category) {
    currentCategory = currentCategory === category ? '' : category;
    $('.category-filter').removeClass('active');
    if (currentCategory) $(`.category-filter[data-category="${currentCategory}"]`).addClass('active');
    this.filterAndDisplayPosts();
  },

  clearSearch: function() {
    searchQuery = '';
    $('#blog-search').val('');
    $('#search-clear').addClass('d-none');
    this.filterAndDisplayPosts();
  },

  sortPosts: function(sortBy) {
    if (!sortBy) return;
    if (sortBy === 'date') sortBy = 'newest';
    try {
      switch (sortBy) {
        case 'newest':
          filteredPosts.sort((a, b) => new Date(b.date) - new Date(a.date)); break;
        case 'oldest':
          filteredPosts.sort((a, b) => new Date(a.date) - new Date(b.date)); break;
        case 'popular':
          filteredPosts.sort((a, b) => (b.likes || 0) - (a.likes || 0)); break;
        case 'title':
          filteredPosts.sort((a, b) => (a.title || '').localeCompare(b.title || '')); break;
        case 'author':
          filteredPosts.sort((a, b) => (a.author || '').localeCompare(b.author || '')); break;
      }
      currentPage = 1; displayedPosts = []; this.displayPosts(); this.updateResultsCount(); this.updateLoadMoreButton();
    } catch (err) {
      console.error('Sort error', err);
      if (window.utils && window.utils.showToast) window.utils.showToast('Error sorting posts', 'error');
    }
  },

  readPost: function(postId) {
    window.location.href = `blog-post.html?id=${postId}`;
  },

  loadWritersSection: function() {
  const writersSection = $('#writers-section');
  if (!writersSection.length || !allBlogPosts.length) return;

  // Count articles & likes per author
  const authorStats = {};
  allBlogPosts.forEach(post => {
    if (!authorStats[post.author]) {
      authorStats[post.author] = {
        name: post.author,
        avatar: post.authorAvatar || '/images/placeholder-avatar.jpg',
        posts: 0,
        likes: 0
      };
    }
    authorStats[post.author].posts++;
    authorStats[post.author].likes += (post.likes || 0);
  });

  // Sort authors by posts (then likes as tiebreaker)
  const sortedAuthors = Object.values(authorStats)
    .sort((a, b) => b.posts - a.posts || b.likes - a.likes);

  // Get top 3
  const topAuthors = sortedAuthors.slice(0, 3);

  // Function to build author card
  const buildAuthorCard = (author) => `
    <div class="col-md-4 mb-4 writer-card">
      <div class="text-center">
        <img src="${author.avatar}" alt="${author.name}" 
             class="rounded-circle mb-3" 
             width="80" height="80"
             onerror="this.src='/images/placeholder-avatar.jpg'">
        <h5>${author.name}</h5>
        <p class="text-muted">
          ${author.posts} article${author.posts === 1 ? '' : 's'} • ${author.likes} likes
        </p>
      </div>
    </div>
  `;

  // Render top 3 + hidden full list
  const writersHtml = `
    <div class="row" id="top-writers">
      ${topAuthors.map(buildAuthorCard).join('')}
    </div>
    <div class="row d-none" id="all-writers">
      ${sortedAuthors.map(buildAuthorCard).join('')}
    </div>
    <div class="text-center mt-3">
      <button class="btn btn-primary btn-lg" id="toggle-writers">See All Writers</button>
      
    </div>
  `;

  writersSection.html(writersHtml);

  // Toggle logic
  $('#toggle-writers').off('click').on('click', function() {
    const allWriters = $('#all-writers');
    const topWriters = $('#top-writers');

    if (allWriters.hasClass('d-none')) {
      // Expand
      topWriters.hide();
      allWriters.removeClass('d-none');
      $(this).text('Show Less');
    } else {
      // Collapse
      allWriters.addClass('d-none');
      topWriters.show();
      $(this).text('See All Writers');
    }
  });
},

  handleEmailSubscription: function(inputSelector, buttonSelectorOrForm) {
  // If a button is provided → bind to click
  // If a form is provided → bind to submit
  if (buttonSelectorOrForm) {
    $(buttonSelectorOrForm).off('click').click(() => this.subscribeEmail(inputSelector));
  } else {
    // default: bind form submission
    $(inputSelector).closest('form').off('submit').on('submit', (e) => {
      e.preventDefault();
      this.subscribeEmail(inputSelector);
    });
  }
},

subscribeEmail: function(inputSelector) {
  const email = $(inputSelector).val().trim();

  if (!email) {
    if (window.utils && window.utils.showToast) window.utils.showToast('Please enter your email.', 'danger');
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    if (window.utils && window.utils.showToast) window.utils.showToast('Invalid email address.', 'danger');
    return;
  }

  // Firestore REST API URL with API key
  const url = "https://firestore.googleapis.com/v1/projects/subscription-7cae3/databases/(default)/documents/subscribers?key=AIzaSyBY1E-HfG8yf9TKAjhVdZ-fKssTnNo5I4U";

  // use jQuery AJAX
  $.ajax({
    url: url,
    method: "POST",
    contentType: "application/json",
    data: JSON.stringify({
      fields: {
        email: { stringValue: email },
        createdAt: { timestampValue: new Date().toISOString() }
      }
    }),
    success: function(response) {
      if (window.utils && window.utils.showToast) {
        window.utils.showToast('🎉 Thank you for subscribing!', 'success');
      }
      console.log("✅ Subscribed:", response);
    },
    error: function(xhr, status, error) {
      console.error("❌ REST API error:", error, xhr.responseText);
      if (window.utils && window.utils.showToast) {
        window.utils.showToast('❌ Subscription failed.', 'danger');
      }
    },
    complete: function() {
      $(inputSelector).val(''); // Clear input after request
    }
  });
}};

$(document).ready(function() {
  blogPage.init();

  // Newsletter form (with input #newsletter-email inside #newsletter-form)
  
  blogPage.handleEmailSubscription('#newsletter-form input[type="email"]', null);


  // Footer subscribe (input + button)
  blogPage.handleEmailSubscription('#subscribe-email', '#subscribe-btn');
});
