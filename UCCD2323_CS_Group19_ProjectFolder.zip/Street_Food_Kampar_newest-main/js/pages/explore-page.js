/**
 * Kampar Street Food - Explore Page JavaScript (Full Functional)
 * Handles vendor search, filtering, sorting, view modes, map integration
 * Includes stub VendorAPI and StateManager hooks
 */

let vendorsMap;
let markersGroup;
let currentView = 'grid';
let filteredVendors = [];
let displayedVendors = [];
let vendorsPerPage = 12;
let currentPage = 1;

// ----------------- VendorAPI Stub -----------------
/*
const VendorAPI = {
    getAllVendors: async function() {
        // Replace this with real API call if available
        return new Promise(resolve => {
            setTimeout(() => {
                resolve([
                    { id: 1, name: 'Kampar Nasi Lemak', description: 'Traditional Nasi Lemak with sambal', photos:['/images/nasi-lemak.jpg'], rating:4.5, reviewsCount:120, distance:'0.5 km', category:'Local', priceBand:'RM', tags:['Halal','Spicy'], isVerified:true, phone:'0123456789', coordinates:{lat:4.327, lng:101.152} },
                    { id: 2, name: 'Curry Puff Corner', description: 'Crispy curry puffs for snacks', photos:['/images/curry-puff.jpg'], rating:4.2, reviewsCount:80, distance:'1.2 km', category:'Snacks', priceBand:'RM', tags:['Vegetarian'], isVerified:false, phone:'0123456790', coordinates:{lat:4.325, lng:101.148} },
                    // Add more mock vendors as needed
                ]);
            }, 500);
        });
    }
};

const VendorAPI = {
    getAllVendors: async function() {
        try {
            const response = await fetch('../data/vendors.json'); // 确认路径
            if (!response.ok) throw new Error('Failed to load vendors.json');
            const data = await response.json();
            return data;
        } catch (e) {
            console.error('Error loading vendors:', e);
            return []; // 出错时返回空数组
        }
    }
};
*/

// ----------------- App State -----------------
const appState = {
    vendors: [],
    searchQuery: '',
    filters: { category:'', priceRange:'', status:'', tags:[] }
};

// ----------------- Explore Vendors -----------------
const exploreVendors = {
    init:  function() {
        this.initializeFromURL();
        this.setupEventHandlers();
        this.setupSearch();
        this.loadVendors();
        this.initializeMap();
        if (typeof StateManager !== 'undefined') StateManager.updateFavoritesCount();
    },

    initializeFromURL: function() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('category')) appState.filters.category = urlParams.get('category');
        if (urlParams.get('price')) appState.filters.priceRange = urlParams.get('price');
        if (urlParams.get('status')) appState.filters.status = urlParams.get('status');
        if (urlParams.get('q')) {
            appState.searchQuery = urlParams.get('q');
            $('#vendor-search').val(appState.searchQuery);
        }
        if (urlParams.get('view')) {
            currentView = urlParams.get('view');
            this.switchView(currentView);
        }
    },

    setupEventHandlers: function() {
        $('.btn-group button').click((e) => {
            const view = $(e.target).closest('button').data('view');
            this.switchView(view);
        });

        $('#sort-select').change((e) => {
            this.sortVendors(e.target.value);
            this.updateURL();
        });

        $('#category-filter a').click((e) => {
            e.preventDefault();
            this.updateFilter('category', $(e.target).data('category'));
        });

        $('#price-filter a').click((e) => {
            e.preventDefault();
            this.updateFilter('priceRange', $(e.target).data('price'));
        });

        $('#status-filter a').click((e) => {
            e.preventDefault();
            this.updateFilter('status', $(e.target).data('status'));
        });

        $('#clear-filters').click(() => this.clearAllFilters());
        $('#load-more-btn').click(() => this.loadMoreVendors());
    },

    setupSearch: function() {
        const searchInput = $('#vendor-search');
        const clearButton = $('#search-clear');
        const debouncedSearch = utils.debounce((query) => {
            appState.searchQuery = query;
            this.filterAndDisplayVendors();
            this.updateURL();
        }, 300);

        searchInput.on('input', function() {
            const query = $(this).val().trim();
            debouncedSearch(query);
            clearButton.toggleClass('d-none', !query);
        });

        clearButton.click(() => {
            searchInput.val('');
            clearButton.addClass('d-none');
            appState.searchQuery = '';
            this.filterAndDisplayVendors();
            this.updateURL();
        });
    },

/*
    loadVendorsAsync: async function() {
        try {
            $('#loading-state').show();
            if (!appState.vendors.length) {
                appState.vendors = await VendorAPI.getAllVendors();
            }
            $('#loading-state').hide();
            if (!$('#sort-select').val()) $('#sort-select').val('name');
            this.filterAndDisplayVendors();
            this.updateActiveFiltersDisplay();
        } catch(e) {
            console.error('Error loading vendors:', e);
            $('#loading-state').hide();
            $('#no-results').show();
        }
    },
    */

   // Load vendors and initialize display
    loadVendors: function() {
        if (appState.vendors.length === 0) {
            setTimeout(() => this.loadVendors(), 100);
            return;
        }

        $('#loading-state').hide();
        
        // Initialize sort dropdown to default value
        const sortSelect = $('#sort-select');
        if (!sortSelect.val() || sortSelect.val() === '') {
            sortSelect.val('name');
        }
        
        this.filterAndDisplayVendors();
        this.updateActiveFiltersDisplay();
    },

    filterAndDisplayVendors: function() {
        filteredVendors = searchFilter.filterVendors(appState.vendors);
        this.sortVendors($('#sort-select').val());
        currentPage = 1;
        displayedVendors = filteredVendors.slice(0, vendorsPerPage);
        this.displayVendors();
        this.updateResultsCount();
        this.updateLoadMoreButton();
        this.updateMapView();
    },

    displayVendors: function() {
        const container = $('#vendors-grid');
        container.empty();
        if (!filteredVendors.length) {
            $('#no-results').show();
            return;
        } else $('#no-results').hide();

        displayedVendors.forEach(v => container.append(this.createVendorHTML(v)));
        if (typeof StateManager !== 'undefined') setTimeout(() => StateManager.initializeFavoritesUI(true), 150);
    },

    createVendorHTML: function(vendor) {
        const isOpen = utils.isVendorOpen(vendor);
        const statusBadge = isOpen 
            ? '<span class="badge badge-success">Open</span>'
            : '<span class="badge text-danger fw-bold" title="Closed">• Closed</span>';
        const mainPhoto = vendor.photos?.[0] || '/images/placeholder-food.jpg';
        return currentView === 'list'
            ? this.createListViewHTML(vendor, isOpen, statusBadge, mainPhoto)
            : this.createGridViewHTML(vendor, isOpen, statusBadge, mainPhoto);
    },

    createGridViewHTML: function(vendor,isOpen,statusBadge,mainPhoto){
        return `<div class="col-md-6 col-lg-4 vendor-item">
            <div class="card vendor-card h-100" onclick="window.location.href='vendor-details.html?id=${vendor.id}'">
                <div class="position-relative">
                    <img src="${mainPhoto}" class="card-img-top" alt="${vendor.name}" loading="lazy" style="height:200px;object-fit:cover;">
                    <button class="btn btn-icon favorite-btn position-absolute top-0 end-0 m-2 bg-white shadow-sm" data-vendor-id="${vendor.id}" onclick="event.stopPropagation();"><i class="far fa-heart"></i></button>
                    <div class="position-absolute bottom-0 start-0 m-2">${statusBadge}</div>
                    ${vendor.isVerified?'<div class="position-absolute top-0 start-0 m-2"><i class="fas fa-check-circle text-primary bg-white rounded-circle"></i></div>':''}
                </div>
                <div class="card-body">
                    <h5 class="card-title">${vendor.name}</h5>
                    <p class="card-text text-muted">${utils.truncateText(vendor.description,100)}</p>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="rating">${utils.generateStarRating(vendor.rating,'0.9rem')}<span class="rating-text ms-1">${vendor.rating}</span><span class="rating-count text-muted">(${vendor.reviewsCount})</span></div>
                        <span class="badge badge-warning">${vendor.priceBand}</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${vendor.distance}</small>
                        <span class="badge badge-secondary">${vendor.category}</span>
                    </div>
                    <div class="vendor-tags">${vendor.tags.slice(0,3).map(tag=>`<span class="badge bg-light text-dark me-1 mb-1">${tag}</span>`).join('')}</div>
                </div>
            </div>
        </div>`;
    },

    createListViewHTML: function(vendor,isOpen,statusBadge,mainPhoto){
        return `<div class="col-12 vendor-item">
            <div class="card vendor-card" onclick="window.location.href='vendor-details.html?id=${vendor.id}'">
                <div class="row g-0">
                    <div class="col-md-3 position-relative">
                        <img src="${mainPhoto}" class="img-fluid rounded-start h-100" alt="${vendor.name}" style="object-fit:cover;min-height:200px;">
                        <button class="btn btn-icon favorite-btn position-absolute top-0 end-0 m-2 bg-white shadow-sm" data-vendor-id="${vendor.id}" onclick="event.stopPropagation();"><i class="far fa-heart"></i></button>
                    </div>
                    <div class="col-md-9">
                        <div class="card-body h-100 d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title mb-0">${vendor.name}</h5>
                                <div class="d-flex align-items-center gap-2">${statusBadge}<span class="badge badge-warning">${vendor.priceBand}</span></div>
                            </div>
                            <p class="card-text text-muted">${utils.truncateText(vendor.description,200)}</p>
                            <div class="row g-3 mb-3">
                                <div class="col-sm-6">
                                    <div class="rating">${utils.generateStarRating(vendor.rating,'0.9rem')}<span class="rating-text ms-1">${vendor.rating}</span><span class="rating-count text-muted">(${vendor.reviewsCount} reviews)</span></div>
                                </div>
                                <div class="col-sm-6">
                                    <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i>${vendor.distance} • ${vendor.category}</small>
                                </div>
                            </div>
                            <div class="mt-auto d-flex justify-content-between align-items-center">
                                <div class="vendor-tags flex-grow-1">${vendor.tags.slice(0,4).map(tag=>`<span class="badge bg-light text-dark me-1 mb-1">${tag}</span>`).join('')}</div>
                                <div class="d-flex align-items-center gap-2">
                                    ${vendor.phone?`<button class="btn btn-sm btn-outline-primary" onclick="event.stopPropagation();window.open('tel:${vendor.phone}')"><i class="fas fa-phone"></i></button>`:''}
                                    <button class="btn btn-sm btn-primary" onclick="event.stopPropagation();window.location.href='vendor-details.html?id=${vendor.id}'">View Details</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>`;
    },

    switchView: function(view) {
        currentView = view;
        $('.btn-group button').removeClass('active');
        $(`#${view}-view`).addClass('active');

        if(view==='map'){
            $('#vendors-grid').hide();
            $('#map-container').show();
            $('#load-more-container').hide();
            this.initializeMap();
            this.updateMapView();
        } else {
            $('#map-container').hide();
            $('#vendors-grid').show();
            this.displayVendors();
            this.updateLoadMoreButton();
        }
        this.updateURL();
    },

    updateFilter: function(type,value){
        appState.filters[type] = value;
        this.filterAndDisplayVendors();
        this.updateActiveFiltersDisplay();
        this.updateURL();
    },

    clearAllFilters: function(){
        appState.searchQuery='';
        appState.filters={category:'',priceRange:'',status:'',tags:[]};
        $('#vendor-search').val('');
        $('#search-clear').addClass('d-none');
        this.filterAndDisplayVendors();
        this.updateActiveFiltersDisplay();
        this.updateURL();
    },

    updateActiveFiltersDisplay: function(){
        const chips = $('#filter-chips').empty();
        let hasFilters = false;
        const addChip = (label,key)=>{hasFilters=true;chips.append(`<span class="badge bg-primary">${label}<button class="btn-close btn-close-white ms-1" style="font-size:0.6em;" onclick="exploreVendors.updateFilter('${key}','')"></button></span>`);};
        if(appState.searchQuery) addChip(`Search: ${appState.searchQuery}`,'searchQuery');
        if(appState.filters.category) addChip(appState.filters.category,'category');
        if(appState.filters.priceRange) addChip(appState.filters.priceRange,'priceRange');
        if(appState.filters.status) addChip(appState.filters.status,'status');
        $('#active-filters').toggle(hasFilters);
        $('#clear-filters').toggle(hasFilters);
    },

    sortVendors: function(sortBy){
        if(!sortBy||!filteredVendors.length) return;
        const vendorsToSort = [...filteredVendors];
        try{
            switch(sortBy){
                case 'rating': vendorsToSort.sort((a,b)=>(b.rating||0)-(a.rating||0)); break;
                case 'distance': vendorsToSort.sort((a,b)=>parseFloat(a.distance||0)-parseFloat(b.distance||0)); break;
                case 'reviews': vendorsToSort.sort((a,b)=>(b.reviewsCount||0)-(a.reviewsCount||0)); break;
                default: vendorsToSort.sort((a,b)=>(a.name||'').localeCompare(b.name||'')); break;
            }
            filteredVendors=vendorsToSort;
            currentPage=1;
            displayedVendors=filteredVendors.slice(0,vendorsPerPage);
            this.displayVendors();
            this.updateLoadMoreButton();
        }catch(e){console.error('Error sorting vendors:',e);}
    },

    loadMoreVendors: function(){
        currentPage++;
        const end = currentPage*vendorsPerPage;
        const moreVendors = filteredVendors.slice((currentPage-1)*vendorsPerPage,end);
        moreVendors.forEach(v=>$('#vendors-grid').append(this.createVendorHTML(v)));
        displayedVendors=filteredVendors.slice(0,end);
        if(typeof StateManager!=='undefined') setTimeout(()=>StateManager.initializeFavoritesUI(true),150);
        this.updateLoadMoreButton();
    },

    updateLoadMoreButton: function(){
        $('#load-more-container').toggle(displayedVendors.length<filteredVendors.length && currentView!=='map');
    },

    updateResultsCount: function(){
        $('#results-count').text(filteredVendors.length===1?'1 vendor':`${filteredVendors.length} vendors`);
    },

    initializeMap: function(){
        if(!vendorsMap){
            vendorsMap=L.map('vendors-map').setView([4.3228,101.1506],13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).addTo(vendorsMap);
            markersGroup=L.markerClusterGroup();
            vendorsMap.addLayer(markersGroup);
        }
    },


updateMapView: function(){
    if(!vendorsMap || currentView !== 'map') return;
    markersGroup.clearLayers();

    filteredVendors.forEach(v => {
        if(v.coordinates){
            const mainPhoto = v.photos?.[0] || '/images/placeholder-food.jpg';
            const isOpen = utils.isVendorOpen(v);
            const statusBadge = isOpen 
                ? '<span class="badge badge-success">Open</span>'
                : '<span class="badge text-danger fw-bold" title="Closed">• Closed</span>';

            const popupHTML = `
                <div style="width:220px;">
                    <img src="${mainPhoto}" alt="${v.name}" style="width:100%; height:120px; object-fit:cover; border-radius:4px; margin-bottom:5px;">
                    <h6 style="margin:0 0 5px 0;">${v.name}</h6>
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <div class="rating">${utils.generateStarRating(v.rating,'0.8rem')}<span class="rating-text ms-1">${v.rating}</span><span class="rating-count text-muted">(${v.reviewsCount})</span></div>
                        <span class="badge badge-warning">${v.priceBand}</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <small class="text-muted">${v.distance} • ${v.category}</small>
                        ${statusBadge}
                    </div>
                    <p style="margin:5px 0; font-size:0.85rem; color:#555;">${utils.truncateText(v.description, 100)}</p>
                    <button class="btn btn-sm btn-primary w-100" onclick="window.location.href='vendor-details.html?id=${v.id}'">
                        View Details
                    </button>
                </div>
            `;
            const marker = L.marker([v.coordinates.lat, v.coordinates.lng]);
            marker.bindPopup(popupHTML);
            markersGroup.addLayer(marker);
        }
    });

    if(markersGroup.getLayers().length > 0) {
        vendorsMap.fitBounds(markersGroup.getBounds(), { padding: [20, 20] });
    }
},

    updateURL: function(){
        const params = new URLSearchParams();
        if(appState.searchQuery) params.set('q',appState.searchQuery);
        if(appState.filters.category) params.set('category',appState.filters.category);
        if(appState.filters.priceRange) params.set('price',appState.filters.priceRange);
        if(appState.filters.status) params.set('status',appState.filters.status);
        if(currentView!=='grid') params.set('view',currentView);
        history.replaceState(null,'',window.location.pathname + (params.toString()? '?' + params.toString():''));
    }
};

// ----------------- Initialize -----------------
$(document).ready(function(){
    setTimeout(()=>exploreVendors.init(),100);
    $(document).on('favoritesUpdated',()=>{if(typeof StateManager!=='undefined') StateManager.updateFavoritesCount();});
});

$(window).resize(()=>{if(vendorsMap&&currentView==='map') setTimeout(()=>vendorsMap.invalidateSize(),100);});

window.exploreVendors = exploreVendors;
