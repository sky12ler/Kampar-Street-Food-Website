/**
 * Submit Vendor Page JavaScript (REST API with API key)
 */

(function() {
  'use strict';

  const FIREBASE_PROJECT_ID = "subscription-7cae3";
  const FIRESTORE_COLLECTION = "submitVendors";
  const API_KEY = "AIzaSyBY1E-HfG8yf9TKAjhVdZ-fKssTnNo5I4U"; // Replace with your key
  const FIRESTORE_URL = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${FIRESTORE_COLLECTION}?key=${API_KEY}`;

  let form, submitBtn, submitText, submitSpinner, descriptionTextarea, descCountSpan;

  document.addEventListener('DOMContentLoaded', function() {
    console.log('submit-vendor.js loaded');
    initializeElements();
    setupEventListeners();
  });

  function initializeElements() {
    form = document.getElementById('submitVendorForm'); // Updated ID
    submitBtn = document.getElementById('submit-btn');
    submitText = document.getElementById('submit-text');
    submitSpinner = document.getElementById('submit-spinner');
    descriptionTextarea = document.getElementById('description');
    descCountSpan = document.getElementById('desc-count');

    if (!form) console.error('Submit vendor form not found');
  }

  function setupEventListeners() {
    if (!form) return;
    form.addEventListener('submit', handleFormSubmit);

    if (descriptionTextarea && descCountSpan) {
      descriptionTextarea.addEventListener('input', updateDescriptionCounter);
    }
  }

  function updateDescriptionCounter() {
    const current = descriptionTextarea.value.length;
    descCountSpan.textContent = current;
    if (current > 450) descCountSpan.parentElement.classList.add('text-warning');
    else descCountSpan.parentElement.classList.remove('text-warning');
  }

  function collectFormData() {
    return {
      name: document.getElementById('vendorName').value.trim(),
      category: document.getElementById('category').value,
      description: document.getElementById('description').value.trim(),
      priceRange: document.getElementById('priceRange').value,
      tags: document.getElementById('tags').value.trim(),
      ownerName: document.getElementById('ownerName').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      address: document.getElementById('address').value.trim(),
      email: document.getElementById('email').value.trim(),
      website: document.getElementById('website').value.trim(),
      operatingDays: document.getElementById('operatingDays').value,
      openTime: document.getElementById('openTime').value,
      closeTime: document.getElementById('closeTime').value,
      specialDishes: document.getElementById('specialDishes').value.trim(),
      additionalInfo: document.getElementById('additionalInfo').value.trim(),
      submitDate: new Date().toISOString()
    };
  }

  function setSubmitButtonLoading(isLoading) {
    if (isLoading) {
      submitBtn.disabled = true;
      submitText.textContent = 'Submitting...';
      submitSpinner.classList.remove('d-none');
    } else {
      submitBtn.disabled = false;
      submitText.textContent = 'Submit Vendor Information';
      submitSpinner.classList.add('d-none');
    }
  }

    function validateForm() {
  let isValid = true;

  // Vendor Name
  const vendorName = document.getElementById("vendorName");
  if (vendorName.value.trim().length < 3 || vendorName.value.trim().length > 100) {
    vendorName.classList.add("is-invalid");
    isValid = false;
  } else {
    vendorName.classList.remove("is-invalid");
  }

  // Category
  const category = document.getElementById("category");
  if (!category.value) {
    category.classList.add("is-invalid");
    isValid = false;
  } else {
    category.classList.remove("is-invalid");
  }

  // Description
  const description = document.getElementById("description");
  if (description.value.trim().length < 20 || description.value.trim().length > 500) {
    description.classList.add("is-invalid");
    isValid = false;
  } else {
    description.classList.remove("is-invalid");
  }

  // Price Range
  const priceRange = document.getElementById("priceRange");
  if (!priceRange.value) {
    priceRange.classList.add("is-invalid");
    isValid = false;
  } else {
    priceRange.classList.remove("is-invalid");
  }

  // Owner Name
  const ownerName = document.getElementById("ownerName");
  if (ownerName.value.trim().length < 2 || ownerName.value.trim().length > 100) {
    ownerName.classList.add("is-invalid");
    isValid = false;
  } else {
    ownerName.classList.remove("is-invalid");
  }

  // Phone Number (Malaysia format: +60123456789 or 0123456789)
  const phone = document.getElementById("phone");
  const phoneRegex = /^(\+60\d{8,9}|0\d{8,9})$/;
  if (!phoneRegex.test(phone.value.trim())) {
    phone.classList.add("is-invalid");
    isValid = false;
  } else {
    phone.classList.remove("is-invalid");
  }

  // Address
  const address = document.getElementById("address");
  if (address.value.trim().length < 10 || address.value.trim().length > 300) {
    address.classList.add("is-invalid");
    isValid = false;
  } else {
    address.classList.remove("is-invalid");
  }

  // Email
  const email = document.getElementById("email");
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.value.trim())) {
    email.classList.add("is-invalid");
    isValid = false;
  } else {
    email.classList.remove("is-invalid");
  }

  // Agreement checkbox
  const agreement = document.getElementById("agreement");
  if (!agreement.checked) {
    agreement.classList.add("is-invalid");
    isValid = false;
  } else {
    agreement.classList.remove("is-invalid");
  }

  return isValid;
}

     function handleFormSubmit(event) {
    event.preventDefault();

   

  // Run validation before submission
  if (!validateForm()) {
    alert("⚠️ Please fix the errors before submitting.");
    return;
  }
  
    const formData = collectFormData();

    // Convert to Firestore REST format
    const docData = { fields: {} };
    for (const key in formData) {
      if (key === 'submitDate') {
        docData.fields[key] = { timestampValue: formData[key] };
      } else {
        docData.fields[key] = { stringValue: formData[key] };
      }
    }

    setSubmitButtonLoading(true);

    // Use jQuery AJAX instead of fetch
    $.ajax({
      url: FIRESTORE_URL,
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify(docData),
      success: function(data) {
        alert(`✅ Submission successful! Document ID: ${data.name.split('/').pop()}`);
        form.reset();
        if (descCountSpan) descCountSpan.textContent = '0';
      },
      error: function(xhr, status, error) {
        console.error("❌ Submission failed:", error, xhr.responseText);
        alert(`❌ Submission failed: ${xhr.responseText || error}`);
      },
      complete: function() {
        setSubmitButtonLoading(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }
  
})();
