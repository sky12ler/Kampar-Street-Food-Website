/**
 * Resilient SessionStorage Wrapper
 */

// Storage availability cache
let storageAvailable = null;
let storageTestCompleted = false;

/**
 * Test if sessionStorage is available and functional
 * @returns {boolean} True if sessionStorage is available
 */
function testStorageAvailability() {
    if (storageTestCompleted) {
        return storageAvailable;
    }
    
    try {
        // Check if sessionStorage exists
        if (typeof sessionStorage === 'undefined') {
            storageAvailable = false;
            storageTestCompleted = true;
            return false;
        }
        
        // Test actual functionality with a temporary item
        const testKey = '__ss_test__' + Date.now();
        const testValue = 'test_value';
        
        sessionStorage.setItem(testKey, testValue);
        const retrieved = sessionStorage.getItem(testKey);
        sessionStorage.removeItem(testKey);
        
        storageAvailable = retrieved === testValue;
        storageTestCompleted = true;
        return storageAvailable;
        
    } catch (error) {
        // Common in private browsing mode or when storage is disabled
        console.warn('SessionStorage not available:', error.message);
        storageAvailable = false;
        storageTestCompleted = true;
        return false;
    }
}

/**
 * Get data from sessionStorage with JSON parsing
 * @param {string} key - Storage key
 * @param {*} fallback - Default value if key doesn't exist or parsing fails
 * @returns {*} Parsed value or fallback
 */
export function get(key, fallback = null) {
    try {
        // Validate inputs
        if (!key || typeof key !== 'string') {
            console.warn('SessionStorage get: key must be a non-empty string');
            return fallback;
        }
        
        // Check storage availability
        if (!testStorageAvailability()) {
            return fallback;
        }
        
        // Get raw value
        const rawValue = sessionStorage.getItem(key);
        
        // Return fallback if key doesn't exist
        if (rawValue === null) {
            return fallback;
        }
        
        // Parse JSON
        try {
            return JSON.parse(rawValue);
        } catch (parseError) {
            console.warn(`SessionStorage get: JSON parse error for key "${key}":`, parseError.message);
            // Clean up corrupted data
            sessionStorage.removeItem(key);
            return fallback;
        }
        
    } catch (error) {
        console.error(`SessionStorage get error for key "${key}":`, error.message);
        return fallback;
    }
}

/**
 * Set data in sessionStorage with JSON serialization
 * @param {string} key - Storage key
 * @param {*} value - Value to store (will be JSON.stringify'd)
 * @returns {boolean} True if successfully stored
 */
export function set(key, value) {
    try {
        // Validate inputs
        if (!key || typeof key !== 'string') {
            console.warn('SessionStorage set: key must be a non-empty string');
            return false;
        }
        
        // Check storage availability
        if (!testStorageAvailability()) {
            return false;
        }
        
        // Serialize value
        let serializedValue;
        try {
            serializedValue = JSON.stringify(value);
        } catch (serializeError) {
            console.warn(`SessionStorage set: JSON serialize error for key "${key}":`, serializeError.message);
            return false;
        }
        
        // Store value
        sessionStorage.setItem(key, serializedValue);
        
        // Verify storage by reading back
        const verification = sessionStorage.getItem(key);
        return verification === serializedValue;
        
    } catch (error) {
        // Handle quota exceeded or other storage errors
        if (error.name === 'QuotaExceededError') {
            console.warn('SessionStorage quota exceeded. Attempting cleanup...');
            attemptCleanup();
            
            // Try once more after cleanup
            try {
                const serializedValue = JSON.stringify(value);
                sessionStorage.setItem(key, serializedValue);
                return true;
            } catch (retryError) {
                console.error('SessionStorage set failed even after cleanup:', retryError.message);
                return false;
            }
        } else {
            console.error(`SessionStorage set error for key "${key}":`, error.message);
            return false;
        }
    }
}

/**
 * Delete a key from sessionStorage
 * @param {string} key - Key to delete
 * @returns {boolean} True if deletion was attempted (key may or may not have existed)
 */
export function del(key) {
    try {
        // Validate inputs
        if (!key || typeof key !== 'string') {
            console.warn('SessionStorage delete: key must be a non-empty string');
            return false;
        }
        
        // Check storage availability
        if (!testStorageAvailability()) {
            return true; // Return true since there's nothing to delete anyway
        }
        
        // Remove item
        sessionStorage.removeItem(key);
        
        // Verify removal
        return sessionStorage.getItem(key) === null;
        
    } catch (error) {
        console.error(`SessionStorage delete error for key "${key}":`, error.message);
        return false;
    }
}

/**
 * Check if a key exists in sessionStorage
 * @param {string} key - Key to check
 * @returns {boolean} True if key exists
 */
export function has(key) {
    try {
        // Validate inputs
        if (!key || typeof key !== 'string') {
            return false;
        }
        
        // Check storage availability
        if (!testStorageAvailability()) {
            return false;
        }
        
        return sessionStorage.getItem(key) !== null;
        
    } catch (error) {
        console.error(`SessionStorage has error for key "${key}":`, error.message);
        return false;
    }
}

/**
 * Clear all sessionStorage data
 * @returns {boolean} True if successfully cleared
 */
export function clear() {
    try {
        // Check storage availability
        if (!testStorageAvailability()) {
            return true; // Nothing to clear
        }
        
        sessionStorage.clear();
        return sessionStorage.length === 0;
        
    } catch (error) {
        console.error('SessionStorage clear error:', error.message);
        return false;
    }
}

/**
 * Get all keys in sessionStorage
 * @returns {string[]} Array of all keys
 */
export function keys() {
    try {
        // Check storage availability
        if (!testStorageAvailability()) {
            return [];
        }
        
        const allKeys = [];
        for (let i = 0; i < sessionStorage.length; i++) {
            const key = sessionStorage.key(i);
            if (key) {
                allKeys.push(key);
            }
        }
        
        return allKeys;
        
    } catch (error) {
        console.error('SessionStorage keys error:', error.message);
        return [];
    }
}

/**
 * Get storage usage information
 * @returns {Object} Object with usage statistics
 */
export function getUsageInfo() {
    try {
        if (!testStorageAvailability()) {
            return {
                available: false,
                keyCount: 0,
                estimatedSize: 0
            };
        }
        
        let estimatedSize = 0;
        const keyCount = sessionStorage.length;
        
        // Estimate total size by checking all stored data
        for (let i = 0; i < sessionStorage.length; i++) {
            const key = sessionStorage.key(i);
            if (key) {
                const value = sessionStorage.getItem(key);
                estimatedSize += (key.length + (value ? value.length : 0)) * 2; // Rough UTF-16 estimate
            }
        }
        
        return {
            available: true,
            keyCount,
            estimatedSize,
            estimatedSizeKB: Math.round(estimatedSize / 1024)
        };
        
    } catch (error) {
        console.error('SessionStorage usage info error:', error.message);
        return {
            available: false,
            keyCount: 0,
            estimatedSize: 0
        };
    }
}

/**
 * Attempt to cleanup old or large data to free up space
 * @returns {boolean} True if cleanup was attempted
 */
function attemptCleanup() {
    try {
        if (!testStorageAvailability()) {
            return false;
        }
        
        console.log('Attempting sessionStorage cleanup...');
        
        // Get all keys and their data sizes
        const keyData = [];
        for (let i = 0; i < sessionStorage.length; i++) {
            const key = sessionStorage.key(i);
            if (key) {
                const value = sessionStorage.getItem(key);
                const size = (key.length + (value ? value.length : 0)) * 2;
                keyData.push({ key, size });
            }
        }
        
        // Sort by size (largest first)
        keyData.sort((a, b) => b.size - a.size);
        
        // Remove the largest items (up to 25% of total keys)
        const itemsToRemove = Math.max(1, Math.floor(keyData.length * 0.25));
        let removedCount = 0;
        
        for (let i = 0; i < itemsToRemove && i < keyData.length; i++) {
            try {
                sessionStorage.removeItem(keyData[i].key);
                removedCount++;
            } catch (removeError) {
                console.warn(`Failed to remove key "${keyData[i].key}" during cleanup:`, removeError.message);
            }
        }
        
        console.log(`SessionStorage cleanup completed. Removed ${removedCount} items.`);
        return removedCount > 0;
        
    } catch (error) {
        console.error('SessionStorage cleanup error:', error.message);
        return false;
    }
}

// Export default object for convenience
export default {
    get,
    set,
    delete: del,
    has,
    clear,
    keys,
    getUsageInfo,
    isAvailable: () => testStorageAvailability()
};

// Alias for convenience
export const ss = {
    get,
    set,
    del,
    has,
    clear,
    keys,
    usage: getUsageInfo,
    available: () => testStorageAvailability()
};
