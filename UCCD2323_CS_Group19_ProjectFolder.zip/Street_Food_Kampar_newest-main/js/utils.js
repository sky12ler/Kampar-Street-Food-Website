/**
 * Utility functions for the Kampar Street Food website
 */

(function(window) {
    'use strict';

    const utils = {
        // Toast notification system
        showToast: function(message, type = 'info', duration = 5000) {
            // Create toast container if it doesn't exist
            let container = document.querySelector('.toast-container');
            if (!container) {
                container = document.createElement('div');
                container.className = 'toast-container position-fixed top-0 end-0 p-3';
                container.style.zIndex = '1055';
                document.body.appendChild(container);
            }

            // Create toast element
            const toastId = 'toast-' + Date.now();
            const toast = document.createElement('div');
            toast.id = toastId;
            toast.className = 'toast';
            toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
            toast.setAttribute('aria-live', 'assertive');
            toast.setAttribute('aria-atomic', 'true');
            
            // Set background color based on type
            const bgClass = type === 'success' ? 'bg-success' : 
                           type === 'error' ? 'bg-danger' : 
                           type === 'warning' ? 'bg-warning' : 'bg-primary';
            
            const textClass = type === 'warning' ? 'text-dark' : 'text-white';
            
            const iconClass = type === 'success' ? 'fa-check-circle' :
                             type === 'error' ? 'fa-exclamation-triangle' :
                             type === 'warning' ? 'fa-exclamation-circle' : 'fa-info-circle';

            toast.innerHTML = `
                <div class="toast-header ${bgClass} ${textClass} border-0">
                    <i class="fas ${iconClass} me-2"></i>
                    <strong class="me-auto">${this.capitalizeFirst(type)}</strong>
                    <button type="button" class="btn-close btn-close-${type === 'warning' ? 'dark' : 'white'}" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            `;

            container.appendChild(toast);

            // Initialize Bootstrap toast
            if (window.bootstrap) {
                const bsToast = new bootstrap.Toast(toast, {
                    delay: duration
                });
                bsToast.show();
                
                // Remove from DOM when hidden
                toast.addEventListener('hidden.bs.toast', function() {
                    toast.remove();
                });
            } else {
                // Fallback for non-Bootstrap setup
                toast.style.display = 'block';
                setTimeout(() => {
                    toast.remove();
                }, duration);
            }
        },

        // Capitalize first letter
        capitalizeFirst: function(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        },

        // Format price range
        formatPriceRange: function(range) {
            const ranges = {
                '$': 'Budget (Under RM10)',
                '$$': 'Moderate (RM10-20)',
                '$$$': 'Premium (Above RM20)'
            };
            return ranges[range] || range;
        },

        // Format phone number
        formatPhoneNumber: function(phone) {
            if (!phone) return '';
            
            // Remove all non-digits
            const digits = phone.replace(/\D/g, '');
            
            // Format Malaysian numbers
            if (digits.startsWith('60')) {
                // International format: +60 12 345 6789
                return `+${digits.slice(0, 2)} ${digits.slice(2, 4)} ${digits.slice(4, 7)} ${digits.slice(7)}`;
            } else if (digits.startsWith('01')) {
                // Local format: 012-345-6789
                return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
            }
            
            return phone; // Return original if format not recognized
        },

        // Validate email
        isValidEmail: function(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        // Validate URL
        isValidUrl: function(url) {
            try {
                new URL(url);
                return url.startsWith('http://') || url.startsWith('https://');
            } catch {
                return false;
            }
        },

        // Debounce function
        debounce: function(func, wait, immediate) {
            let timeout;
            return function executedFunction() {
                const context = this;
                const args = arguments;
                const later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                };
                const callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
            };
        },

        // Local storage helpers
        storage: {
            set: function(key, value) {
                try {
                    localStorage.setItem(key, JSON.stringify(value));
                    return true;
                } catch (e) {
                    console.error('Error saving to localStorage:', e);
                    return false;
                }
            },
            
            get: function(key, defaultValue = null) {
                try {
                    const item = localStorage.getItem(key);
                    return item ? JSON.parse(item) : defaultValue;
                } catch (e) {
                    console.error('Error reading from localStorage:', e);
                    return defaultValue;
                }
            },
            
            remove: function(key) {
                try {
                    localStorage.removeItem(key);
                    return true;
                } catch (e) {
                    console.error('Error removing from localStorage:', e);
                    return false;
                }
            }
        },

        // Scroll to element with smooth animation
        scrollToElement: function(element, offset = 0) {
            if (typeof element === 'string') {
                element = document.querySelector(element);
            }
            
            if (element) {
                const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
                window.scrollTo({
                    top: elementPosition - offset,
                    behavior: 'smooth'
                });
            }
        },

        // Format date
        formatDate: function(date, format = 'short') {
            if (!date) return '';
            
            const d = new Date(date);
            const options = format === 'long' 
                ? { year: 'numeric', month: 'long', day: 'numeric' }
                : { year: 'numeric', month: 'short', day: 'numeric' };
            
            return d.toLocaleDateString('en-MY', options);
        },

        // Loading state management
        setLoadingState: function(element, isLoading, loadingText = 'Loading...') {
            if (!element) return;
            
            if (isLoading) {
                element.disabled = true;
                element.dataset.originalText = element.textContent;
                element.innerHTML = `
                    <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    ${loadingText}
                `;
            } else {
                element.disabled = false;
                element.textContent = element.dataset.originalText || element.textContent;
            }
        },

        // Truncate text to specified length
        truncateText: function(text, maxLength, suffix = '...') {
            if (!text || text.length <= maxLength) return text;
            return text.substring(0, maxLength).trim() + suffix;
        },

        // Copy text to clipboard
        copyToClipboard: function(text) {
            return new Promise((resolve, reject) => {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text)
                        .then(() => resolve())
                        .catch(err => reject(err));
                } else {
                    // Fallback for older browsers
                    const textArea = document.createElement('textarea');
                    textArea.value = text;
                    textArea.style.position = 'fixed';
                    textArea.style.opacity = '0';
                    document.body.appendChild(textArea);
                    textArea.focus();
                    textArea.select();
                    
                    try {
                        const successful = document.execCommand('copy');
                        document.body.removeChild(textArea);
                        if (successful) {
                            resolve();
                        } else {
                            reject(new Error('Unable to copy to clipboard'));
                        }
                    } catch (err) {
                        document.body.removeChild(textArea);
                        reject(err);
                    }
                }
            });
        }
    };

    // Make utils available globally
    window.utils = utils;

})(window);