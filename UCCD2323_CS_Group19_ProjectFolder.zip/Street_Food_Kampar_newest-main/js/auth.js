// Authentication System for Kampar Street Food
// This must be loaded in the <head> of every page without defer/async

// Storage keys
const AUTH_KEY = 'kamparAuthData';
const USERS_KEY = 'kamparUsers';

// Current authentication state
let currentUser = null;

// Helper to get current storage (sessionStorage or localStorage)
function getAuthStorage() {
    // Try session first, fallback to localStorage if rememberMe was used
    return sessionStorage.getItem(AUTH_KEY) || localStorage.getItem(AUTH_KEY);
}

// Initialize authentication system
function initAuth() {
    const authDataStr = getAuthStorage();
    if (authDataStr) {
        try {
            const parsed = JSON.parse(authDataStr);
            if (parsed.isAuthenticated && parsed.sessionExpiry > Date.now()) {
                currentUser = parsed.user;
                return true;
            } else {
                // Session expired → clear both storages
                sessionStorage.removeItem(AUTH_KEY);
                localStorage.removeItem(AUTH_KEY);
            }
        } catch (error) {
            console.error('Error parsing auth data:', error);
            sessionStorage.removeItem(AUTH_KEY);
            localStorage.removeItem(AUTH_KEY);
        }
    }
    return false;
}

// Check authentication status and handle redirects
function checkAuth() {
    const isAuthenticated = initAuth();
    const currentPage = window.location.pathname;
    const isLoginPage = currentPage.endsWith('index.html') || currentPage === '/' || currentPage.endsWith('/');

    if (!isAuthenticated && !isLoginPage) {
        // Not authenticated and not on login page → redirect to login
        window.location.replace('/index.html');
        return false;
    } else if (isAuthenticated && isLoginPage) {
        // Authenticated but on login page → redirect to home
        window.location.replace('/home.html');
        return true;
    }

    return isAuthenticated;
}

// Register new user
function register(fullName, email, password, phone = '') {
    if (!fullName.trim()) return { success: false, message: 'Full name is required' };
    if (!isValidEmail(email)) return { success: false, message: 'Please enter a valid email address' };
    if (password.length < 6) return { success: false, message: 'Password must be at least 6 characters long' };

    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    if (users.find(user => user.email.toLowerCase() === email.toLowerCase())) {
        return { success: false, message: 'An account with this email already exists' };
    }

    const newUser = {
        id: Date.now().toString(),
        name: fullName.trim(),
        email: email.toLowerCase(),
        password: btoa(password), // demo only, not secure
        phone: phone.trim(),
        memberSince: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));

    return { success: true, message: 'Registration successful! Please log in.' };
}

// Login user
function login(email, password, rememberMe = false) {
    if (!email.trim()) return { success: false, message: 'Email is required' };
    if (!password.trim()) return { success: false, message: 'Password is required' };

    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === btoa(password));

    if (!user) return { success: false, message: 'Invalid email or password' };

    // Session duration logic
    const sessionDuration = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
    const authData = {
        isAuthenticated: true,
        sessionExpiry: Date.now() + sessionDuration,
        user: { id: user.id, name: user.name, email: user.email, phone: user.phone, memberSince: user.memberSince, isSubscribed: user.isSubscribed || false,  // ADD THIS LINE
            tier: user.tier || null }
    };

    // Save in correct storage
    if (rememberMe) {
        localStorage.setItem(AUTH_KEY, JSON.stringify(authData));
    } else {
        sessionStorage.setItem(AUTH_KEY, JSON.stringify(authData));
    }

    currentUser = authData.user;
    return { success: true, message: 'Login successful!' };
}

// Logout user
function logout() {
    sessionStorage.removeItem(AUTH_KEY);
    localStorage.removeItem(AUTH_KEY);
    currentUser = null;
    window.location.replace('/index.html?status=logged_out');
}

// Get current user info
function getCurrentUser() {
    return currentUser;
}

// Update user profile
function updateUserProfile(updatedData) {
    if (!currentUser) return { success: false, message: 'Not authenticated' };
    if (!updatedData.name || !updatedData.name.trim()) return { success: false, message: 'Name is required' };
    if (!isValidEmail(updatedData.email)) return { success: false, message: 'Please enter a valid email address' };

    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    if (updatedData.email.toLowerCase() !== currentUser.email.toLowerCase()) {
        if (users.find(u => u.email.toLowerCase() === updatedData.email.toLowerCase())) {
            return { success: false, message: 'An account with this email already exists' };
        }
    }

    const userIndex = users.findIndex(u => u.id === currentUser.id);
    if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], name: updatedData.name.trim(), email: updatedData.email.toLowerCase(), phone: updatedData.phone || '' };
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }

    // Update active session too
    const authDataStr = getAuthStorage();
    if (authDataStr) {
        const authData = JSON.parse(authDataStr);
        authData.user = { ...authData.user, name: updatedData.name.trim(), email: updatedData.email.toLowerCase(), phone: updatedData.phone || '' };
        sessionStorage.setItem(AUTH_KEY, JSON.stringify(authData)); // update both storages
        localStorage.setItem(AUTH_KEY, JSON.stringify(authData));
        currentUser = authData.user;
    }

    return { success: true, message: 'Profile updated successfully!'};
    
}

// Require authentication for a page
function requireAuth(redirectTo = '/index.html') {
    if (!checkAuth()) {
        window.location.replace(redirectTo);
        return false;
    }
    return true;
}

// Update navigation UI
function updateNavigation() {
    const loginLink = document.querySelector('a[href="profile.html"]');
    const navbarNav = document.getElementById('navbarNav');

    if (currentUser && loginLink && navbarNav) {
        const userDropdownHtml = `
            <li class="nav-item dropdown">
                <a id="userDropdownToggle" class="nav-link dropdown-toggle" href="#"
                   role="button" aria-expanded="false">
                    <i class="fas fa-user me-1"></i> ${currentUser.name.split(' ')[0]}
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="/profile.html"><i class="fas fa-cog me-2"></i>Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </li>
        `;
        loginLink.parentElement.outerHTML = userDropdownHtml;

        const userToggle = document.getElementById('userDropdownToggle');
        const userMenu = userToggle ? userToggle.parentElement.querySelector('.dropdown-menu') : null;
        const navbarCollapseEl = document.getElementById('navbarNav');

        if (userToggle && userMenu) {
            // Create Bootstrap Dropdown Instance
            const dropdown = new bootstrap.Dropdown(userToggle, {
                autoClose: false
            });

            // Show and hide toggle when clicked
            userToggle.addEventListener('click', e => {
                e.stopPropagation(); // prevent collapse
                e.preventDefault();

                if (userMenu.classList.contains('show')) {
                    dropdown.hide();
                } else {
                    dropdown.show();
                }
            });

            userMenu.addEventListener('click', e => e.stopPropagation());
        }

        if (navbarCollapseEl) {
            navbarCollapseEl.addEventListener('hide.bs.collapse', e => {
                if (userMenu && userMenu.classList.contains('show')) {
                    e.preventDefault();
                }
            });
        }
    }
}

// Utility: validate email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Utility: show alert messages
function showAlert(message, type = 'info') {
    document.querySelectorAll('.alert-auth').forEach(alert => alert.remove());

    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show alert-auth`;
    alertDiv.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;

    const container = document.querySelector('.container') || document.querySelector('main') || document.body;
    container.insertBefore(alertDiv, container.firstElementChild || null);

    if (type === 'success') {
        setTimeout(() => alertDiv.remove(), 5000);
    }
}

// Initialize demo users if none exist
function initDemoUsers() {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    if (users.length === 0) {
        const demoUsers = [
            { id: '1', name: 'Ahmad Bin Abdullah', email: 'ahmad@example.com', password: btoa('password123'), phone: '012-345-6789', memberSince: '2024-01-15T10:00:00.000Z',isSubscribed: true,   tier: 'premium' },
            { id: '2', name: 'Siti Nurhaliza', email: 'siti@example.com', password: btoa('password123'), phone: '013-456-7890', memberSince: '2024-02-20T14:30:00.000Z', isSubscribed: false, tier: null  }
        ];
        localStorage.setItem(USERS_KEY, JSON.stringify(demoUsers));
    }
}

// Show logout success message
function checkStatusMessage() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('status') === 'logged_out') {
        showAlert('You have been successfully logged out.', 'success');
        window.history.replaceState({}, document.title, window.location.pathname);
    }
}

// Update user subscription
function updateUserSubscription(plan, isSubscribed = true) {
    if (!currentUser) return { success: false, message: 'Not authenticated' };
    
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    
    if (userIndex !== -1) {
        users[userIndex].isSubscribed = isSubscribed;
        users[userIndex].tier = plan;
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
        
        // Update active session too
        const authDataStr = getAuthStorage();
        if (authDataStr) {
            const authData = JSON.parse(authDataStr);
            authData.user.isSubscribed = isSubscribed;
            authData.user.tier = plan;
            sessionStorage.setItem(AUTH_KEY, JSON.stringify(authData));
            localStorage.setItem(AUTH_KEY, JSON.stringify(authData));
            currentUser = authData.user;
        }
        
        return { success: true, message: 'Subscription updated successfully!' };
    }
    
    return { success: false, message: 'User not found' };
}

// Get user subscription status
function getUserSubscription() {
    if (!currentUser) return null;
    
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const user = users.find(u => u.id === currentUser.id);
    
    if (user) {
        return {
            isSubscribed: user.isSubscribed || false,
            tier: user.tier || null
        };
    }
    
    return null;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function () {
    initDemoUsers();
    checkStatusMessage();
    if (currentUser) updateNavigation();

});

// Run auth check early
checkAuth();
