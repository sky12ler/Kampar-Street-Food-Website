/**
 * Cookie Consent Management System
 */

import { setCookie, getCookie } from './cookies.js';

// Configuration constants
const CONSENT_COOKIE_NAME = 'kampar_consent';
const CATEGORY_COOKIE_NAME = 'kampar_last_category';
const COOKIE_EXPIRY_DAYS = 180;

/**
 * Initialize the cookie consent system
 * Should be called when DOM is ready
 */
export function initConsentBanner() {
    // Check if user has already given consent
    const hasConsent = getCookie(CONSENT_COOKIE_NAME);
    
    if (!hasConsent) {
        showConsentBanner();
    }
    
    // Initialize category tracking regardless of consent status
    initCategoryTracking();
    
    // Highlight last visited category if we have consent
    if (hasConsent === 'true') {
        highlightLastCategory();
    }
}

/**
 * Show the cookie consent banner with accessibility features
 */
function showConsentBanner() {
    const banner = document.getElementById('cookieBanner');
    if (!banner) {
        console.error('Cookie banner element not found. Ensure #cookieBanner exists in HTML.');
        return;
    }
    
    // Make banner visible
    banner.hidden = false;
    banner.setAttribute('aria-hidden', 'false');
    
    // Set focus to accept button for accessibility
    const acceptBtn = document.getElementById('cookieAccept');
    if (acceptBtn) {
        // Small delay to ensure banner is fully visible
        setTimeout(() => {
            acceptBtn.focus();
        }, 100);
        
        // Add click handler
        acceptBtn.addEventListener('click', handleAcceptConsent, { once: true });
    }
    
    // Add keyboard event listeners
    document.addEventListener('keydown', handleKeyboardEvents);
    banner.addEventListener('keydown', handleBannerKeyboard);
    
    // Announce to screen readers
    announceToScreenReader('Cookie consent banner is now visible. Press Tab to navigate or Escape to accept.');
}

/**
 * Handle consent acceptance
 */
function handleAcceptConsent() {
    // Set consent cookie
    const success = setCookie(CONSENT_COOKIE_NAME, 'true', COOKIE_EXPIRY_DAYS);
    
    if (success) {
        hideConsentBanner();
        announceToScreenReader('Cookie consent accepted. Thank you.');
        
        // Now that we have consent, highlight last category if available
        highlightLastCategory();
    } else {
        console.error('Failed to set consent cookie');
        announceToScreenReader('Error setting consent preference. Please try again.');
    }
}

/**
 * Hide the consent banner
 */
function hideConsentBanner() {
    const banner = document.getElementById('cookieBanner');
    if (banner) {
        banner.hidden = true;
        banner.setAttribute('aria-hidden', 'true');
    }
    
    // Remove event listeners
    document.removeEventListener('keydown', handleKeyboardEvents);
    banner?.removeEventListener('keydown', handleBannerKeyboard);
    
    // Return focus to main content
    const mainContent = document.querySelector('main') || document.body;
    if (mainContent) {
        mainContent.focus();
    }
}

/**
 * Handle global keyboard events (primarily ESC key)
 */
function handleKeyboardEvents(event) {
    if (event.key === 'Escape') {
        event.preventDefault();
        handleAcceptConsent(); // Treat ESC as acceptance for UX
    }
}

/**
 * Handle keyboard navigation within the banner (focus trapping)
 */
function handleBannerKeyboard(event) {
    if (event.key !== 'Tab') return;
    
    const banner = document.getElementById('cookieBanner');
    const focusableElements = banner.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    // Trap focus within banner
    if (event.shiftKey) {
        // Shift+Tab - move to previous element
        if (document.activeElement === firstElement) {
            lastElement.focus();
            event.preventDefault();
        }
    } else {
        // Tab - move to next element
        if (document.activeElement === lastElement) {
            firstElement.focus();
            event.preventDefault();
        }
    }
}

/**
 * Initialize category tracking on homepage
 */
export function initCategoryTracking() {
    // Only run on homepage
    if (!isHomepage()) return;
    
    // Find all category cards/links
    const categoryElements = document.querySelectorAll([
        '.category-card',
        '.category-item',
        '[data-category]',
        '.food-category',
        '.category-link'
    ].join(', '));
    
    categoryElements.forEach(element => {
        element.addEventListener('click', handleCategoryClick);
    });
}

/**
 * Handle category click for tracking
 */
function handleCategoryClick(event) {
    const hasConsent = getCookie(CONSENT_COOKIE_NAME);
    if (hasConsent !== 'true') return; // Only track if user has consented
    
    let categoryName = '';
    
    // Try multiple ways to get category name
    const element = event.currentTarget;
    
    // Priority order for finding category name
    categoryName = element.dataset.category ||
                  element.getAttribute('data-category') ||
                  element.querySelector('.category-name')?.textContent ||
                  element.querySelector('h3')?.textContent ||
                  element.querySelector('h4')?.textContent ||
                  element.textContent?.trim() ||
                  '';
    
    if (categoryName) {
        // Clean and normalize category name
        categoryName = categoryName.replace(/\s+/g, ' ').trim();
        trackLastCategory(categoryName);
    }
}

/**
 * Track the last visited category
 */
export function trackLastCategory(categoryName) {
    const hasConsent = getCookie(CONSENT_COOKIE_NAME);
    if (hasConsent !== 'true') return; // Only track with consent
    
    if (categoryName && typeof categoryName === 'string') {
        const success = setCookie(CATEGORY_COOKIE_NAME, categoryName, COOKIE_EXPIRY_DAYS);
        if (success) {
            console.log(`Last category tracked: ${categoryName}`);
            // Re-highlight categories after tracking
            setTimeout(highlightLastCategory, 100);
        }
    }
}

/**
 * Highlight the last visited category on homepage
 */
export function highlightLastCategory() {
    // Only run on homepage
    if (!isHomepage()) return;
    
    const hasConsent = getCookie(CONSENT_COOKIE_NAME);
    if (hasConsent !== 'true') return; // Only highlight with consent
    
    const lastCategory = getCookie(CATEGORY_COOKIE_NAME);
    if (!lastCategory) return;
    
    // Remove existing highlights first
    document.querySelectorAll('.is-last-visited').forEach(el => {
        el.classList.remove('is-last-visited');
    });
    
    // Find matching category elements
    const categoryElements = document.querySelectorAll([
        '.category-card',
        '.category-item', 
        '[data-category]',
        '.food-category',
        '.category-link'
    ].join(', '));
    
    categoryElements.forEach(element => {
        const elementCategory = element.dataset.category ||
                               element.getAttribute('data-category') ||
                               element.querySelector('.category-name')?.textContent ||
                               element.querySelector('h3')?.textContent ||
                               element.querySelector('h4')?.textContent ||
                               element.textContent?.trim() ||
                               '';
        
        // Normalize for comparison
        const normalizedElement = elementCategory.replace(/\s+/g, ' ').trim().toLowerCase();
        const normalizedLast = lastCategory.replace(/\s+/g, ' ').trim().toLowerCase();
        
        if (normalizedElement === normalizedLast) {
            element.classList.add('is-last-visited');
            
            // Add check mark indicator
            if (!element.querySelector('.last-visited-indicator')) {
                const indicator = document.createElement('div');
                indicator.className = 'last-visited-indicator';
                indicator.innerHTML = '<i class="fas fa-check" aria-hidden="true"></i>';
                indicator.setAttribute('title', 'Last visited category');
                element.appendChild(indicator);
            }
        }
    });
}

/**
 * Check if current page is homepage
 */
function isHomepage() {
    const path = window.location.pathname;
    return path === '/' || path === '/home.html' || path === '/index.html' || 
           path.endsWith('/home.html') || document.body.classList.contains('homepage');
}

/**
 * Announce message to screen readers
 */
function announceToScreenReader(message) {
    try {
        // Create temporary element for screen reader announcement
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only'; // Screen reader only
        announcement.textContent = message;
        
        document.body.appendChild(announcement);
        
        // Remove after announcement
        setTimeout(() => {
            if (announcement.parentNode) {
                announcement.parentNode.removeChild(announcement);
            }
        }, 1000);
        
    } catch (error) {
        console.error('Error announcing to screen reader:', error);
    }
}

/**
 * Check if user has given consent
 */
export function hasUserConsent() {
    return getCookie(CONSENT_COOKIE_NAME) === 'true';
}

/**
 * Clear all consent and tracking cookies
 */
export function clearConsentData() {
    setCookie(CONSENT_COOKIE_NAME, '', -1);
    setCookie(CATEGORY_COOKIE_NAME, '', -1);
    
    // Remove visual highlights
    document.querySelectorAll('.is-last-visited').forEach(el => {
        el.classList.remove('is-last-visited');
    });
    
    // Remove indicators
    document.querySelectorAll('.last-visited-indicator').forEach(el => {
        el.remove();
    });
}

// Export default object for convenience
export default {
    init: initConsentBanner,
    track: trackLastCategory,
    highlight: highlightLastCategory,
    hasConsent: hasUserConsent,
    clear: clearConsentData
};
