/**
 * Filter State Persistence System
 */

import { set, get, del, has } from './ss.js';

// Configuration
const STORAGE_KEY = 'explore_filters_state';
const EXPLORE_PAGE_PATHS = ['/explore.html', '/explore', 'explore.html'];
const AUTO_SAVE_DELAY = 300; // milliseconds
const URL_SYNC_ENABLED = false; // Set to true to sync with URL parameters

// State management
let currentFilters = {};
let isInitialized = false;
let saveTimeout = null;
let lastPopstateTime = 0;

/**
 * Initialize filter persistence system
 */
export function initFilterPersistence() {
    // Only initialize on explore page
    if (!isExplorePage()) {
        console.log('Filter persistence skipped - not on explore page');
        return;
    }
    
    if (isInitialized) {
        console.warn('Filter persistence already initialized');
        return;
    }
    
    console.log('Initializing filter persistence system...');
    
    // Wait for DOM if needed
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            performInitialization();
        });
    } else {
        performInitialization();
    }
}

/**
 * Internal initialization function
 */
function performInitialization() {
    try {
        // Restore saved filter state
        restoreFilterState();
        
        // Set up filter monitoring
        setupFilterMonitoring();
        
        // Set up browser navigation handling
        setupPopstateHandling();
        
        // Set up custom event listeners
        setupCustomEventListeners();
        
        isInitialized = true;
        console.log('Filter persistence system initialized successfully');
        
        // Notify other scripts that filters are ready
        dispatchFilterEvent('filtersInitialized', { filters: currentFilters });
        
    } catch (error) {
        console.error('Error initializing filter persistence:', error);
    }
}

/**
 * Check if current page is the explore page
 * @returns {boolean} True if on explore page
 */
function isExplorePage() {
    const path = window.location.pathname;
    return EXPLORE_PAGE_PATHS.some(explorePath => 
        path === explorePath || path.endsWith(explorePath)
    ) || document.body.classList.contains('explore-page');
}

/**
 * Restore saved filter state from sessionStorage
 */
function restoreFilterState() {
    try {
        const savedFilters = get(STORAGE_KEY, {});
        console.log('Restoring filter state:', savedFilters);
        
        if (Object.keys(savedFilters).length === 0) {
            console.log('No saved filter state found');
            return;
        }
        
        currentFilters = { ...savedFilters };
        
        // Apply filters to UI elements
        applyFiltersToUI(currentFilters);
        
        // Trigger filter application (if filter system is ready)
        setTimeout(() => {
            applyFilters(currentFilters);
        }, 100);
        
    } catch (error) {
        console.error('Error restoring filter state:', error);
        currentFilters = {};
    }
}

/**
 * Apply filter state to UI elements
 * @param {Object} filters - Filter state object
 */
function applyFiltersToUI(filters) {
    try {
        console.log('Applying filters to UI:', filters);
        
        // Category filter
        if (filters.category) {
            const categoryElements = document.querySelectorAll([
                '#categoryFilter',
                '[name="category"]',
                '.category-filter',
                '[data-filter-type="category"]'
            ].join(', '));
            
            categoryElements.forEach(element => {
                if (element.tagName.toLowerCase() === 'select') {
                    element.value = filters.category;
                } else if (element.type === 'radio') {
                    element.checked = element.value === filters.category;
                }
            });
        }
        
        // Price range filter
        if (filters.priceRange) {
            const priceElements = document.querySelectorAll([
                '#priceFilter',
                '[name="priceRange"]',
                '.price-filter',
                '[data-filter-type="price"]'
            ].join(', '));
            
            priceElements.forEach(element => {
                if (element.tagName.toLowerCase() === 'select') {
                    element.value = filters.priceRange;
                } else if (element.type === 'radio') {
                    element.checked = element.value === filters.priceRange;
                }
            });
        }
        
        // Status filter
        if (filters.status) {
            const statusElements = document.querySelectorAll([
                '#statusFilter',
                '[name="status"]',
                '.status-filter',
                '[data-filter-type="status"]'
            ].join(', '));
            
            statusElements.forEach(element => {
                if (element.tagName.toLowerCase() === 'select') {
                    element.value = filters.status;
                } else if (element.type === 'radio') {
                    element.checked = element.value === filters.status;
                } else if (element.type === 'checkbox') {
                    element.checked = filters.status === 'true' || filters.status === true;
                }
            });
        }
        
        // Search query
        if (filters.search) {
            const searchElements = document.querySelectorAll([
                '#searchInput',
                '[name="search"]',
                '.search-input',
                '[data-filter-type="search"]'
            ].join(', '));
            
            searchElements.forEach(element => {
                element.value = filters.search;
            });
        }
        
        // Custom filters
        Object.entries(filters).forEach(([filterName, filterValue]) => {
            if (!['category', 'priceRange', 'status', 'search'].includes(filterName)) {
                const customElements = document.querySelectorAll(`[data-filter="${filterName}"]`);
                
                customElements.forEach(element => {
                    if (element.tagName.toLowerCase() === 'select') {
                        element.value = filterValue;
                    } else if (element.type === 'checkbox') {
                        element.checked = filterValue === 'true' || filterValue === true;
                    } else if (element.type === 'radio') {
                        element.checked = element.value === filterValue;
                    } else if (element.type === 'text' || element.type === 'search') {
                        element.value = filterValue;
                    }
                });
            }
        });
        
        // Trigger change events to update UI
        setTimeout(() => {
            triggerUIUpdateEvents();
        }, 50);
        
    } catch (error) {
        console.error('Error applying filters to UI:', error);
    }
}

/**
 * Apply filters to the actual filtering system
 * @param {Object} filters - Filter state object
 */
function applyFilters(filters) {
    try {
        // Dispatch custom event for filter system to pick up
        dispatchFilterEvent('filtersApplied', { filters });
        
        // If there's a global filter function, call it
        if (typeof window.applyFilters === 'function') {
            window.applyFilters(filters);
        }
        
        // Try common filter function names
        const filterFunctions = [
            'filterVendors',
            'applyVendorFilters',
            'updateFilters',
            'runFilters'
        ];
        
        filterFunctions.forEach(funcName => {
            if (typeof window[funcName] === 'function') {
                try {
                    window[funcName](filters);
                } catch (funcError) {
                    console.warn(`Error calling ${funcName}:`, funcError);
                }
            }
        });
        
    } catch (error) {
        console.error('Error applying filters:', error);
    }
}

/**
 * Set up monitoring for filter changes
 */
function setupFilterMonitoring() {
    try {
        // Find all filter elements
        const filterSelectors = [
            '#categoryFilter', '#priceFilter', '#statusFilter', '#searchInput',
            '[name="category"]', '[name="priceRange"]', '[name="status"]', '[name="search"]',
            '.category-filter', '.price-filter', '.status-filter', '.search-input',
            '[data-filter-type]', '[data-filter]'
        ];
        
        const filterElements = document.querySelectorAll(filterSelectors.join(', '));
        
        console.log(`Found ${filterElements.length} filter elements to monitor`);
        
        // Add event listeners
        filterElements.forEach(element => {
            const events = getFilterEvents(element);
            
            events.forEach(eventType => {
                element.addEventListener(eventType, (event) => {
                    handleFilterChange(event);
                });
            });
        });
        
        // Also listen for custom filter events
        document.addEventListener('filterChanged', (event) => {
            if (event.detail && event.detail.filterName && event.detail.filterValue !== undefined) {
                updateFilter(event.detail.filterName, event.detail.filterValue);
            }
        });
        
    } catch (error) {
        console.error('Error setting up filter monitoring:', error);
    }
}

/**
 * Get relevant events for a filter element
 * @param {HTMLElement} element - Filter element
 * @returns {string[]} Array of event names
 */
function getFilterEvents(element) {
    const tagName = element.tagName.toLowerCase();
    const type = element.type ? element.type.toLowerCase() : '';
    
    const events = ['change']; // All filter elements get change event
    
    // Add input event for text-like inputs
    if (tagName === 'input' && ['text', 'search'].includes(type)) {
        events.push('input');
        events.push('keyup'); // For immediate response
    }
    
    return events;
}

/**
 * Handle filter change events
 * @param {Event} event - Change event
 */
function handleFilterChange(event) {
    try {
        const element = event.target;
        const filterName = getFilterName(element);
        const filterValue = getFilterValue(element);
        
        console.log(`Filter changed: ${filterName} = ${filterValue}`);
        
        updateFilter(filterName, filterValue);
        
    } catch (error) {
        console.error('Error handling filter change:', error);
    }
}

/**
 * Get filter name from element
 * @param {HTMLElement} element - Filter element
 * @returns {string} Filter name
 */
function getFilterName(element) {
    return element.dataset.filter ||
           element.dataset.filterType ||
           element.name ||
           element.id ||
           'unknown';
}

/**
 * Get filter value from element
 * @param {HTMLElement} element - Filter element
 * @returns {*} Filter value
 */
function getFilterValue(element) {
    const tagName = element.tagName.toLowerCase();
    const type = element.type ? element.type.toLowerCase() : '';
    
    switch (type) {
        case 'checkbox':
            return element.checked;
        case 'radio':
            return element.checked ? element.value : null;
        default:
            return element.value;
    }
}

/**
 * Update a specific filter
 * @param {string} filterName - Name of the filter
 * @param {*} filterValue - Value of the filter
 */
export function updateFilter(filterName, filterValue) {
    try {
        // Update current filters
        if (filterValue === null || filterValue === '' || filterValue === undefined) {
            delete currentFilters[filterName];
        } else {
            currentFilters[filterName] = filterValue;
        }
        
        // Schedule save
        scheduleFilterSave();
        
        // Sync with URL if enabled
        if (URL_SYNC_ENABLED) {
            syncFiltersToURL();
        }
        
        console.log('Filter updated:', filterName, '=', filterValue);
        console.log('Current filters:', currentFilters);
        
    } catch (error) {
        console.error('Error updating filter:', error);
    }
}

/**
 * Schedule a debounced filter save
 */
function scheduleFilterSave() {
    // Clear existing timeout
    if (saveTimeout) {
        clearTimeout(saveTimeout);
    }
    
    // Set new timeout
    saveTimeout = setTimeout(() => {
        saveFilterState();
        saveTimeout = null;
    }, AUTO_SAVE_DELAY);
}

/**
 * Save current filter state to sessionStorage
 */
function saveFilterState() {
    try {
        const success = set(STORAGE_KEY, currentFilters);
        
        if (success) {
            console.log('Filter state saved:', currentFilters);
        } else {
            console.warn('Failed to save filter state');
        }
        
    } catch (error) {
        console.error('Error saving filter state:', error);
    }
}

/**
 * Set up browser back/forward navigation handling
 */
function setupPopstateHandling() {
    try {
        // Save initial state
        if (history.state === null) {
            history.replaceState({ filters: currentFilters }, '', window.location.href);
        }
        
        // Listen for popstate events (back/forward navigation)
        window.addEventListener('popstate', (event) => {
            handlePopstateEvent(event);
        });
        
        console.log('Popstate handling set up');
        
    } catch (error) {
        console.error('Error setting up popstate handling:', error);
    }
}

/**
 * Handle browser back/forward navigation
 * @param {PopStateEvent} event - Popstate event
 */
function handlePopstateEvent(event) {
    try {
        const now = Date.now();
        
        // Prevent rapid-fire popstate events
        if (now - lastPopstateTime < 100) {
            return;
        }
        lastPopstateTime = now;
        
        console.log('Popstate event detected');
        
        let filtersToRestore = {};
        
        // Try to get filters from history state
        if (event.state && event.state.filters) {
            filtersToRestore = event.state.filters;
        } else {
            // Fallback to saved filters
            filtersToRestore = get(STORAGE_KEY, {});
        }
        
        console.log('Restoring filters from navigation:', filtersToRestore);
        
        // Update current filters
        currentFilters = { ...filtersToRestore };
        
        // Apply to UI and filtering system
        applyFiltersToUI(currentFilters);
        setTimeout(() => {
            applyFilters(currentFilters);
        }, 100);
        
    } catch (error) {
        console.error('Error handling popstate event:', error);
    }
}

/**
 * Set up custom event listeners
 */
function setupCustomEventListeners() {
    // Listen for filter clear events
    document.addEventListener('clearFilters', () => {
        clearAllFilters();
    });
    
    // Listen for filter reset events
    document.addEventListener('resetFilters', () => {
        resetFilters();
    });
    
    // Listen for manual filter updates
    document.addEventListener('updateFilters', (event) => {
        if (event.detail && event.detail.filters) {
            Object.entries(event.detail.filters).forEach(([name, value]) => {
                updateFilter(name, value);
            });
        }
    });
}

/**
 * Clear all filters
 */
export function clearAllFilters() {
    try {
        console.log('Clearing all filters');
        
        currentFilters = {};
        
        // Save empty state
        set(STORAGE_KEY, currentFilters);
        
        // Clear UI
        clearFiltersFromUI();
        
        // Apply empty filters
        applyFilters(currentFilters);
        
        // Dispatch event
        dispatchFilterEvent('filtersCleared', { filters: currentFilters });
        
    } catch (error) {
        console.error('Error clearing all filters:', error);
    }
}

/**
 * Reset filters to default state
 */
function resetFilters() {
    try {
        console.log('Resetting filters to defaults');
        
        // Define default filters (customize as needed)
        const defaultFilters = {
            category: '',
            priceRange: '',
            status: '',
            search: ''
        };
        
        currentFilters = { ...defaultFilters };
        
        // Save default state
        set(STORAGE_KEY, currentFilters);
        
        // Apply to UI and filtering system
        applyFiltersToUI(currentFilters);
        applyFilters(currentFilters);
        
        // Dispatch event
        dispatchFilterEvent('filtersReset', { filters: currentFilters });
        
    } catch (error) {
        console.error('Error resetting filters:', error);
    }
}

/**
 * Clear filters from UI elements
 */
function clearFiltersFromUI() {
    try {
        const filterElements = document.querySelectorAll([
            'select[data-filter-type]',
            'input[data-filter-type]',
            'select[data-filter]',
            'input[data-filter]',
            '.category-filter',
            '.price-filter',
            '.status-filter',
            '.search-input'
        ].join(', '));
        
        filterElements.forEach(element => {
            if (element.tagName.toLowerCase() === 'select') {
                element.selectedIndex = 0;
            } else if (element.type === 'checkbox' || element.type === 'radio') {
                element.checked = false;
            } else if (element.type === 'text' || element.type === 'search') {
                element.value = '';
            }
        });
        
        // Trigger change events
        triggerUIUpdateEvents();
        
    } catch (error) {
        console.error('Error clearing filters from UI:', error);
    }
}

/**
 * Trigger UI update events
 */
function triggerUIUpdateEvents() {
    try {
        // Dispatch change events on filter form if it exists
        const filterForm = document.querySelector('.filters-form, #filtersForm, [data-filter-form]');
        if (filterForm) {
            const changeEvent = new Event('change', { bubbles: true });
            filterForm.dispatchEvent(changeEvent);
        }
        
        // Dispatch custom event
        dispatchFilterEvent('filtersUIUpdated', { filters: currentFilters });
        
    } catch (error) {
        console.error('Error triggering UI update events:', error);
    }
}

/**
 * Dispatch a filter-related custom event
 * @param {string} eventName - Name of the event
 * @param {Object} detail - Event detail data
 */
function dispatchFilterEvent(eventName, detail = {}) {
    try {
        const customEvent = new CustomEvent(eventName, {
            detail,
            bubbles: true
        });
        document.dispatchEvent(customEvent);
    } catch (error) {
        console.error(`Error dispatching ${eventName} event:`, error);
    }
}

/**
 * Get current filter state
 * @returns {Object} Current filter state
 */
export function getCurrentFilters() {
    return { ...currentFilters };
}

/**
 * Get saved filter information
 * @returns {Object} Information about saved filters
 */
export function getFilterInfo() {
    try {
        const savedFilters = get(STORAGE_KEY, {});
        return {
            hasSavedFilters: Object.keys(savedFilters).length > 0,
            filterCount: Object.keys(savedFilters).length,
            filters: savedFilters,
            currentFilters: currentFilters
        };
    } catch (error) {
        console.error('Error getting filter info:', error);
        return {
            hasSavedFilters: false,
            filterCount: 0,
            filters: {},
            currentFilters: {}
        };
    }
}

// Export default object for convenience
export default {
    init: initFilterPersistence,
    updateFilter,
    clearAll: clearAllFilters,
    getCurrent: getCurrentFilters,
    getInfo: getFilterInfo
};
