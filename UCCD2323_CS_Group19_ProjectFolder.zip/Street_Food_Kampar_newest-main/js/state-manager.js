/**
 * Centralized State Management for Kampar Street Food
 */

// =============================================================================
// STATE MANAGER - THE BRAIN OF THE WEBSITE
// =============================================================================

/**
 * Central state management system
 */
window.StateManager = {
    initialized: false, // Guard flag to prevent duplicate initialization
    updateInProgress: false, // Prevent recursive updates
    throttleDelay: 100, // Throttle UI updates
    
    // Throttle utility function
    throttle: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func.apply(this, args);
            };
            if (!timeout) {
                timeout = setTimeout(later, wait);
            }
        };
    },
    
    /**
     * Initialize the state management system
     */
    init: function() {
        if (this.initialized) {
            console.log('StateManager already initialized, skipping...');
            return;
        }
        
        console.log('StateManager: Initializing...');
        this.initialized = true;
        
        this.loadState();           // Load saved data from browser storage
        this.setupEventListeners(); // Listen for changes from other tabs
        this.updateAllUI();         // Update all buttons, counters, etc.
    },

    /**
     * Load saved state from localStorage
     */
    loadState: function() {
        console.log('StateManager: Loading state...');
        
        // Load favorites from browser storage (default to empty array if none saved)
        const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
        console.log('StateManager: Loaded favorites from localStorage:', favorites);
        
        // Set up the internal state object
        this.state = {
            favorites: favorites,           // Array of favorite vendor IDs
            user: this.getCurrentUser()     // Current user information
        };
        
        console.log('StateManager: Initialized state:', this.state);
    },

    /**
     * Get current user from authentication system
     * @returns {Object|null} - User object if logged in, null if not
     */
    getCurrentUser: function() {
        // Try to use global auth function first
        if (typeof getCurrentUser === 'function') {
            return getCurrentUser();
        }
        
        // Fallback: check localStorage for saved auth data
        const authData = localStorage.getItem('kamparAuthData');
        if (authData) {
            try {
                const parsed = JSON.parse(authData);
                return parsed.user || null;
            } catch (e) {
                // If data is corrupted, return null
                return null;
            }
        }
        return null;  // No user logged in
    },

    /**
     * Get the current list of favorite vendor IDs
     * @returns {Array} - Array of vendor IDs (strings like ["1", "3", "7"])
     */
    getFavorites: function() {
        return this.state.favorites || [];  // Return favorites array or empty array if undefined
    },

    // Add to favorites
    addFavorite: function(vendorId) {
        console.log('StateManager: Adding vendor to favorites:', vendorId);
        if (!this.isFavorite(vendorId)) {
            this.state.favorites.push(vendorId);
            this.saveFavorites();
            this.updateAllUI();  // immediate UI update
            this.dispatchFavoritesUpdate();
            this.showToast('Added to favorites', 'success');
            console.log('StateManager: Vendor added to favorites. Total favorites:', this.state.favorites.length);
        } else {
            console.log('StateManager: Vendor already in favorites');
        }
    },

    // Remove from favorites
    removeFavorite: function(vendorId) {
        console.log('StateManager: Removing vendor from favorites:', vendorId);
        const index = this.state.favorites.indexOf(vendorId);
        if (index > -1) {
            this.state.favorites.splice(index, 1);
            this.saveFavorites();
            this.updateAllUI();  // immediate UI update
            this.dispatchFavoritesUpdate();
            this.showToast('Removed from favorites', 'info');
            console.log('StateManager: Vendor removed from favorites. Total favorites:', this.state.favorites.length);
        } else {
            console.log('StateManager: Vendor not found in favorites');
        }
    },

    // Toggle favorite status
    toggleFavorite: function(vendorId) {
        console.log('StateManager: Toggling favorite for vendor:', vendorId);
        if (this.isFavorite(vendorId)) {
            this.removeFavorite(vendorId);
        } else {
            this.addFavorite(vendorId);
        }
    },

    // Check if vendor is favorite
    isFavorite: function(vendorId) {
        return this.state.favorites.includes(vendorId);
    },

    // Save favorites to localStorage
    saveFavorites: function() {
        console.log('StateManager: Saving favorites to localStorage:', this.state.favorites);
        localStorage.setItem('favorites', JSON.stringify(this.state.favorites));
        
        // Update global appState for backward compatibility
        if (window.appState) {
            window.appState.favorites = this.state.favorites;
        }
    },

    // Dispatch favorites update event
    dispatchFavoritesUpdate: function() {
        const event = new CustomEvent('favoritesUpdated', {
            detail: {
                favorites: this.state.favorites,
                count: this.state.favorites.length
            }
        });
        window.dispatchEvent(event);
    },

    // Setup event listeners for cross-page sync
    setupEventListeners: function() {
        // Prevent duplicate setup
        if (this.listenersSetup) {
            console.log('StateManager: Event listeners already setup, skipping...');
            return;
        }
        
        this.listenersSetup = true;
        
        // Use named functions to prevent duplicate listeners with throttling
        this.handleStorageChange = this.throttle((e) => {
            if (e.key === 'favorites' && !this.updateInProgress) {
                this.updateInProgress = true;
                this.loadState();
                this.updateAllUI();
                this.dispatchFavoritesUpdate();
                setTimeout(() => { this.updateInProgress = false; }, this.throttleDelay);
            }
        }, this.throttleDelay);
        
        this.handleFavoritesUpdate = this.throttle((e) => {
            if (!this.updateInProgress) {
                this.updateInProgress = true;
                this.updateAllUI();
                setTimeout(() => { this.updateInProgress = false; }, this.throttleDelay);
            }
        }, this.throttleDelay);
        
        // Remove existing listeners first
        window.removeEventListener('storage', this.handleStorageChange);
        window.removeEventListener('favoritesUpdated', this.handleFavoritesUpdate);
        
        // Listen for storage changes (other tabs)
        window.addEventListener('storage', this.handleStorageChange);

        // Listen for favorites updates
        window.addEventListener('favoritesUpdated', this.handleFavoritesUpdate);
    },

    // Update all UI elements across the page
    updateAllUI: function() {
        if (this.updateInProgress) {
            console.log('StateManager: Update already in progress, skipping...');
            return;
        }
        
        console.log('StateManager: Updating all UI, favorites count:', this.state.favorites.length);
        this.updateFavoritesCount();
        this.updateFavoriteButtons();
        this.updateFavoritesList();
    },

    // Update favorites count in navigation and other places
    updateFavoritesCount: function() {
        const count = this.state.favorites.length;
        console.log('StateManager: Updating favorites count to:', count);
        
        // Update navigation counter
        const navCounter = document.getElementById('favorites-count');
        if (navCounter) {
            if (count > 0) {
                navCounter.textContent = count;
                navCounter.style.display = 'inline-block';
                console.log('StateManager: Updated nav counter to show', count);
            } else {
                navCounter.style.display = 'none';
                console.log('StateManager: Hid nav counter');
            }
        } else {
            console.log('StateManager: Nav counter element not found');
        }

        // Update all other counters
        document.querySelectorAll('[data-favorites-count]').forEach(el => {
            el.textContent = count;
        });

        // Update specific elements
        const elements = [
            'favoritesCount',
            'total-favorites', 
            'stats-favorites'
        ];
        
        elements.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = count;
            }
        });
    },

    // Update favorite button states
    updateFavoriteButtons: function() {
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            const vendorId = btn.getAttribute('data-vendor-id');
            if (vendorId) {
                const isFav = this.isFavorite(vendorId);
                const icon = btn.querySelector('i');
                
                if (icon) {
                    if (isFav) {
                        icon.className = 'fas fa-heart text-danger';
                        btn.classList.add('active');
                    } else {
                        icon.className = 'far fa-heart';
                        btn.classList.remove('active');
                    }
                }
            }
        });
    },

    // Update favorites lists
    updateFavoritesList: function() {
        // This will be called by individual pages to refresh their lists
        const event = new CustomEvent('refreshFavoritesList');
        window.dispatchEvent(event);
    },

    // Show toast notification
    showToast: function(message, type = 'info') {
        // Use existing toast system if available
        if (typeof utils !== 'undefined' && utils.showToast) {
            utils.showToast(message, type);
        } else if (typeof showAlert === 'function') {
            showAlert(message, type);
        } else {
            // Fallback - create simple toast
            const toast = document.createElement('div');
            toast.className = `alert alert-${type} position-fixed`;
            toast.style.cssText = 'top: 20px; right: 20px; z-index: 1055; max-width: 300px;';
            toast.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="fas fa-${type === 'success' ? 'check' : type === 'danger' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close ms-auto" onclick="this.parentElement.parentElement.remove()"></button>
                </div>
            `;
            document.body.appendChild(toast);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 3000);
            
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    },

    // Initialize favorites UI - updates all favorite buttons and states
    initializeFavoritesUI: function() {
        if (this.initializingUI) {
            console.log('StateManager: UI initialization already in progress, skipping...');
            return;
        }
        
        this.initializingUI = true;
        
        console.log('StateManager: Initializing favorites UI for', document.querySelectorAll('.favorite-btn').length, 'buttons');
        this.updateAllUI();
        
        // Ensure all favorite buttons have proper click handlers
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            const vendorId = btn.getAttribute('data-vendor-id');
            if (vendorId && !btn.hasAttribute('data-handler-attached')) {
                console.log('StateManager: Setting up click handler for vendor', vendorId);
                
                btn.setAttribute('data-handler-attached', 'true');
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('StateManager: Favorite button clicked for vendor', vendorId);
                    this.toggleFavorite(vendorId);
                });
            }
        });
        
        console.log('StateManager: Favorites UI initialization complete');
        
        setTimeout(() => {
            this.initializingUI = false;
        }, 50);
    },

    // Get favorite vendors from vendor list
    getFavoriteVendors: function(vendors) {
        if (!vendors || vendors.length === 0) return [];
        return vendors.filter(vendor => this.isFavorite(vendor.id));
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    StateManager.init();
});

// Export for global use
window.favoritesManager = StateManager;