/**
 * VendorAPI.js
 * Handles all vendor operations using JSON + localStorage
 * Mimics RESTful API
 */

import vendorsData from './vendors.json'; // your JSON file

// Key to store favorites/reviews in localStorage
const STORAGE_KEY = 'vendors_state';

function loadState() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
}

function saveState(state) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function mergeVendorState(vendor) {
    const state = loadState();
    const vendorState = state[vendor.id] || {};
    return {
        ...vendor,
        isFavorite: vendorState.isFavorite || false,
        reviews: vendorState.reviews || vendor.reviews || [],
    };
}

// Get all vendors
export function getAllVendors() {
    return vendorsData.map(mergeVendorState);
}

// Get a single vendor by ID
export function getVendorById(id) {
    const vendor = vendorsData.find(v => v.id === id);
    if (!vendor) return null;
    return mergeVendorState(vendor);
}

// Toggle favorite
export function toggleFavorite(id) {
    const state = loadState();
    const vendorState = state[id] || {};
    vendorState.isFavorite = !vendorState.isFavorite;
    state[id] = vendorState;
    saveState(state);
    return vendorState.isFavorite;
}

// Add review
export function addReview(id, review) {
    const state = loadState();
    const vendorState = state[id] || {};
    vendorState.reviews = vendorState.reviews || [];
    vendorState.reviews.push(review);
    state[id] = vendorState;
    saveState(state);
}

// Update reviews after adding dynamically
export function getReviews(id) {
    const vendor = getVendorById(id);
    return vendor ? vendor.reviews : [];
}
